// MUSIX MAIN.DART - MASSIVE GLASS UI UPDATE VERSION
// Safer library management, proper Settings, swipe tabs, calmer glass UI,
// album actions, foreground metadata scan status, search/sort library controls,
// and no rainbow header text.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui';

import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:musix/models/track_metadata.dart';
import 'state/now_playing.dart';
import 'services/google_auth_client.dart';
import 'services/drive_audio_source.dart';
import 'widgets/glassy_container.dart';

part 'services/drive_utils.dart';
part 'services/metadata_service.dart';
part 'screens/home_tab.dart';
part 'screens/library_tab.dart';
part 'screens/drive_tab.dart';
part 'widgets/library_widgets.dart';
part 'widgets/player_widgets.dart';

// ─── Compatibility helpers for the local metadata model ─────────────────────
// These keep main.dart in sync even if lib/models/track_metadata.dart only has
// fromJson/toJson and plain fields.

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const MusixApp());
}

// ─── Palette ─────────────────────────────────────────────────────────────────
const _bg = Color(0xFF101014);
const _pink = Color(0xFFFF2A7A);
const _accentWhite = Color(0xFFEDEDED);
const _accentChampagne = Color(0xFFE6C8A0);
const _accentBlue = Color(0xFF8EA7FF);
const _accentPink = Color(0xFFFF4D8D);
const _accentDefault = _accentChampagne;
const _cyan = Color(0xFF00E5FF);
const _purple = Color(0xFF7C4DFF);

const _textPri = Color(0xFFFFFFFF);
const _textSub = Color(0xFFA0A0B0);
const _glassWhite = Color(0x15FFFFFF);
const glassBorder = Color(0x30FFFFFF);

final List<Color> _defaultDynamicColors = [
  const Color(0xFF2A2430),
  _accentDefault,
  const Color(0xFF243447),
  const Color(0xFF15151B),
];

const _albumsPrefsKey = 'dopamine_albums_v9';
const _albumsBackupPrefsKey = 'dopamine_albums_v9_backup';
const _metadataScanServiceId = 8901;
const _metadataProgressPrefsKey = 'musix_metadata_progress_v1';
const _uiPrefsKey = 'musix_ui_prefs_v1';
const _albumColorPrefsKey = 'musix_album_color_cache_v1';
const _libraryBrainPrefsKey = 'musix_library_brain_v1';
const _playHistoryPrefsKey = 'musix_play_history_v1';
const _lastPlayedPrefsKey = 'musix_last_played_v1';

const glassModePerformance = 'performance';
const _glassModeBalanced = 'balanced';
const glassModePretty = 'pretty';

const _accentModeWhite = 'white';
const _accentModeChampagne = 'champagne';
const _accentModeBlue = 'blue';
const _accentModePink = 'pink';

final ValueNotifier<String> glassModeNotifier = ValueNotifier<String>(_glassModeBalanced);

bool _isValidGlassMode(String mode) {
  return mode == glassModePerformance || mode == _glassModeBalanced || mode == glassModePretty;
}

bool _isValidAccentMode(String mode) {
  return mode == _accentModeWhite ||
      mode == _accentModeChampagne ||
      mode == _accentModeBlue ||
      mode == _accentModePink;
}

Color _accentColorForMode(String mode) {
  if (mode == _accentModeWhite) return _accentWhite;
  if (mode == _accentModeBlue) return _accentBlue;
  if (mode == _accentModePink) return _accentPink;
  return _accentChampagne;
}

String _accentModeLabelForMode(String mode) {
  if (mode == _accentModeWhite) return 'White';
  if (mode == _accentModeBlue) return 'Soft Blue';
  if (mode == _accentModePink) return 'Pink';
  return 'Champagne';
}

// ─── 4-Color Deterministic Gradient Generator ────────────────────────────────
List<Color> getAlbumGradient(String name) {
  int hash = 0;
  for (int i = 0; i < name.length; i++) {
    hash = name.codeUnitAt(i) + ((hash << 5) - hash);
  }

  final base = (hash % 360).abs().toDouble();

  return [
    HSLColor.fromAHSL(1.0, base, 0.46, 0.30).toColor(),
    HSLColor.fromAHSL(1.0, (base + 42) % 360, 0.52, 0.44).toColor(),
    HSLColor.fromAHSL(1.0, (base + 120) % 360, 0.38, 0.34).toColor(),
    HSLColor.fromAHSL(1.0, (base + 210) % 360, 0.34, 0.24).toColor(),
  ];
}

List<Color> _safeColors(List<Color> colors) {
  if (colors.length >= 4) return colors;
  return _defaultDynamicColors;
}

String _colorToHex(Color color) {
  return color.value.toRadixString(16).padLeft(8, '0');
}

Color? _colorFromHex(String value) {
  final parsed = int.tryParse(value, radix: 16);
  if (parsed == null) return null;
  return Color(parsed);
}

String _localCoverPath(String source) {
  if (source.startsWith('file://')) {
    return Uri.parse(source).toFilePath();
  }
  return source;
}

bool _isLocalCover(String? source) {
  if (source == null || source.isEmpty) return false;
  return source.startsWith('file://') || source.startsWith('/');
}

// Album art can be massive when it comes from embedded tags. Decoding every
// image at full resolution makes grids feel slow even when the files are
// already cached locally. Keep UI decoding capped to a sensible cover size.
const int _coverDecodeSize = 900;

ImageProvider? _coverProvider(String? source) {
  if (source == null || source.isEmpty) return null;

  final baseProvider = _isLocalCover(source)
      ? FileImage(File(_localCoverPath(source))) as ImageProvider
      : NetworkImage(source);

  return ResizeImage(
    baseProvider,
    width: _coverDecodeSize,
    height: _coverDecodeSize,
  );
}

Widget _coverImage(
  String source, {
  BoxFit fit = BoxFit.cover,
  Widget Function(BuildContext, Object, StackTrace?)? errorBuilder,
}) {
  if (_isLocalCover(source)) {
    return Image.file(
      File(_localCoverPath(source)),
      fit: fit,
      cacheWidth: _coverDecodeSize,
      cacheHeight: _coverDecodeSize,
      errorBuilder: errorBuilder,
    );
  }

  return Image.network(
    source,
    fit: fit,
    cacheWidth: _coverDecodeSize,
    cacheHeight: _coverDecodeSize,
    errorBuilder: errorBuilder,
  );
}



// ─── App Root ────────────────────────────────────────────────────────────────
class MusixApp extends StatelessWidget {
  const MusixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
        sliderTheme: const SliderThemeData(
          thumbColor: _accentDefault,
          activeTrackColor: _pink,
          inactiveTrackColor: _glassWhite,
          trackHeight: 4,
          thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
          overlayShape: RoundSliderOverlayShape(overlayRadius: 14),
        ),
      ),
      home: const MainScreen(),
    );
  }
}

// ─── Now-Playing State ──────────────────────────────────────────────────────


final _nowPlaying = NowPlaying();

// ─── Main Screen ────────────────────────────────────────────────────────────
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  GoogleSignInAccount? _user;
  final AudioPlayer _player = AudioPlayer();
  bool _signingIn = false;
  int _navIndex = 0;
  late final PageController _pageController;

  String _libraryQuery = '';
  String _librarySortMode = 'az';
  bool _libraryGridMode = true;

  List<Map<String, String>> _albums = [];
  bool _loadingSaved = true;
  bool _isScanning = false;
  static const _albumsKey = _albumsPrefsKey;

  Map<String, String>? _viewingAlbum;
  List<drive.File> _albumTracks = [];
  bool _loadingAlbum = false;

  // Whole-library foreground metadata scan state. This keeps updating even while
  // you move around the app or open albums.
  bool _loadingMetadata = false;
  int _metadataDone = 0;
  int _metadataTotal = 0;
  int _metadataFast = 0;
  int _metadataDeep = 0;
  int _metadataFailed = 0;
  String _metadataPhase = 'Idle';
  StateSetter? _settingsSheetSetState;
  Timer? _metadataProgressPoller;
  int _lastMetadataProgressStamp = 0;
  bool _finalMetadataRefreshDone = true;
  bool _showBackgroundGlow = true;
  String _glassMode = _glassModeBalanced;
  String _accentMode = _accentModeChampagne;
  Map<String, String>? _lastPlayed;
  final Map<String, List<Color>> _albumColorCache = {};
  final Map<String, List<drive.File>> _albumTracksCache = {};
  final Map<String, Map<String, String>> _libraryBrain = {};
  final List<Map<String, String>> _playHistory = [];
  bool _homeShowContinue = true;
  bool _homeShowGenres = true;
  bool _homeShowDecades = true;
  bool _homeShowArtists = true;
  bool _homeShowDiscovery = true;

  // Album-only metadata scan state. This is separate so opening an album does
  // not make the whole-library foreground scan look like it stopped.
  bool _albumMetadataLoading = false;
  int _albumMetadataDone = 0;
  int _albumMetadataTotal = 0;

  List<Color> _currentDynamicColors = List<Color>.from(_defaultDynamicColors);

  drive.File? _exploreFolder;
  List<drive.File> _exploreItems = [];
  bool _loadingExplore = false;
  final List<drive.File> _navStack = [];

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [drive.DriveApi.driveReadonlyScope],
  );

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _navIndex);
    _loadUiPreferences();
    _loadLastPlayed();
    _loadCachedMetadata();
    _loadLibraryBrainAndHistory();
    _trySilentSignIn();

    FlutterForegroundTask.addTaskDataCallback(_onMetadataTaskData);
    _startMetadataProgressPolling();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _requestForegroundMetadataPermissions();
      _initForegroundMetadataService();
    });

    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _playNext();
      }
    });
  }

  @override
  void dispose() {
    FlutterForegroundTask.removeTaskDataCallback(_onMetadataTaskData);
    _metadataProgressPoller?.cancel();
    _pageController.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _loadCachedMetadata() async {
    await _metaStore.load();
    if (mounted) setState(() {});
  }

  Color get _appAccent => _accentColorForMode(_accentMode);

  Future<void> _loadLastPlayed() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_lastPlayedPrefsKey);
      if (raw == null || raw.isEmpty) return;

      final decoded = json.decode(raw);
      if (decoded is! Map) return;

      final data = <String, String>{};
      decoded.forEach((key, value) {
        if (key is String && value != null) {
          data[key] = value.toString();
        }
      });

      if (!mounted) return;
      setState(() => _lastPlayed = data);
    } catch (_) {}
  }

  Future<void> _saveLastPlayed(
    drive.File file, {
    String? coverUrl,
  }) async {
    final fileId = DriveUtils.effectiveId(file);
    if (fileId == null) return;

    final meta = DriveUtils.getTrackMeta(file);
    final existing = _lastPlayed;
    final sameAsExisting = existing?['fileId'] == fileId;
    final data = <String, String>{
      'fileId': fileId,
      'fileName': file.name ?? meta['title'] ?? 'Unknown',
      'title': meta['title'] ?? file.name ?? 'Unknown',
      'artist': meta['artist'] ?? 'Unknown Artist',
      'coverUrl': coverUrl ?? (sameAsExisting ? (existing?['coverUrl'] ?? '') : ''),
      'albumId': _viewingAlbum?['id'] ?? (sameAsExisting ? (existing?['albumId'] ?? '') : ''),
      'albumName': _viewingAlbum?['name'] ?? (sameAsExisting ? (existing?['albumName'] ?? '') : ''),
      'size': file.size ?? '',
      'modifiedTime': file.modifiedTime?.toIso8601String() ?? '',
    };

    _lastPlayed = data;

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_lastPlayedPrefsKey, json.encode(data));
    } catch (_) {}

    if (mounted) setState(() {});
  }

  Future<void> _playLastPlayed() async {
    final data = _lastPlayed;
    if (_user == null || data == null) return;

    final fileId = data['fileId'];
    if (fileId == null || fileId.isEmpty) return;

    try {
      final coverUrl = data['coverUrl'] ?? '';
      final albumName = data['albumName'] ?? '';
      final albumId = data['albumId'] ?? '';

      drive.File track = drive.File()
        ..id = fileId
        ..name = data['fileName'] ?? data['title'] ?? 'Unknown';

      List<drive.File> queue = [track];
      int index = 0;
      Map<String, String>? albumRecord;

      if (albumId.isNotEmpty) {
        albumRecord = _albums.firstWhere(
          (album) => album['id'] == albumId,
          orElse: () => {'id': albumId, 'name': albumName, 'cover': coverUrl},
        );

        final authHeaders = await _user!.authHeaders;
        final api = drive.DriveApi(GoogleAuthClient(authHeaders));
        final tracks = await _fetchTracksForAlbumRecord(api, albumRecord);
        final foundIndex = tracks.indexWhere((item) => DriveUtils.effectiveId(item) == fileId);

        if (tracks.isNotEmpty && foundIndex >= 0) {
          queue = tracks;
          index = foundIndex;
          track = tracks[foundIndex];
        }
      }

      await _playSong(
        track,
        queue: queue,
        idx: index,
        coverUrl: coverUrl.isNotEmpty ? coverUrl : albumRecord?['cover'],
        colors: getAlbumGradient(albumName.isNotEmpty ? albumName : (data['title'] ?? 'Musix')),
      );
    } catch (e) {
      _showError('Could not continue last song: $e');
    }
  }
  Future<void> _loadUiPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      glassModeNotifier.value = _glassMode;

      final colorsRaw = prefs.getString(_albumColorPrefsKey);
      if (colorsRaw != null && colorsRaw.isNotEmpty) {
        try {
          final decodedColors = json.decode(colorsRaw);
          if (decodedColors is Map) {
            _albumColorCache.clear();
            decodedColors.forEach((key, value) {
              if (key is String && value is List) {
                final parsed = value
                    .map((item) => _colorFromHex(item.toString()))
                    .whereType<Color>()
                    .toList();
                if (parsed.length >= 4) {
                  _albumColorCache[key] = parsed.take(4).toList();
                }
              }
            });
          }
        } catch (_) {}
      }

      final raw = prefs.getString(_uiPrefsKey);
      if (raw == null || raw.isEmpty) return;

      final data = json.decode(raw);
      if (data is! Map) return;

      if (!mounted) return;
      setState(() {
        _showBackgroundGlow = data['showBackgroundGlow'] != false;
        _homeShowContinue = data['homeShowContinue'] != false;
        _homeShowGenres = data['homeShowGenres'] != false;
        _homeShowDecades = data['homeShowDecades'] != false;
        _homeShowArtists = data['homeShowArtists'] != false;
        _homeShowDiscovery = data['homeShowDiscovery'] != false;
        final savedGlassMode = (data['glassMode'] ?? _glassModeBalanced).toString();
        _glassMode = _isValidGlassMode(savedGlassMode) ? savedGlassMode : _glassModeBalanced;
        glassModeNotifier.value = _glassMode;

        final savedAccentMode = (data['accentMode'] ?? _accentModeChampagne).toString();
        _accentMode = _isValidAccentMode(savedAccentMode) ? savedAccentMode : _accentModeChampagne;
      });
    } catch (_) {}
  }

  Future<void> _saveUiPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _uiPrefsKey,
      json.encode({
        'showBackgroundGlow': _showBackgroundGlow,
        'glassMode': _glassMode,
        'homeShowContinue': _homeShowContinue,
        'homeShowGenres': _homeShowGenres,
        'homeShowDecades': _homeShowDecades,
        'homeShowArtists': _homeShowArtists,
        'homeShowDiscovery': _homeShowDiscovery,
        'accentMode': _accentMode,
      }),
    );
  }

  Future<void> _saveAlbumColorCache() async {
    final prefs = await SharedPreferences.getInstance();
    final payload = <String, List<String>>{};
    _albumColorCache.forEach((key, colors) {
      if (colors.length >= 4) {
        payload[key] = colors.take(4).map(_colorToHex).toList();
      }
    });
    await prefs.setString(_albumColorPrefsKey, json.encode(payload));
  }


  String _cleanBrainValue(String? value) {
    final v = (value ?? '').trim();
    if (v.isEmpty || v.toLowerCase() == 'unknown' || v.toLowerCase() == 'unknown artist') {
      return '';
    }
    return v;
  }

  String _yearFromText(String value) {
    final match = RegExp(r'(19|20)\d{2}').firstMatch(value);
    return match?.group(0) ?? '';
  }

  String _decadeFromYear(String year) {
    final y = int.tryParse(year);
    if (y == null) return '';
    return '${(y ~/ 10) * 10}s';
  }

  String _genreFromText(String text) {
    final t = text.toLowerCase();

    bool hasAny(List<String> words) => words.any((w) => t.contains(w));

    if (hasAny(['hip hop', 'hip-hop', 'rap', 'trap', 'boom bap', 'drill', 'mixtape'])) {
      return 'Hip-Hop';
    }
    if (hasAny(['r&b', 'rnb', 'soul', 'neo soul', 'motown', 'funk'])) {
      return 'Soul / R&B';
    }
    if (hasAny(['jazz', 'bebop', 'fusion', 'blue note'])) return 'Jazz';
    if (hasAny(['rock', 'metal', 'punk', 'grunge', 'indie'])) return 'Rock';
    if (hasAny(['electronic', 'edm', 'house', 'techno', 'daft', 'dance'])) return 'Electronic';
    if (hasAny(['soundtrack', 'score', 'ost', 'film'])) return 'Soundtracks';
    if (hasAny(['pop', 'michael jackson', 'madonna'])) return 'Pop';
    return '';
  }

  String _normalizeGenre(String value) {
    final g = _cleanBrainValue(value);
    if (g.isEmpty) return '';
    final t = g.toLowerCase();

    if (t.contains('hip') || t.contains('rap') || t.contains('trap')) return 'Hip-Hop';
    if (t.contains('r&b') || t.contains('rnb') || t.contains('soul') || t.contains('funk')) return 'Soul / R&B';
    if (t.contains('jazz')) return 'Jazz';
    if (t.contains('rock') || t.contains('metal') || t.contains('punk')) return 'Rock';
    if (t.contains('electronic') || t.contains('house') || t.contains('techno') || t.contains('dance')) {
      return 'Electronic';
    }
    if (t.contains('soundtrack') || t.contains('score')) return 'Soundtracks';
    if (t.contains('pop')) return 'Pop';

    return g.split('/').first.split(';').first.split(',').first.trim();
  }

  String _mostCommon(List<String> values) {
    final counts = <String, int>{};
    for (final raw in values) {
      final value = _cleanBrainValue(raw);
      if (value.isEmpty) continue;
      counts[value] = (counts[value] ?? 0) + 1;
    }
    if (counts.isEmpty) return '';

    final entries = counts.entries.toList()
      ..sort((a, b) {
        final byCount = b.value.compareTo(a.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      });

    return entries.first.key;
  }

  int _brainInt(Map<String, String> info, String key) {
    return int.tryParse(info[key] ?? '') ?? 0;
  }

  Future<void> _loadLibraryBrainAndHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final brainRaw = prefs.getString(_libraryBrainPrefsKey);
      final historyRaw = prefs.getString(_playHistoryPrefsKey);

      final nextBrain = <String, Map<String, String>>{};
      if (brainRaw != null && brainRaw.isNotEmpty) {
        final decoded = json.decode(brainRaw);
        if (decoded is Map) {
          decoded.forEach((key, value) {
            if (key is String && value is Map) {
              nextBrain[key] = Map<String, String>.from(value);
            }
          });
        }
      }

      final nextHistory = <Map<String, String>>[];
      if (historyRaw != null && historyRaw.isNotEmpty) {
        final decoded = json.decode(historyRaw);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map) nextHistory.add(Map<String, String>.from(item));
          }
        }
      }

      if (!mounted) return;
      setState(() {
        _libraryBrain
          ..clear()
          ..addAll(nextBrain);
        _playHistory
          ..clear()
          ..addAll(nextHistory.take(40));
      });

      _buildBasicLibraryBrain(save: false);
    } catch (_) {}
  }

  Future<void> _saveLibraryBrain() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_libraryBrainPrefsKey, json.encode(_libraryBrain));
  }

  Future<void> _savePlayHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_playHistoryPrefsKey, json.encode(_playHistory.take(40).toList()));
  }

  void _buildBasicLibraryBrain({bool save = true}) {
    if (_albums.isEmpty) return;

    final now = DateTime.now().millisecondsSinceEpoch.toString();
    bool changed = false;

    for (final album in _albums) {
      final id = album['id'] ?? '';
      if (id.isEmpty) continue;

      final existing = _libraryBrain[id] ?? <String, String>{};
      final name = album['name'] ?? existing['name'] ?? 'Album';
      final cover = album['cover'] ?? existing['cover'] ?? '';
      final dateAdded = album['dateAdded'] ?? existing['dateAdded'] ?? now;
      final savedArtist = _cleanBrainValue(album['artist']).isNotEmpty
          ? album['artist']!
          : existing['artist'] ?? '';
      final savedDisplayName = _cleanBrainValue(album['displayName']).isNotEmpty
          ? album['displayName']!
          : existing['displayName'] ?? name;
      final year = _cleanBrainValue(album['year']).isNotEmpty
          ? album['year']!
          : _cleanBrainValue(existing['year']).isNotEmpty
              ? existing['year']!
              : _yearFromText(name);
      final genre = _cleanBrainValue(album['genre']).isNotEmpty
          ? _normalizeGenre(album['genre']!)
          : _cleanBrainValue(existing['genre']).isNotEmpty
              ? existing['genre']!
              : _genreFromText('$name $savedArtist');

      album['dateAdded'] = dateAdded;

      final next = <String, String>{
        'albumId': id,
        'name': name,
        'displayName': savedDisplayName,
        'artist': savedArtist,
        'year': year,
        'decade': _decadeFromYear(year),
        'genre': genre,
        'cover': cover,
        'trackCount': album['trackCount'] ?? existing['trackCount'] ?? '',
        'playCount': existing['playCount'] ?? '0',
        'lastPlayed': existing['lastPlayed'] ?? '',
        'dateAdded': dateAdded,
      };

      if (json.encode(existing) != json.encode(next)) {
        _libraryBrain[id] = next;
        changed = true;
      }
    }

    if (changed && save) {
      if (mounted) setState(() {});
      _saveLibraryBrain();
      _persistAlbums();
    }
  }

  void _indexAlbumFromTracks(Map<String, String> album, List<drive.File> tracks, {bool save = true}) {
    final id = album['id'] ?? '';
    if (id.isEmpty) return;

    final existing = _libraryBrain[id] ?? <String, String>{};
    final artists = <String>[];
    final albumNames = <String>[];
    final years = <String>[];
    final genres = <String>[];

    for (final track in tracks) {
      final cached = _metaStore.peekFresh(track) ?? _metaStore.peek(track);
      if (cached == null) continue;
      artists.add(cached.artist);
      if (cached.album != null) albumNames.add(cached.album!);
      if (cached.year != null) years.add(cached.year!);
      if (cached.genre != null) genres.add(cached.genre!);
    }

    final folderName = album['name'] ?? existing['name'] ?? 'Album';
    final displayName = _mostCommon(albumNames).isNotEmpty ? _mostCommon(albumNames) : folderName;
    final artist = _mostCommon(artists);
    final rawYear = _mostCommon(years).isNotEmpty ? _mostCommon(years) : _yearFromText('$displayName $folderName');
    final rawGenre = _normalizeGenre(_mostCommon(genres)).isNotEmpty
        ? _normalizeGenre(_mostCommon(genres))
        : _genreFromText('$displayName $folderName $artist');

    final next = <String, String>{
      'albumId': id,
      'name': folderName,
      'displayName': displayName,
      'artist': artist,
      'year': rawYear,
      'decade': _decadeFromYear(rawYear),
      'genre': rawGenre,
      'cover': album['cover'] ?? existing['cover'] ?? '',
      'trackCount': tracks.length.toString(),
      'playCount': existing['playCount'] ?? '0',
      'lastPlayed': existing['lastPlayed'] ?? '',
      'dateAdded': album['dateAdded'] ?? existing['dateAdded'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
    };

    album['displayName'] = displayName;
    album['artist'] = artist;
    album['year'] = rawYear;
    album['genre'] = rawGenre;
    album['trackCount'] = tracks.length.toString();

    _libraryBrain[id] = next;
    if (save) {
      _saveLibraryBrain();
      _persistAlbums();
      if (mounted) setState(() {});
    }
  }

  Future<void> _recordPlay(drive.File file, {String? coverUrl}) async {
    final fileId = DriveUtils.effectiveId(file);
    if (fileId == null) return;

    final meta = DriveUtils.getTrackMeta(file);
    final albumId = _viewingAlbum?['id'] ?? '';
    final albumName = _viewingAlbum?['name'] ?? '';
    final now = DateTime.now().millisecondsSinceEpoch.toString();

    _playHistory.removeWhere((item) => item['fileId'] == fileId);
    _playHistory.insert(0, {
      'fileId': fileId,
      'title': meta['title'] ?? file.name ?? 'Unknown',
      'artist': meta['artist'] ?? 'Unknown Artist',
      'albumId': albumId,
      'albumName': albumName,
      'cover': coverUrl ?? _viewingAlbum?['cover'] ?? '',
      'playedAt': now,
    });

    if (_playHistory.length > 40) {
      _playHistory.removeRange(40, _playHistory.length);
    }

    if (albumId.isNotEmpty) {
      final existing = _libraryBrain[albumId] ?? <String, String>{};
      existing['albumId'] = albumId;
      existing['name'] = existing['name'] ?? albumName;
      existing['displayName'] = existing['displayName'] ?? albumName;
      existing['cover'] = coverUrl ?? existing['cover'] ?? _viewingAlbum?['cover'] ?? '';
      existing['playCount'] = ((_brainInt(existing, 'playCount')) + 1).toString();
      existing['lastPlayed'] = now;
      existing['dateAdded'] = existing['dateAdded'] ?? _viewingAlbum?['dateAdded'] ?? now;
      _libraryBrain[albumId] = Map<String, String>.from(existing);
      _saveLibraryBrain();
    }

    _savePlayHistory();
    if (mounted) setState(() {});
  }

  List<Map<String, String>> _brainAlbums() {
    _buildBasicLibraryBrain(save: false);

    final items = _albums.map((album) {
      final id = album['id'] ?? '';
      final brain = Map<String, String>.from(_libraryBrain[id] ?? <String, String>{});
      brain['albumId'] = id;
      brain['name'] = brain['name'] ?? album['name'] ?? 'Album';
      brain['displayName'] = brain['displayName'] ?? brain['name'] ?? 'Album';
      brain['cover'] = album['cover'] ?? brain['cover'] ?? '';
      brain['dateAdded'] = album['dateAdded'] ?? brain['dateAdded'] ?? '0';
      return brain;
    }).where((item) => (item['albumId'] ?? '').isNotEmpty).toList();

    return items;
  }

  Map<String, String>? _albumById(String id) {
    for (final album in _albums) {
      if ((album['id'] ?? '') == id) return album;
    }
    return null;
  }

  void _openAlbumByBrain(Map<String, String> info) {
    final id = info['albumId'] ?? '';
    final album = _albumById(id);
    if (album != null) _openAlbum(album);
  }

  List<Map<String, String>> _recentBrainAlbums({int limit = 8}) {
    final items = _brainAlbums()
      ..sort((a, b) => _brainInt(b, 'dateAdded').compareTo(_brainInt(a, 'dateAdded')));
    return items.take(limit).toList();
  }

  List<Map<String, String>> _lastPlayedAlbums({int limit = 8}) {
    final items = _brainAlbums().where((a) => _brainInt(a, 'lastPlayed') > 0).toList()
      ..sort((a, b) => _brainInt(b, 'lastPlayed').compareTo(_brainInt(a, 'lastPlayed')));
    return items.take(limit).toList();
  }

  List<Map<String, String>> _mostPlayedAlbums({int limit = 8}) {
    final items = _brainAlbums().where((a) => _brainInt(a, 'playCount') > 0).toList()
      ..sort((a, b) => _brainInt(b, 'playCount').compareTo(_brainInt(a, 'playCount')));
    return items.take(limit).toList();
  }

  List<Map<String, String>> _albumsForGenre(String genre, {int limit = 8}) {
    final items = _brainAlbums().where((a) => (a['genre'] ?? '') == genre).toList()
      ..sort((a, b) => _brainInt(b, 'dateAdded').compareTo(_brainInt(a, 'dateAdded')));
    return items.take(limit).toList();
  }

  List<Map<String, String>> _albumsForDecade(String decade, {int limit = 8}) {
    final items = _brainAlbums().where((a) => (a['decade'] ?? '') == decade).toList()
      ..sort((a, b) => (a['displayName'] ?? '').compareTo(b['displayName'] ?? ''));
    return items.take(limit).toList();
  }

  List<String> _topGenres({int limit = 3}) {
    final counts = <String, int>{};
    for (final album in _brainAlbums()) {
      final genre = album['genre'] ?? '';
      if (genre.isEmpty) continue;
      counts[genre] = (counts[genre] ?? 0) + 1;
    }
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.take(limit).map((e) => e.key).toList();
  }

  List<String> _topDecades({int limit = 3}) {
    final counts = <String, int>{};
    for (final album in _brainAlbums()) {
      final decade = album['decade'] ?? '';
      if (decade.isEmpty) continue;
      counts[decade] = (counts[decade] ?? 0) + 1;
    }
    final entries = counts.entries.toList()
      ..sort((a, b) => b.key.compareTo(a.key));
    return entries.take(limit).map((e) => e.key).toList();
  }

  List<Map<String, String>> _topArtists({int limit = 12}) {
    final counts = <String, int>{};
    for (final album in _brainAlbums()) {
      final artist = _cleanBrainValue(album['artist']);
      if (artist.isEmpty) continue;
      counts[artist] = (counts[artist] ?? 0) + 1;
    }

    final entries = counts.entries.toList()
      ..sort((a, b) {
        final byCount = b.value.compareTo(a.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      });

    return entries.take(limit).map((e) => {'artist': e.key, 'count': e.value.toString()}).toList();
  }

  Map<String, String>? _spotlightAlbum() {
    final played = _lastPlayedAlbums(limit: 1);
    if (played.isNotEmpty) return played.first;

    final recent = _recentBrainAlbums(limit: 12);
    if (recent.isEmpty) return null;

    final daySeed = DateTime.now().day + DateTime.now().month * 31;
    return recent[daySeed % recent.length];
  }


  Future<void> _rebuildSmartHomeIndex() async {
    _libraryBrain.clear();
    _buildBasicLibraryBrain(save: false);

    for (final album in _albums) {
      final tracks = _albumTracksCache[album['id'] ?? ''];
      if (tracks != null && tracks.isNotEmpty) {
        _indexAlbumFromTracks(album, tracks, save: false);
      }
    }

    await _saveLibraryBrain();
    await _persistAlbums();
    if (mounted) setState(() {});
    _showSuccess('Smart Home index rebuilt from cached metadata.');
  }

  void _startMetadataProgressPolling() {
    _metadataProgressPoller?.cancel();
    _metadataProgressPoller = Timer.periodic(const Duration(seconds: 1), (_) {
      _pollMetadataProgressSnapshot();
    });

    _pollMetadataProgressSnapshot();
  }

  Future<void> _pollMetadataProgressSnapshot() async {
    try {
      String? raw = await FlutterForegroundTask.getData<String>(key: _metadataProgressPrefsKey);

      if (raw == null || raw.isEmpty) {
        final prefs = await SharedPreferences.getInstance();
        raw = prefs.getString(_metadataProgressPrefsKey);
      }

      if (raw == null || raw.isEmpty) return;
      final decoded = json.decode(raw);
      if (decoded is Map) {
        final normalized = Map<String, dynamic>.from(decoded);

        // If Android killed the foreground task but the last saved progress
        // still says running, do not leave the UI stuck forever.
        if (normalized['running'] == true && Platform.isAndroid) {
          final serviceRunning = await FlutterForegroundTask.isRunningService;
          final updatedAt = (normalized['updatedAt'] as num?)?.toInt() ?? 0;
          final ageMs = DateTime.now().millisecondsSinceEpoch - updatedAt;

          if (!serviceRunning && updatedAt > 0 && ageMs > 8000) {
            normalized['running'] = false;
            normalized['phase'] = 'Stopped';
            normalized['updatedAt'] = DateTime.now().millisecondsSinceEpoch;
            _saveMetadataProgressSnapshot(normalized);
          }
        }

        _applyMetadataProgressData(normalized);
      }
    } catch (_) {}
  }

  void _applyMetadataProgressData(Map data) {
    if (!mounted) return;

    final stamp = (data['updatedAt'] as num?)?.toInt() ?? 0;
    if (stamp != 0 && stamp == _lastMetadataProgressStamp) return;
    if (stamp != 0) _lastMetadataProgressStamp = stamp;

    final wasRunning = _loadingMetadata;
    final running = data['running'] == true;

    final nextDone = (data['done'] as num?)?.toInt() ?? _metadataDone;
    final nextTotal = (data['total'] as num?)?.toInt() ?? _metadataTotal;
    final nextFast = (data['fast'] as num?)?.toInt() ?? _metadataFast;
    final nextDeep = (data['deep'] as num?)?.toInt() ?? _metadataDeep;
    final nextFailed = (data['failed'] as num?)?.toInt() ?? _metadataFailed;
    final nextPhase = (data['phase'] ?? _metadataPhase).toString();

    final changed = _loadingMetadata != running ||
        _metadataDone != nextDone ||
        _metadataTotal != nextTotal ||
        _metadataFast != nextFast ||
        _metadataDeep != nextDeep ||
        _metadataFailed != nextFailed ||
        _metadataPhase != nextPhase;

    if (!changed) return;

    setState(() {
      _loadingMetadata = running;
      _metadataDone = nextDone;
      _metadataTotal = nextTotal;
      _metadataFast = nextFast;
      _metadataDeep = nextDeep;
      _metadataFailed = nextFailed;
      _metadataPhase = nextPhase;
      if (running) _finalMetadataRefreshDone = false;
    });

    _settingsSheetSetState?.call(() {});

    if (wasRunning && !running && !_finalMetadataRefreshDone) {
      _finalMetadataRefreshDone = true;
      _metaStore.reload().then((_) {
        if (mounted) setState(() {});
      });
      _loadAlbums();
    }
  }

  Future<void> _requestForegroundMetadataPermissions() async {
    if (!Platform.isAndroid) return;

    final permission = await FlutterForegroundTask.checkNotificationPermission();
    if (permission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
  }

  void _initForegroundMetadataService() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'musix_metadata_scan',
        channelName: 'Musix metadata scan',
        channelDescription: 'Shows progress while Musix scans Google Drive music metadata.',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(3000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  void _onMetadataTaskData(Object data) {
    if (data is! Map) return;
    if (data['type'] != 'metadata_progress') return;
    _applyMetadataProgressData(data);
  }

  String _metadataStatusLabel({bool includeTapToCancel = false}) {
    if (!_loadingMetadata) {
      if (_metadataPhase == 'Complete' && _metadataTotal > 0) {
        return 'Last scan complete • $_metadataTotal tracks';
      }
      return 'Metadata scanner is idle';
    }

    if (_metadataTotal <= 0) {
      final phase = _metadataPhase.trim().isEmpty ? 'Preparing' : _metadataPhase;
      return '$phase metadata scan...';
    }

    final base =
        'Scanning metadata $_metadataDone/$_metadataTotal • Fast: $_metadataFast • Deep: $_metadataDeep • Failed: $_metadataFailed';
    return includeTapToCancel ? '$base — tap to cancel' : base;
  }

  String _glassModeLabel(String mode) {
    if (mode == glassModePerformance) return 'Performance';
    if (mode == glassModePretty) return 'Pretty';
    return 'Balanced';
  }

  String _glassModeDescription(String mode) {
    if (mode == glassModePerformance) {
      return 'Fastest mode. Fake glass only, lighter shadows, best for huge libraries.';
    }
    if (mode == glassModePretty) {
      return 'Most glassy mode. Real blur on fixed UI only, heavier glow, still avoids blur in lists.';
    }
    return 'Recommended. Real blur only on fixed UI like nav and player, fake glass in scrolling lists.';
  }

  void _cycleGlassMode([StateSetter? setSheetState]) {
    final next = _glassMode == glassModePerformance
        ? _glassModeBalanced
        : _glassMode == _glassModeBalanced
            ? glassModePretty
            : glassModePerformance;

    setState(() {
      _glassMode = next;
      glassModeNotifier.value = next;
    });
    setSheetState?.call(() {});
    _saveUiPreferences();
  }

  void _cycleAccentMode([StateSetter? setSheetState]) {
    final next = _accentMode == _accentModeChampagne
        ? _accentModeWhite
        : _accentMode == _accentModeWhite
            ? _accentModeBlue
            : _accentMode == _accentModeBlue
                ? _accentModePink
                : _accentModeChampagne;

    setState(() => _accentMode = next);
    setSheetState?.call(() {});
    _saveUiPreferences();
  }

  void _selectRootTab(int index, {bool animate = true}) {
    if (index < 0 || index > 2) return;

    setState(() {
      _navIndex = index;
      _viewingAlbum = null;
      _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
    });

    if (_pageController.hasClients) {
      if (animate) {
        _pageController.animateToPage(
          index,
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutCubic,
        );
      } else {
        _pageController.jumpToPage(index);
      }
    }

    if (index == 2 && _exploreItems.isEmpty && _exploreFolder == null) {
      _fetchExplore(folderId: 'root');
    }
  }

  void _openSettingsSheet() {
    final colors = _safeColors(_currentDynamicColors);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            _settingsSheetSetState = setSheetState;
            final accent = _appAccent;

            final progress = _metadataTotal > 0
                ? (_metadataDone / _metadataTotal).clamp(0.0, 1.0)
                : null;

            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
              child: Container(
                height: MediaQuery.of(sheetContext).size.height * 0.88,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.zero,
                  border: Border(top: BorderSide(color: Colors.white.withOpacity(0.12))),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      colors[0].withOpacity(0.22),
                      _bg.withOpacity(0.98),
                      Colors.black,
                    ],
                  ),
                ),
                child: SafeArea(
                  top: false,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
                        child: Row(
                          children: [
                            IconButton(
                              onPressed: () => Navigator.pop(sheetContext),
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                            ),
                            const Spacer(),
                            Text(
                              'Settings',
                              style: GoogleFonts.inter(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const Spacer(),
                            const SizedBox(width: 48),
                          ],
                        ),
                      ),
                      Expanded(
                        child: ListView(
                          physics: const BouncingScrollPhysics(),
                          padding: const EdgeInsets.fromLTRB(22, 10, 22, 28),
                          children: [
                            Text(
                              'Musix Control Center',
                              style: GoogleFonts.inter(
                                color: _textPri,
                                fontSize: 27,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.8,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Library tools, background metadata scanning, cache cleanup and safety controls live here now.',
                              style: GoogleFonts.inter(
                                color: _textSub,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                height: 1.45,
                              ),
                            ),
                            const SizedBox(height: 22),
                            GlassyContainer(
                              radius: 24,
                              padding: const EdgeInsets.all(16),
                              customColor: Colors.white.withOpacity(0.075),
                              customBorder: accent.withOpacity(0.22),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        _loadingMetadata
                                            ? Icons.sync_rounded
                                            : Icons.library_music_rounded,
                                        color: accent,
                                        size: 22,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          _metadataStatusLabel(),
                                          style: GoogleFonts.inter(
                                            color: _textPri,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w900,
                                            height: 1.35,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 14),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: LinearProgressIndicator(
                                      value: progress,
                                      minHeight: 6,
                                      backgroundColor: Colors.white.withOpacity(0.14),
                                      valueColor: AlwaysStoppedAnimation<Color>(accent),
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  Row(
                                    children: [
                                      _MetadataStat(label: 'Fast', value: _metadataFast),
                                      _MetadataStat(label: 'Deep', value: _metadataDeep),
                                      _MetadataStat(label: 'Failed', value: _metadataFailed),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _SettingsPrimaryButton(
                              label: _loadingMetadata ? 'Cancel metadata scan' : 'Scan whole library metadata',
                              icon: _loadingMetadata ? Icons.stop_rounded : Icons.sync_rounded,
                              accent: accent,
                              destructive: _loadingMetadata,
                              onTap: () {
                                if (_loadingMetadata) {
                                  _cancelForegroundMetadataScan();
                                } else {
                                  _startForegroundLibraryMetadataScan();
                                }
                                setSheetState(() {});
                              },
                            ),
                            const SizedBox(height: 24),
                            _SettingsSectionTitle(title: 'Library'),
                            _SettingsInfoCard(
                              icon: Icons.album_rounded,
                              title: '${_albums.length} albums saved',
                              subtitle: '${_metaStore.count} cached song metadata entries',
                              accent: accent,
                            ),
                            const SizedBox(height: 10),
                            _SettingsActionRow(
                              icon: Icons.restore_rounded,
                              title: 'Restore previous library',
                              subtitle: 'Recover the backup saved before clearing the app library.',
                              accent: accent,
                              onTap: _restoreLibraryBackup,
                            ),
                            _SettingsActionRow(
                              icon: Icons.refresh_rounded,
                              title: 'Rescan current Drive folder',
                              subtitle: _exploreFolder == null
                                  ? 'Open a folder in Search first, then scan it here.'
                                  : 'Scan "${_exploreFolder!.name ?? 'folder'}" into your library.',
                              accent: accent,
                              onTap: _exploreFolder == null || _isScanning
                                  ? null
                                  : () => _scanFolderToLibrary(_exploreFolder!),
                            ),
                            const SizedBox(height: 18),
                            _SettingsSectionTitle(title: 'Cache'),
                            _SettingsActionRow(
                              icon: Icons.tag_rounded,
                              title: 'Clear metadata cache',
                              subtitle: 'Forces titles, artists and albums to be scanned again.',
                              accent: accent,
                              onTap: _clearMetadataCacheSafely,
                            ),
                            _SettingsActionRow(
                              icon: Icons.image_not_supported_rounded,
                              title: 'Clear embedded cover cache',
                              subtitle: 'Removes local cover images saved by metadata scans.',
                              accent: accent,
                              onTap: _clearCoverCacheSafely,
                            ),
                            const SizedBox(height: 18),
                            _SettingsSectionTitle(title: 'Home Screen'),
                            _SettingsActionRow(
                              icon: Icons.auto_awesome_rounded,
                              title: 'Rebuild Smart Home index',
                              subtitle: 'Refreshes Home sections from cached metadata and opened albums.',
                              accent: accent,
                              onTap: _rebuildSmartHomeIndex,
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.history_rounded,
                              title: 'Continue listening',
                              subtitle: 'Show recent albums and recent tracks on Home.',
                              value: _homeShowContinue,
                              accent: colors[1],
                              onChanged: (value) {
                                setState(() => _homeShowContinue = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.category_rounded,
                              title: 'Genre shelves',
                              subtitle: 'Show Hip-Hop, Soul, Jazz and other shelves when tags exist.',
                              value: _homeShowGenres,
                              accent: colors[1],
                              onChanged: (value) {
                                setState(() => _homeShowGenres = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.calendar_month_rounded,
                              title: 'Decade shelves',
                              subtitle: 'Show 90s, 2000s and other year-based rows when metadata exists.',
                              value: _homeShowDecades,
                              accent: colors[1],
                              onChanged: (value) {
                                setState(() => _homeShowDecades = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.person_rounded,
                              title: 'Artist chips',
                              subtitle: 'Show a quick row of artists from cached metadata.',
                              value: _homeShowArtists,
                              accent: colors[1],
                              onChanged: (value) {
                                setState(() => _homeShowArtists = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.casino_rounded,
                              title: 'Discovery card',
                              subtitle: 'Show the random-library pick card.',
                              value: _homeShowDiscovery,
                              accent: colors[1],
                              onChanged: (value) {
                                setState(() => _homeShowDiscovery = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            const SizedBox(height: 18),
                            _SettingsSectionTitle(title: 'Performance'),
                            _SettingsActionRow(
                              icon: Icons.tune_rounded,
                              title: 'Glass mode: ${_glassModeLabel(_glassMode)}',
                              subtitle: _glassModeDescription(_glassMode),
                              accent: accent,
                              onTap: () => _cycleGlassMode(setSheetState),
                            ),
                            _SettingsSwitchRow(
                              icon: Icons.gradient_rounded,
                              title: 'Background glow',
                              subtitle: 'Soft mesh glow without list blur. Turn off only if page swipes still feel heavy.',
                              value: _showBackgroundGlow,
                              accent: accent,
                              onChanged: (value) {
                                setState(() => _showBackgroundGlow = value);
                                setSheetState(() {});
                                _saveUiPreferences();
                              },
                            ),
                            _SettingsInfoCard(
                              icon: Icons.speed_rounded,
                              title: 'Album opening optimized',
                              subtitle: 'Track lists are cached in memory, album colors are cached, and scrolling cards use fake glass.',
                              accent: accent,
                            ),
                            const SizedBox(height: 18),
                            _SettingsSectionTitle(title: 'Appearance'),
                            _SettingsActionRow(
                              icon: Icons.palette_rounded,
                              title: 'Accent color: ${_accentModeLabelForMode(_accentMode)}',
                              subtitle: 'Cycles White, Champagne, Soft Blue and Pink. No loud yellow.',
                              accent: accent,
                              onTap: () => _cycleAccentMode(setSheetState),
                            ),
                            const SizedBox(height: 10),
                            _SettingsInfoCard(
                              icon: Icons.auto_awesome_rounded,
                              title: 'Dark glass UI enabled',
                              subtitle: 'No rainbow headers. The app uses controlled glass, album-color glow, and cheaper scrolling cards.',
                              accent: accent,
                            ),
                            const SizedBox(height: 18),
                            _SettingsSectionTitle(title: 'Danger Zone'),
                            _SettingsActionRow(
                              icon: Icons.delete_outline_rounded,
                              title: 'Clear app library cache',
                              subtitle: 'Does not touch Google Drive files. Requires typing CLEAR.',
                              accent: Colors.redAccent,
                              destructive: true,
                              onTap: _clearLibraryCacheSafely,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      _settingsSheetSetState = null;
    });
  }

  Future<void> _startForegroundLibraryMetadataScan() async {
    if (_user == null || _albums.isEmpty || _loadingMetadata) return;

    final authHeaders = await _user!.authHeaders;
    final bearer = authHeaders['Authorization'] ?? authHeaders['authorization'] ?? '';
    if (!bearer.startsWith('Bearer ')) {
      _showError('Could not get Google token.');
      return;
    }

    final token = bearer.substring(7);

    await FlutterForegroundTask.saveData(key: 'metadata_token', value: token);
    await FlutterForegroundTask.saveData(key: 'metadata_albums', value: json.encode(_albums));

    final startingPayload = {
      'type': 'metadata_progress',
      'done': 0,
      'total': 0,
      'fast': 0,
      'deep': 0,
      'failed': 0,
      'phase': 'Starting',
      'running': true,
      'updatedAt': DateTime.now().millisecondsSinceEpoch,
    };
    _saveMetadataProgressSnapshot(startingPayload);

    setState(() {
      _loadingMetadata = true;
      _metadataDone = 0;
      _metadataTotal = 0;
      _metadataFast = 0;
      _metadataDeep = 0;
      _metadataFailed = 0;
      _metadataPhase = 'Starting';
      _finalMetadataRefreshDone = false;
    });
    _settingsSheetSetState?.call(() {});

    if (await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
      await Future.delayed(const Duration(milliseconds: 350));
    }

    final result = await FlutterForegroundTask.startService(
      serviceId: _metadataScanServiceId,
      serviceTypes: [ForegroundServiceTypes.dataSync],
      notificationTitle: 'Musix metadata scan',
      notificationText: 'Starting metadata scan...',
      notificationInitialRoute: '/',
      callback: metadataScanStartCallback,
    );

    if (result is ServiceRequestFailure) {
      if (mounted) {
        setState(() => _loadingMetadata = false);
        _showError('Could not start metadata service: ${result.error}');
      }
      return;
    }
  }

  Future<void> _cancelForegroundMetadataScan() async {
    if (!_loadingMetadata && !(await FlutterForegroundTask.isRunningService)) return;

    setState(() {
      _loadingMetadata = false;
      _metadataPhase = 'Cancelled';
    });
    _settingsSheetSetState?.call(() {});

    final cancelledPayload = {
      'type': 'metadata_progress',
      'done': _metadataDone,
      'total': _metadataTotal,
      'fast': _metadataFast,
      'deep': _metadataDeep,
      'failed': _metadataFailed,
      'phase': 'Cancelled',
      'running': false,
      'updatedAt': DateTime.now().millisecondsSinceEpoch,
    };
    _saveMetadataProgressSnapshot(cancelledPayload);

    // Ask the task to stop cleanly first, then force-stop the foreground
    // service. This makes the Settings cancel button work even if the task is
    // busy in a Drive request and does not receive the cancel command quickly.
    FlutterForegroundTask.sendDataToTask('cancel_metadata_scan');
    await Future.delayed(const Duration(milliseconds: 450));

    if (await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
    }

    _metaStore.reload().then((_) {
      if (mounted) setState(() {});
    });
    _loadAlbums();
  }

  // ── Auth ──────────────────────────────────────────────────────────────────
  Future<void> _trySilentSignIn() async {
    final account = await _googleSignIn.signInSilently();

    if (!mounted) return;

    if (account != null) {
      setState(() => _user = account);
      await _loadAlbums();
    } else {
      setState(() => _loadingSaved = false);
    }
  }

  Future<void> _signIn() async {
    if (_signingIn) return;

    setState(() => _signingIn = true);

    try {
      await _googleSignIn.signOut();
      final account = await _googleSignIn.signIn();

      if (!mounted) return;

      if (account != null) {
        setState(() => _user = account);
        await _loadAlbums();
      }
    } catch (e) {
      _showError('Sign-in failed: $e');
    } finally {
      if (mounted) setState(() => _signingIn = false);
    }
  }

  Future<void> _signOut() async {
    await _googleSignIn.signOut();
    await _player.stop();
    if (_pageController.hasClients) {
      _pageController.jumpToPage(0);
    }

    _nowPlaying.setTrack(
      drive.File()..name = '',
      [],
      -1,
      coverUrl: null,
      colors: _defaultDynamicColors,
    );
    _nowPlaying.track = null;
    _nowPlaying.refresh();

    if (!mounted) return;

    setState(() {
      _user = null;
      _albums = [];
      _navIndex = 0;
      _viewingAlbum = null;
      _albumTracks = [];
      _albumTracksCache.clear();
      _exploreFolder = null;
      _exploreItems = [];
      _navStack.clear();
      _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
    });
  }

  // ── Local Database ─────────────────────────────────────────────────────────
  Future<void> _loadAlbums() async {
    setState(() => _loadingSaved = true);

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_albumsKey);
    final now = DateTime.now().millisecondsSinceEpoch.toString();

    if (!mounted) return;

    var changed = false;
    final loadedAlbums = raw != null
        ? List<Map<String, String>>.from(
            (json.decode(raw) as List).map((e) => Map<String, String>.from(e)),
          )
        : <Map<String, String>>[];

    for (final album in loadedAlbums) {
      if ((album['dateAdded'] ?? '').isEmpty) {
        album['dateAdded'] = now;
        changed = true;
      }
    }

    setState(() {
      _albums = loadedAlbums;
      _loadingSaved = false;
    });

    _buildBasicLibraryBrain(save: true);
    if (changed) await _persistAlbums();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _precacheAlbumCovers(limit: 36);
    });
  }

  void _precacheAlbumCovers({int limit = 36}) {
    final candidates = _albums
        .map((album) => album['cover'] ?? '')
        .where((cover) => cover.isNotEmpty)
        .take(limit);

    for (final cover in candidates) {
      final provider = _coverProvider(cover);
      if (provider != null) {
        precacheImage(provider, context).catchError((_) {});
      }
    }
  }

  Future<void> _persistAlbums() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_albumsKey, json.encode(_albums));
  }

  String _audioExtension(drive.File file) {
    final name = file.name ?? 'track.mp3';
    final dot = name.lastIndexOf('.');
    if (dot == -1) return '.mp3';
    return name.substring(dot).toLowerCase();
  }

  String _safeCacheName(String id) {
    return id
        .replaceAll('/', '_')
        .replaceAll(':', '_')
        .replaceAll('?', '_')
        .replaceAll('&', '_')
        .replaceAll('=', '_');
  }

  Future<File> _downloadTrackToTemp(String fileId, String token, String extension) async {
    final dir = await getTemporaryDirectory();
    final unique = DateTime.now().microsecondsSinceEpoch;
    final path = '${dir.path}/musix_meta_${_safeCacheName(fileId)}_$unique$extension';
    final tempFile = File(path);

    final uri = Uri.parse('https://www.googleapis.com/drive/v3/files/$fileId?alt=media');
    final client = http.Client();

    try {
      final request = http.Request('GET', uri)
        ..headers.addAll({
          'Authorization': 'Bearer $token',
          'User-Agent': 'MusixApp/1.0',
        })
        ..followRedirects = false;

      final response = await client.send(request);
      http.StreamedResponse finalResponse = response;

      if (response.isRedirect && response.headers.containsKey('location')) {
        final redirectUri = Uri.parse(response.headers['location']!);
        final secondRequest = http.Request('GET', redirectUri);
        finalResponse = await client.send(secondRequest);
      }

      if (finalResponse.statusCode != 200 && finalResponse.statusCode != 206) {
        throw Exception('Could not download metadata file: ${finalResponse.statusCode}');
      }

      final sink = tempFile.openWrite();
      await finalResponse.stream.pipe(sink);
      return tempFile;
    } finally {
      client.close();
    }
  }

  String _coverExtensionFromBytes(Uint8List bytes) {
    if (bytes.length >= 8 &&
        bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4E &&
        bytes[3] == 0x47) {
      return '.png';
    }

    if (bytes.length >= 3 &&
        bytes[0] == 0xFF &&
        bytes[1] == 0xD8 &&
        bytes[2] == 0xFF) {
      return '.jpg';
    }

    if (bytes.length >= 12 &&
        bytes[8] == 0x57 &&
        bytes[9] == 0x45 &&
        bytes[10] == 0x42 &&
        bytes[11] == 0x50) {
      return '.webp';
    }

    return '.jpg';
  }

  Future<String?> _saveEmbeddedCover(drive.File file, Uint8List bytes) async {
    final fileId = DriveUtils.effectiveId(file);
    if (fileId == null || bytes.isEmpty) return null;

    try {
      final dir = await getApplicationDocumentsDirectory();
      final coverDir = Directory('${dir.path}/musix_embedded_covers');
      if (!await coverDir.exists()) {
        await coverDir.create(recursive: true);
      }

      final ext = _coverExtensionFromBytes(bytes);
      final path = '${coverDir.path}/${_safeCacheName(fileId)}$ext';
      final out = File(path);
      await out.writeAsBytes(bytes, flush: true);
      return 'file://$path';
    } catch (_) {
      return null;
    }
  }

  void _applyEmbeddedCoverToAlbum(
    drive.File file,
    String coverPath, {
    Map<String, String>? albumRecord,
  }) {
    final fileId = DriveUtils.effectiveId(file);
    bool changed = false;

    void applyToAlbum(Map<String, String> album) {
      album['cover'] = coverPath;
      changed = true;
    }

    if (albumRecord != null) {
      final albumId = albumRecord['id'];
      for (final album in _albums) {
        if (album['id'] == albumId) {
          applyToAlbum(album);
          break;
        }
      }

      if (_viewingAlbum != null && _viewingAlbum!['id'] == albumId) {
        _viewingAlbum!['cover'] = coverPath;
        changed = true;
      }
    } else if (_viewingAlbum != null && fileId != null) {
      final inCurrentAlbum = _albumTracks.any((track) => DriveUtils.effectiveId(track) == fileId);
      if (inCurrentAlbum) {
        _viewingAlbum!['cover'] = coverPath;
        for (final album in _albums) {
          if (album['id'] == _viewingAlbum!['id']) {
            album['cover'] = coverPath;
            break;
          }
        }
        changed = true;
      }
    }

    if (_nowPlaying.track != null && fileId != null) {
      final activeId = DriveUtils.effectiveId(_nowPlaying.track!);
      if (activeId == fileId) {
        _nowPlaying.currentCoverUrl = coverPath;
        _nowPlaying.refresh();
      }
    }

    if (changed) {
      _persistAlbums();
      if (mounted) setState(() {});
    }
  }

  Future<void> _loadMetadataFor(
    drive.File file,
    String token, {
    Map<String, String>? albumRecord,
  }) async {
    final fileId = DriveUtils.effectiveId(file);
    if (fileId == null) return;
    if (_metaStore.peekFresh(file) != null) return;

    File? tempFile;

    try {
      final fallback = DriveUtils.getTrackMeta(file);
      TrackReadResult? fastResult = await FastTagReader.read(file: file, token: token);
      String? embeddedCoverPath;

      if (fastResult?.coverBytes != null) {
        embeddedCoverPath = await _saveEmbeddedCover(file, fastResult!.coverBytes!);
        if (embeddedCoverPath != null) {
          _applyEmbeddedCoverToAlbum(file, embeddedCoverPath, albumRecord: albumRecord);
        }
      }

      if (fastResult != null && fastResult.hasUsefulText) {
        await _metaStore.put(
          file,
          TrackMetadata(
            title: fastResult.title?.trim().isNotEmpty == true
                ? fastResult.title!.trim()
                : fallback['title'] ?? file.name ?? 'Unknown',
            artist: fastResult.artist?.trim().isNotEmpty == true
                ? fastResult.artist!.trim()
                : fallback['artist'] ?? 'Unknown Artist',
            album: fastResult.album?.trim().isNotEmpty == true ? fastResult.album!.trim() : null,
            year: fastResult.year,
            genre: fastResult.genre,
            trackNumber: fastResult.trackNumber,
            discNumber: fastResult.discNumber,
            coverPath: embeddedCoverPath,
            modifiedTime: file.modifiedTime?.toIso8601String(),
            size: file.size,
          ),
        );

        _nowPlaying.refresh();
        if (mounted) setState(() {});
        return;
      }

      tempFile = await _downloadTrackToTemp(fileId, token, _audioExtension(file));
      final metadata = readMetadata(tempFile, getImage: false);

      final title = metadata.title?.trim().isNotEmpty == true
          ? metadata.title!.trim()
          : fallback['title'] ?? file.name ?? 'Unknown';

      final artist = metadata.artist?.trim().isNotEmpty == true
          ? metadata.artist!.trim()
          : fallback['artist'] ?? 'Unknown Artist';

      final album = metadata.album?.trim().isNotEmpty == true ? metadata.album!.trim() : null;

      await _metaStore.put(
        file,
        TrackMetadata(
          title: title,
          artist: artist,
          album: album,
          year: null,
          genre: null,
          trackNumber: metadata.trackNumber,
          discNumber: metadata.discNumber,
          coverPath: embeddedCoverPath,
          modifiedTime: file.modifiedTime?.toIso8601String(),
          size: file.size,
        ),
      );

      _nowPlaying.refresh();
      if (mounted) setState(() {});
    } catch (_) {
      return;
    } finally {
      try {
        if (tempFile != null && await tempFile.exists()) {
          await tempFile.delete();
        }
      } catch (_) {}
    }
  }

  Future<void> _prefetchMetadataForTracks(List<drive.File> tracks) async {
    if (_user == null || tracks.isEmpty) return;

    try {
      final authHeaders = await _user!.authHeaders;
      final bearer = authHeaders['Authorization'] ?? authHeaders['authorization'] ?? '';
      if (!bearer.startsWith('Bearer ')) return;
      final token = bearer.substring(7);

      const batchSize = 2;

      for (int i = 0; i < tracks.length; i += batchSize) {
        if (!mounted) return;

        final batch = tracks.skip(i).take(batchSize).toList();
        await Future.wait(batch.map((track) => _loadMetadataFor(track, token)));
      }
    } catch (_) {
      return;
    }
  }

  Future<void> _loadMetadataForCurrentAlbum() async {
    if (_user == null || _albumTracks.isEmpty || _albumMetadataLoading) return;

    if (_loadingMetadata) {
      _showError('Library metadata scan is already running. Cancel it in Settings first.');
      return;
    }

    final missing = _albumTracks.where((track) => _metaStore.peekFresh(track) == null).toList();

    if (missing.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Metadata is already loaded for this album.',
            style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
          ),
          backgroundColor: _accentDefault,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() {
      _albumMetadataLoading = true;
      _albumMetadataDone = 0;
      _albumMetadataTotal = missing.length;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Loading metadata for this album...',
          style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
        ),
        backgroundColor: _accentDefault,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );

    try {
      final authHeaders = await _user!.authHeaders;
      final bearer = authHeaders['Authorization'] ?? authHeaders['authorization'] ?? '';
      if (!bearer.startsWith('Bearer ')) {
        throw Exception('Could not get Google token.');
      }

      final token = bearer.substring(7);
      const batchSize = 2;

      for (int i = 0; i < missing.length; i += batchSize) {
        if (!mounted) return;

        final batch = missing.skip(i).take(batchSize).toList();

        await Future.wait(
          batch.map((track) async {
            await _loadMetadataFor(track, token, albumRecord: _viewingAlbum);
            if (mounted) {
              setState(() => _albumMetadataDone++);
            }
          }),
        );
      }

      if (!mounted) return;

      if (_viewingAlbum != null) {
        _indexAlbumFromTracks(_viewingAlbum!, _albumTracks, save: true);
      }

      setState(() => _albumMetadataLoading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Metadata loaded and cached for ${missing.length} tracks.',
            style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
          ),
          backgroundColor: _accentDefault,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (mounted) {
        setState(() => _albumMetadataLoading = false);
        _showError('Metadata load failed: $e');
      }
    }
  }

  Future<void> _loadMetadataForEntireLibrary() async {
    if (_user == null || _albums.isEmpty || _loadingMetadata) return;

    setState(() {
      _loadingMetadata = true;
      _metadataDone = 0;
      _metadataTotal = 0;
    });

    try {
      final authHeaders = await _user!.authHeaders;
      final bearer = authHeaders['Authorization'] ?? authHeaders['authorization'] ?? '';
      if (!bearer.startsWith('Bearer ')) {
        throw Exception('Could not get Google token.');
      }

      final token = bearer.substring(7);
      final api = drive.DriveApi(GoogleAuthClient(authHeaders));
      final Map<String, drive.File> uniqueTracks = {};
      final Map<String, Map<String, String>> trackAlbums = {};

      for (final album in _albums) {
        if (!mounted) return;
        final tracks = await _fetchTracksForAlbumRecord(api, album);

        for (final track in tracks) {
          final id = DriveUtils.effectiveId(track);
          if (id != null) {
            uniqueTracks[id] = track;
            trackAlbums[id] = album;
          }
        }
      }

      final missing = uniqueTracks.values
          .where((track) => _metaStore.peekFresh(track) == null)
          .toList()
        ..sort((a, b) => (a.name ?? '').compareTo(b.name ?? ''));

      if (!mounted) return;

      if (missing.isEmpty) {
        setState(() => _loadingMetadata = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Metadata is already loaded for your whole library.',
              style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
            ),
            backgroundColor: _accentDefault,
            behavior: SnackBarBehavior.floating,
          ),
        );
        return;
      }

      setState(() {
        _metadataTotal = missing.length;
        _metadataDone = 0;
      });

      const batchSize = 2;

      for (int i = 0; i < missing.length; i += batchSize) {
        if (!mounted) return;

        final batch = missing.skip(i).take(batchSize).toList();

        await Future.wait(
          batch.map((track) async {
            final id = DriveUtils.effectiveId(track);
            await _loadMetadataFor(
              track,
              token,
              albumRecord: id == null ? null : trackAlbums[id],
            );
            if (mounted) {
              setState(() => _metadataDone++);
            }
          }),
        );
      }

      if (!mounted) return;

      setState(() => _loadingMetadata = false);
      await _persistAlbums();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Metadata loaded and cached for ' + missing.length.toString() + ' library tracks.',
            style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
          ),
          backgroundColor: _accentDefault,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (mounted) {
        setState(() => _loadingMetadata = false);
        _showError('Library metadata load failed: ' + e.toString());
      }
    }
  }

  Future<void> _backupLibraryCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_albumsBackupPrefsKey, json.encode(_albums));
  }

  Future<void> _restoreLibraryBackup() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_albumsBackupPrefsKey);

    if (raw == null || raw.isEmpty) {
      _showError('No library backup found yet.');
      return;
    }

    try {
      final restored = List<Map<String, String>>.from(
        (json.decode(raw) as List).map((e) => Map<String, String>.from(e)),
      );

      setState(() {
        _albums = restored..sort((a, b) => (a['name'] ?? '').compareTo(b['name'] ?? ''));
        _viewingAlbum = null;
        _albumTracks = [];
      });

      _buildBasicLibraryBrain(save: false);
      await _persistAlbums();
      await _saveLibraryBrain();
      _showSuccess('Previous library restored.');
    } catch (e) {
      _showError('Could not restore library backup: $e');
    }
  }

  Future<bool> _confirmDangerAction({
    required String title,
    required String body,
    required String confirmText,
  }) async {
    final controller = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF181820),
          surfaceTintColor: Colors.transparent,
          title: Text(
            title,
            style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w900),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                body,
                style: GoogleFonts.inter(color: _textSub, height: 1.45, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 16),
              Text(
                'Type $confirmText to continue.',
                style: GoogleFonts.inter(color: _textPri, fontSize: 13, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: controller,
                autofocus: true,
                style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w800),
                decoration: InputDecoration(
                  hintText: confirmText,
                  hintStyle: GoogleFonts.inter(color: _textSub.withOpacity(0.6)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.07),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: _accentDefault),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text('Cancel', style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w800)),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, controller.text.trim() == confirmText);
              },
              child: Text('Confirm', style: GoogleFonts.inter(color: _accentDefault, fontWeight: FontWeight.w900)),
            ),
          ],
        );
      },
    );

    controller.dispose();
    return result == true;
  }

  Future<void> _clearLibraryCacheSafely() async {
    if (_albums.isEmpty) {
      _showSuccess('Library cache is already empty.');
      return;
    }

    final confirmed = await _confirmDangerAction(
      title: 'Clear app library cache?',
      body: 'This does NOT delete anything from Google Drive. It only removes the albums saved inside Musix. A backup will be saved first so you can restore it from Settings.',
      confirmText: 'CLEAR',
    );

    if (!confirmed) return;

    await _backupLibraryCache();

    setState(() {
      _albums.clear();
      _viewingAlbum = null;
      _albumTracks.clear();
      _albumTracksCache.clear();
      _libraryBrain.clear();
      _playHistory.clear();
      _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
    });

    await _persistAlbums();
    await _saveLibraryBrain();
    await _savePlayHistory();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Library cache cleared. Your Drive files are untouched.',
          style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w900),
        ),
        backgroundColor: _accentDefault,
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'RESTORE',
          textColor: Colors.black,
          onPressed: _restoreLibraryBackup,
        ),
      ),
    );
  }

  Future<void> _clearMetadataCacheSafely() async {
    final confirmed = await _confirmDangerAction(
      title: 'Clear metadata cache?',
      body: 'Song titles, artists, album metadata and cached scan results will be removed. Your Drive music files stay untouched.',
      confirmText: 'CLEAR',
    );

    if (!confirmed) return;

    await _metaStore.clear();
    for (final album in _albums) {
      album.remove('displayName');
      album.remove('artist');
      album.remove('year');
      album.remove('genre');
      album.remove('trackCount');
    }
    _libraryBrain.clear();
    _buildBasicLibraryBrain(save: false);
    await _persistAlbums();
    await _saveLibraryBrain();
    _nowPlaying.refresh();
    if (mounted) setState(() {});
    _showSuccess('Metadata cache cleared.');
  }

  Future<void> _clearCoverCacheSafely() async {
    final confirmed = await _confirmDangerAction(
      title: 'Clear embedded cover cache?',
      body: 'This removes locally saved embedded album covers. Your Drive files stay untouched, and covers can be regenerated by scanning metadata again.',
      confirmText: 'CLEAR',
    );

    if (!confirmed) return;

    try {
      final dir = await getApplicationDocumentsDirectory();
      final coverDir = Directory('${dir.path}/musix_embedded_covers');
      if (await coverDir.exists()) {
        await coverDir.delete(recursive: true);
      }

      for (final album in _albums) {
        if (_isLocalCover(album['cover'])) {
          album['cover'] = '';
        }
      }

      await _persistAlbums();
      if (mounted) setState(() {});
      _showSuccess('Cover cache cleared.');
    } catch (e) {
      _showError('Could not clear cover cache: $e');
    }
  }

  Future<void> _removeCurrentAlbumFromLibrary() async {
    final album = _viewingAlbum;
    if (album == null) return;

    final confirmed = await _confirmDangerAction(
      title: 'Remove album from Musix?',
      body: 'This only removes the album from the app library cache. It does not delete the folder or songs from Google Drive.',
      confirmText: 'REMOVE',
    );

    if (!confirmed) return;

    await _backupLibraryCache();
    final id = album['id'];

    setState(() {
      _albums.removeWhere((a) => a['id'] == id);
      if (id != null) _libraryBrain.remove(id);
      _playHistory.removeWhere((item) => item['albumId'] == id);
      _viewingAlbum = null;
      _albumTracks = [];
      _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
    });

    await _persistAlbums();
    await _saveLibraryBrain();
    await _savePlayHistory();
    _showSuccess('Album removed from app library. Drive files are untouched.');
  }

  Future<void> _refreshCurrentAlbumCover() async {
    final album = _viewingAlbum;
    if (album == null) return;

    final albumName = album['name'] ?? 'Unknown Album';
    String artist = 'Unknown Artist';
    if (_albumTracks.isNotEmpty) {
      artist = DriveUtils.getTrackMeta(_albumTracks.first)['artist'] ?? 'Unknown Artist';
    }

    _showSuccess('Searching for a fresh cover...');
    final fetched = await _fetchCoverArt(albumName, artist);
    if (fetched == null || fetched.isEmpty) {
      _showError('No new cover found. Try loading album metadata first.');
      return;
    }

    setState(() {
      album['cover'] = fetched;
      for (final savedAlbum in _albums) {
        if (savedAlbum['id'] == album['id']) {
          savedAlbum['cover'] = fetched;
          break;
        }
      }
    });

    await _persistAlbums();
    await _extractAlbumColors(fetched, albumName);
    _showSuccess('Album cover refreshed.');
  }

  Future<void> _shuffleLibrary() async {
    if (_user == null || _albums.isEmpty) return;

    try {
      final authHeaders = await _user!.authHeaders;
      final api = drive.DriveApi(GoogleAuthClient(authHeaders));
      final random = math.Random();
      final albums = List<Map<String, String>>.from(_albums)..shuffle(random);

      for (final album in albums) {
        final tracks = await _fetchTracksForAlbumRecord(api, album);
        if (tracks.isEmpty) continue;

        final trackIndex = random.nextInt(tracks.length);
        final coverUrl = album['cover'];
        final colors = coverUrl != null && coverUrl.isNotEmpty
            ? getAlbumGradient(album['name'] ?? '')
            : getAlbumGradient(album['name'] ?? '');

        await _playSong(
          tracks[trackIndex],
          queue: tracks,
          idx: trackIndex,
          coverUrl: coverUrl,
          colors: colors,
        );
        return;
      }

      _showError('No playable tracks found in your library.');
    } catch (e) {
      _showError('Could not shuffle library: $e');
    }
  }

  Future<void> _clearLibrary() async {
    await _clearLibraryCacheSafely();
  }

  void _showSuccess(String msg) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w900)),
        backgroundColor: _accentDefault,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ── Cover Art Fetcher ─────────────────────────────────────────────────────
  Future<String?> _fetchCoverArt(String albumName, String artistName) async {
    String cleanAlbum = albumName
        .replaceAll(RegExp(r'\[.*?\]|\(.*?\)|(19|20)\d{2}'), '')
        .trim();

    if (cleanAlbum.isEmpty) cleanAlbum = albumName;

    final query = artistName != 'Unknown Artist'
        ? '$cleanAlbum $artistName'
        : cleanAlbum;

    try {
      final mbUrl = Uri.parse(
        'https://musicbrainz.org/ws/2/release-group/?query=${Uri.encodeComponent(query)}&fmt=json',
      );

      final mbRes = await http.get(
        mbUrl,
        headers: {'User-Agent': 'MusixApp/1.0'},
      );

      if (mbRes.statusCode != 200) return null;

      final data = json.decode(mbRes.body);
      final groups = data['release-groups'];
      if (groups == null || groups is! List || groups.isEmpty) return null;

      final limit = groups.length < 3 ? groups.length : 3;

      for (int i = 0; i < limit; i++) {
        final mbid = groups[i]['id'];
        if (mbid == null) continue;

        final caaUrl = Uri.parse('https://coverartarchive.org/release-group/$mbid');
        final caaRes = await http.get(
          caaUrl,
          headers: {'Accept': 'application/json'},
        );

        if (caaRes.statusCode == 200) {
          final caaData = json.decode(caaRes.body);
          final images = caaData['images'];

          if (images != null && images is List && images.isNotEmpty) {
            final image = images[0]['image'];
            if (image is String && image.isNotEmpty) return image;
          }
        }
      }
    } catch (_) {
      return null;
    }

    return null;
  }

  // ── Library Scanner ───────────────────────────────────────────────────────
  Future<void> _scanFolderToLibrary(drive.File rootFolder) async {
    if (_user == null || DriveUtils.effectiveId(rootFolder) == null) return;

    setState(() => _isScanning = true);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Scanning Drive and building album covers...',
          style: GoogleFonts.inter(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        backgroundColor: _pink,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 4),
      ),
    );

    try {
      final headers = await _user!.authHeaders;
      final api = drive.DriveApi(GoogleAuthClient(headers));

      final Map<String, Map<String, String>> discoveredMap = {};

      await _crawlDirectory(
        api,
        DriveUtils.effectiveId(rootFolder)!,
        rootFolder.name ?? 'Unknown',
        discoveredMap,
      );

      final discovered = discoveredMap.values.toList();

      if (!mounted) return;

      if (discovered.isEmpty) {
        setState(() => _isScanning = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No audio files found.', style: TextStyle(color: Colors.white)),
            backgroundColor: Colors.redAccent,
            behavior: SnackBarBehavior.floating,
          ),
        );
        return;
      }

      final uniqueAlbums = <String, Map<String, String>>{};
      for (final a in _albums) {
        uniqueAlbums[a['id']!] = a;
      }
      for (final a in discovered) {
        final id = a['id']!;
        final existing = uniqueAlbums[id];
        if (existing != null) {
          a['dateAdded'] = existing['dateAdded'] ?? a['dateAdded'] ?? DateTime.now().millisecondsSinceEpoch.toString();
          if ((a['cover'] ?? '').isEmpty && (existing['cover'] ?? '').isNotEmpty) {
            a['cover'] = existing['cover']!;
          }
        }
        uniqueAlbums[id] = a;
      }

      setState(() {
        _albums = uniqueAlbums.values.toList()
          ..sort((a, b) => (a['name'] ?? '').compareTo(b['name'] ?? ''));
        _albumTracksCache.clear();
        _isScanning = false;
      });

      _buildBasicLibraryBrain(save: false);
      await _persistAlbums();
      await _saveLibraryBrain();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Scan complete! Found ${discovered.length} albums.',
            style: GoogleFonts.inter(color: Colors.black, fontWeight: FontWeight.w800),
          ),
          backgroundColor: _accentDefault,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (e.toString().contains('401')) {
        _showError('Session expired. Sign out and sign back in.');
      } else {
        _showError('Scan failed: $e');
      }

      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _crawlDirectory(
    drive.DriveApi api,
    String folderId,
    String folderName,
    Map<String, Map<String, String>> discovered,
  ) async {
    String? pageToken;
    bool containsAudio = false;
    String? localCoverUrl;
    String? firstArtistFound;
    final List<drive.File> subFolders = [];

    do {
      final res = await api.files.list(
        q: "'$folderId' in parents and trashed = false",
        $fields:
            'files(id,name,mimeType,thumbnailLink,shortcutDetails(targetId,targetMimeType)),nextPageToken',
        pageSize: 100,
        pageToken: pageToken,
        supportsAllDrives: true,
        includeItemsFromAllDrives: true,
      );

      final files = res.files ?? <drive.File>[];

      for (final f in files) {
        if (DriveUtils.isAudio(f)) {
          containsAudio = true;
          firstArtistFound ??= DriveUtils.getTrackMeta(f)['artist'];
        } else if (DriveUtils.isFolder(f)) {
          subFolders.add(f);
        } else if (DriveUtils.effectiveMimeType(f)?.startsWith('image/') == true) {
          localCoverUrl ??= f.thumbnailLink;
        }
      }

      pageToken = res.nextPageToken;
    } while (pageToken != null);

    if (containsAudio) {
      final baseAlbumName = folderName
          .replaceAll(
            RegExp(
              r'[\s\-\(\[\]]*(disc|cd)\.?\s*\d+[\s\-\)\[\]]*',
              caseSensitive: false,
            ),
            '',
          )
          .trim();

      String finalCover = localCoverUrl ?? '';

      if (discovered.containsKey(baseAlbumName)) {
        discovered[baseAlbumName]!['id'] =
            '${discovered[baseAlbumName]!['id']!},$folderId';

        if (discovered[baseAlbumName]!['cover']!.isEmpty && finalCover.isNotEmpty) {
          discovered[baseAlbumName]!['cover'] = finalCover;
        }
      } else {
        // Do not call online cover APIs while crawling Drive. That made the
        // first library scan feel much slower, and embedded album art is the
        // preferred source anyway. The manual "Refresh cover" action still
        // uses online lookup as a fallback when needed.

        discovered[baseAlbumName] = {
          'id': folderId,
          'name': baseAlbumName.isEmpty ? folderName : baseAlbumName,
          'cover': finalCover,
          'dateAdded': DateTime.now().millisecondsSinceEpoch.toString(),
        };
      }
    }

    for (final sub in subFolders) {
      final subId = DriveUtils.effectiveId(sub);
      if (subId != null) {
        await _crawlDirectory(api, subId, sub.name ?? 'Unknown', discovered);
      }
    }
  }

  Future<void> _extractAlbumColors(
    String coverUrl,
    String albumName, {
    String? cacheKey,
  }) async {
    final fallback = getAlbumGradient(albumName);
    final key = cacheKey?.trim().isNotEmpty == true ? cacheKey!.trim() : albumName;

    final cached = _albumColorCache[key];
    if (cached != null && cached.length >= 4) {
      if (mounted) setState(() => _currentDynamicColors = cached);
      return;
    }

    if (coverUrl.isEmpty) {
      _albumColorCache[key] = fallback;
      _saveAlbumColorCache();
      if (mounted) setState(() => _currentDynamicColors = fallback);
      return;
    }

    try {
      final provider = _coverProvider(coverUrl);
      if (provider == null) throw Exception('Missing cover provider');

      final palette = await PaletteGenerator.fromImageProvider(
        provider,
        maximumColorCount: 12,
      );

      final extracted = [
        palette.dominantColor?.color ?? fallback[0],
        palette.vibrantColor?.color ?? fallback[1],
        palette.lightVibrantColor?.color ?? fallback[2],
        palette.darkMutedColor?.color ?? fallback[3],
      ];

      _albumColorCache[key] = extracted;
      _saveAlbumColorCache();

      if (!mounted) return;
      setState(() => _currentDynamicColors = extracted);
    } catch (_) {
      _albumColorCache[key] = fallback;
      _saveAlbumColorCache();
      if (mounted) setState(() => _currentDynamicColors = fallback);
    }
  }

  // ── Album View Logic ──────────────────────────────────────────────────────
  Future<void> _openAlbum(Map<String, String> album) async {
    final albumId = album['id'] ?? album['name'] ?? '';
    final albumName = album['name'] ?? 'Unknown Album';
    final cachedTracks = _albumTracksCache[albumId];
    final cachedColors = _albumColorCache[albumId];

    setState(() {
      _viewingAlbum = album;
      _loadingAlbum = cachedTracks == null;
      _albumTracks = cachedTracks ?? <drive.File>[];
      _albumMetadataLoading = false;
      _albumMetadataDone = 0;
      _albumMetadataTotal = 0;
      _currentDynamicColors = cachedColors ?? getAlbumGradient(albumName);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _extractAlbumColors(
        album['cover'] ?? '',
        albumName,
        cacheKey: albumId,
      );
    });

    if (cachedTracks != null) {
      _applyFirstCachedEmbeddedCover(album, cachedTracks);
      _indexAlbumFromTracks(album, cachedTracks);
      return;
    }

    try {
      final headers = await _user!.authHeaders;
      final api = drive.DriveApi(GoogleAuthClient(headers));
      final tracks = await _fetchTracksForAlbumRecord(api, album);

      if (!mounted) return;

      _albumTracksCache[albumId] = tracks;
      _applyFirstCachedEmbeddedCover(album, tracks);
      _indexAlbumFromTracks(album, tracks, save: false);
      _saveLibraryBrain();
      _persistAlbums();

      setState(() {
        _albumTracks = tracks;
        _loadingAlbum = false;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _precacheTrackArtwork(album['cover'] ?? '');
      });
    } catch (e) {
      _showError('Failed to load album: $e');
      if (mounted) setState(() => _loadingAlbum = false);
    }
  }

  void _applyFirstCachedEmbeddedCover(Map<String, String> album, List<drive.File> tracks) {
    String? cachedEmbeddedCover;
    for (final track in tracks) {
      final cached = _metaStore.peek(track);
      if (cached?.coverPath != null && cached!.coverPath!.isNotEmpty) {
        cachedEmbeddedCover = cached.coverPath;
        break;
      }
    }

    if (cachedEmbeddedCover == null) return;

    bool changed = album['cover'] != cachedEmbeddedCover;
    album['cover'] = cachedEmbeddedCover;

    for (final savedAlbum in _albums) {
      if (savedAlbum['id'] == album['id']) {
        if (savedAlbum['cover'] != cachedEmbeddedCover) {
          savedAlbum['cover'] = cachedEmbeddedCover;
          changed = true;
        }
        break;
      }
    }

    if (changed) {
      _persistAlbums();
      if (mounted) setState(() {});
    }
  }

  void _precacheTrackArtwork(String coverUrl) {
    if (coverUrl.isEmpty) return;
    final provider = _coverProvider(coverUrl);
    if (provider != null) {
      precacheImage(provider, context).catchError((_) {});
    }
  }

  void _closeAlbum() {
    setState(() {
      _viewingAlbum = null;
      _albumTracks = [];
      _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
    });
  }

  Future<List<drive.File>> _fetchTracksForAlbumRecord(
    drive.DriveApi api,
    Map<String, String> album,
  ) async {
    final List<drive.File> tracks = [];
    final folderIds = (album['id'] ?? '').split(',').where((id) => id.trim().isNotEmpty);

    for (final fId in folderIds) {
      String? pageToken;

      do {
        final res = await api.files.list(
          q: "'$fId' in parents and trashed = false",
          $fields:
              'files(id,name,mimeType,shortcutDetails(targetId,targetMimeType),size,modifiedTime),nextPageToken',
          pageSize: 100,
          pageToken: pageToken,
          supportsAllDrives: true,
          includeItemsFromAllDrives: true,
        );

        final files = res.files ?? <drive.File>[];
        tracks.addAll(files.where((file) => DriveUtils.isAudio(file)));
        pageToken = res.nextPageToken;
      } while (pageToken != null);
    }

    tracks.sort((a, b) => (a.name ?? '').compareTo(b.name ?? ''));
    return tracks;
  }

  // ── Drive Explorer ────────────────────────────────────────────────────────
  Future<void> _fetchExplore({required String folderId}) async {
    if (_user == null) return;

    setState(() => _loadingExplore = true);

    try {
      final headers = await _user!.authHeaders;
      final api = drive.DriveApi(GoogleAuthClient(headers));

      final result = await api.files.list(
        q: "'$folderId' in parents and trashed = false",
        $fields: 'files(id,name,mimeType,shortcutDetails(targetId,targetMimeType),size,modifiedTime)',
        pageSize: 100,
        orderBy: 'folder,name',
        supportsAllDrives: true,
        includeItemsFromAllDrives: true,
      );

      final files = result.files ?? <drive.File>[];

      if (!mounted) return;

      setState(() {
        _exploreItems = files
            .where((f) => DriveUtils.isFolder(f) || DriveUtils.isAudio(f))
            .toList();
        _loadingExplore = false;
      });
    } catch (e) {
      if (e.toString().contains('401')) {
        _showError('Session expired. Sign out and sign back in.');
      } else {
        _showError('Drive load failed: $e');
      }

      if (mounted) setState(() => _loadingExplore = false);
    }
  }

  Future<void> _exploreGoBack() async {
    if (_navStack.isNotEmpty) {
      final prev = _navStack.removeLast();
      setState(() {
        _exploreFolder = prev.id == 'root' ? null : prev;
        _exploreItems = [];
      });
      await _fetchExplore(folderId: prev.id ?? 'root');
    } else {
      setState(() {
        _exploreFolder = null;
        _exploreItems = [];
      });
      await _fetchExplore(folderId: 'root');
    }
  }

  Future<void> _openExploreFolder(drive.File folder) async {
    final tid = DriveUtils.effectiveId(folder);
    if (tid == null) return;

    if (_exploreFolder == null) {
      _navStack.add(drive.File()
        ..id = 'root'
        ..name = 'My Drive');
    } else {
      _navStack.add(_exploreFolder!);
    }

    final display = drive.File()
      ..id = tid
      ..name = folder.name
      ..mimeType = 'application/vnd.google-apps.folder';

    setState(() {
      _exploreFolder = display;
      _exploreItems = [];
    });

    await _fetchExplore(folderId: tid);
  }

  // ── Playback ──────────────────────────────────────────────────────────────
  Future<void> _playSong(
    drive.File file, {
    List<drive.File>? queue,
    int? idx,
    String? coverUrl,
    List<Color>? colors,
  }) async {
    final fileId = DriveUtils.effectiveId(file);
    if (fileId == null || _user == null) return;

    final tracks = queue ?? _albumTracks;
    final trackIdx = idx ?? tracks.indexWhere((f) => DriveUtils.effectiveId(f) == fileId);
    final activeColors = List<Color>.from(colors ?? _currentDynamicColors);

    _nowPlaying.setTrack(
      file,
      tracks,
      trackIdx,
      coverUrl: coverUrl,
      colors: activeColors,
    );

    _saveLastPlayed(file, coverUrl: coverUrl);

    try {
      final authHeaders = await _user!.authHeaders;
      String token = '';
      final bearer = authHeaders['Authorization'] ?? authHeaders['authorization'] ?? '';
      if (bearer.startsWith('Bearer ')) token = bearer.substring(7);

      _loadMetadataFor(file, token, albumRecord: _viewingAlbum);

      final source = DriveAudioSource(fileId, token);

      await _player.stop();
      await _player.setAudioSource(source);
      await _player.play();
      _recordPlay(file, coverUrl: coverUrl ?? _viewingAlbum?['cover']);
    } catch (e) {
      _showError('Playback error: $e');
    }
  }

  Future<void> _playNext() async {
    if (_nowPlaying.queue.isEmpty) return;

    if (_nowPlaying.shuffleEnabled && _nowPlaying.queue.length > 1) {
      int nextIndex = _nowPlaying.queueIndex;
      final random = math.Random();

      while (nextIndex == _nowPlaying.queueIndex) {
        nextIndex = random.nextInt(_nowPlaying.queue.length);
      }

      await _playSong(
        _nowPlaying.queue[nextIndex],
        queue: _nowPlaying.queue,
        idx: nextIndex,
        coverUrl: _nowPlaying.currentCoverUrl,
        colors: _nowPlaying.dynamicColors,
      );
      return;
    }

    final next = _nowPlaying.nextTrack;
    if (next == null) return;

    final nextIndex = _nowPlaying.queueIndex + 1;
    await _playSong(
      next,
      queue: _nowPlaying.queue,
      idx: nextIndex,
      coverUrl: _nowPlaying.currentCoverUrl,
      colors: _nowPlaying.dynamicColors,
    );
  }

  Future<void> _playPrev() async {
    final pos = _player.position;

    if (pos.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }

    final prev = _nowPlaying.prevTrack;
    if (prev == null) return;

    final prevIndex = _nowPlaying.queueIndex - 1;
    await _playSong(
      prev,
      queue: _nowPlaying.queue,
      idx: prevIndex,
      coverUrl: _nowPlaying.currentCoverUrl,
      colors: _nowPlaying.dynamicColors,
    );
  }

  void _showError(String msg) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: _textPri)),
        backgroundColor: _pink,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  void _showCoverZoom(String heroTag, String coverUrl, List<Color> gradient) {
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: false,
        barrierDismissible: true,
        barrierColor: Colors.black.withOpacity(0.86),
        pageBuilder: (BuildContext context, _, __) {
          return GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Center(
              child: Hero(
                tag: heroTag,
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.86,
                  height: MediaQuery.of(context).size.width * 0.86,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(26),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: gradient,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: gradient[0].withOpacity(0.50),
                        blurRadius: 45,
                        spreadRadius: 8,
                      ),
                    ],
                  ),
                  child: coverUrl.isNotEmpty
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(26),
                          child: _coverImage(coverUrl, fit: BoxFit.cover),
                        )
                      : null,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (_user == null) {
      return _buildSignInScreen();
    }

    final colors = _safeColors(_currentDynamicColors);
    final accent = _appAccent;

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          Positioned.fill(child: _buildAppBackground(colors)),

          SafeArea(
            bottom: false,
            child: _viewingAlbum != null
                ? _buildAlbumView()
                : PageView(
                    controller: _pageController,
                    physics: const BouncingScrollPhysics(),
                    onPageChanged: (index) {
                      setState(() {
                        _navIndex = index;
                        _currentDynamicColors = List<Color>.from(_defaultDynamicColors);
                      });

                      if (index == 2 && _exploreItems.isEmpty && _exploreFolder == null) {
                        _fetchExplore(folderId: 'root');
                      }
                    },
                    children: [
                      this.buildHomeTab(),
                      this.buildLibraryTab(),
                      this.buildDriveTab(),
                    ],
                  ),
          ),

          Positioned(
            bottom: 116,
            left: 16,
            right: 16,
            child: _PlayerFloatingBar(
              player: _player,
              onNext: _playNext,
              onPrev: _playPrev,
              onPlayFromQueue: (track, index) => _playSong(
                track,
                queue: _nowPlaying.queue,
                idx: index,
                coverUrl: _nowPlaying.currentCoverUrl,
                colors: _nowPlaying.dynamicColors,
              ),
            ),
          ),

          Positioned(
            bottom: 18,
            left: 16,
            right: 16,
            child: SafeArea(
              top: false,
              child: GlassyContainer(
                radius: 34,
                allowRealBlur: true,
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                customBorder: accent.withOpacity(0.35),
                customColor: Colors.white.withOpacity(0.075),
                child: SizedBox(
                  height: 60,
                  child: Row(
                    children: [
                      _NavBarItem(
                        icon: Icons.home_rounded,
                        label: 'Home',
                        accent: accent,
                        isSelected: _navIndex == 0,
                        onTap: () => _selectRootTab(0),
                      ),
                      _NavBarItem(
                        icon: Icons.library_music_rounded,
                        label: 'Library',
                        accent: accent,
                        isSelected: _navIndex == 1,
                        onTap: () => _selectRootTab(1),
                      ),
                      _NavBarItem(
                        icon: Icons.search_rounded,
                        label: 'Search',
                        accent: accent,
                        isSelected: _navIndex == 2,
                        onTap: () => _selectRootTab(2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSignInScreen() {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: _buildAppBackground(
              [_pink, _accentDefault, _purple, _cyan],
              signIn: true,
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildGradientText('MUSIX', size: 52, spacing: 4),
                  const SizedBox(height: 12),
                  Text(
                    'Stream your Google Drive library with a proper music-player feel.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.inter(
                      color: _textSub,
                      fontSize: 14,
                      height: 1.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 42),
                  _signingIn
                      ? const CircularProgressIndicator(color: _pink)
                      : GestureDetector(
                          onTap: _signIn,
                          child: GlassyContainer(
                            radius: 30,
                            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 16),
                            customBorder: _pink.withOpacity(0.35),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.cloud_rounded, color: _accentDefault),
                                const SizedBox(width: 10),
                                Text(
                                  'Connect Google Drive',
                                  style: GoogleFonts.inter(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Album View ────────────────────────────────────────────────────────────
  Widget _buildAlbumView() {
    final albumName = _viewingAlbum!['name'] ?? 'Unknown Album';
    final coverUrl = _viewingAlbum!['cover'] ?? '';
    final colors = _safeColors(_currentDynamicColors);
    final fallbackGradient = getAlbumGradient(albumName);
    final metadataLoadedCount = _albumTracks.where((track) => _metaStore.peek(track) != null).length;

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverAppBar(
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          pinned: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _textPri),
            onPressed: _closeAlbum,
          ),
          actions: [
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_horiz_rounded, color: _textPri),
              color: const Color(0xFF1A1A22),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              onSelected: (value) {
                if (value == 'load_metadata') {
                  _loadMetadataForCurrentAlbum();
                } else if (value == 'refresh_cover') {
                  _refreshCurrentAlbumCover();
                } else if (value == 'remove_album') {
                  _removeCurrentAlbumFromLibrary();
                }
              },
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'load_metadata',
                  enabled: !_albumMetadataLoading && !_loadingMetadata,
                  child: Row(
                    children: [
                      Icon(Icons.tag_rounded, color: colors[1], size: 20),
                      const SizedBox(width: 12),
                      Text(
                        _albumMetadataLoading
                            ? 'Loading metadata...'
                            : 'Load metadata for album',
                        style: GoogleFonts.inter(
                          color: _textPri,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'refresh_cover',
                  child: Row(
                    children: [
                      Icon(Icons.image_search_rounded, color: colors[1], size: 20),
                      const SizedBox(width: 12),
                      Text(
                        'Refresh cover',
                        style: GoogleFonts.inter(
                          color: _textPri,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'remove_album',
                  child: Row(
                    children: [
                      const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 20),
                      const SizedBox(width: 12),
                      Text(
                        'Remove from app library',
                        style: GoogleFonts.inter(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => _showCoverZoom('album_hero_$albumName', coverUrl, colors),
                  child: Hero(
                    tag: 'album_hero_$albumName',
                    child: Container(
                      width: 154,
                      height: 154,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: coverUrl.isEmpty ? fallbackGradient : colors,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: colors[0].withOpacity(0.42),
                            blurRadius: 34,
                            offset: const Offset(0, 14),
                          ),
                        ],
                      ),
                      child: coverUrl.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(24),
                              child: _coverImage(
                                coverUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                                  name: albumName,
                                  colors: fallbackGradient,
                                  radius: 24,
                                ),
                              ),
                            )
                          : _AlbumFallbackCover(
                              name: albumName,
                              colors: fallbackGradient,
                              radius: 24,
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 26),
                Text(
                  albumName,
                  style: GoogleFonts.inter(
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                    color: _textPri,
                    height: 1.06,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Album • Drive Library',
                        style: GoogleFonts.inter(
                          color: _textSub,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (_albumTracks.isNotEmpty) {
                          _playSong(
                            _albumTracks.first,
                            queue: _albumTracks,
                            idx: 0,
                            coverUrl: coverUrl,
                            colors: colors,
                          );
                        }
                      },
                      child: Container(
                        width: 62,
                        height: 62,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: colors[1],
                          boxShadow: [
                            BoxShadow(
                              color: colors[1].withOpacity(0.38),
                              blurRadius: 24,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 38),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                if (_albumMetadataLoading)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.2,
                                color: colors[1],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Loading album metadata $_albumMetadataDone/$_albumMetadataTotal',
                              style: GoogleFonts.inter(
                                color: _textSub,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: _albumMetadataTotal > 0
                                ? (_albumMetadataDone / _albumMetadataTotal).clamp(0.0, 1.0)
                                : null,
                            minHeight: 4,
                            backgroundColor: Colors.white.withOpacity(0.13),
                            valueColor: AlwaysStoppedAnimation<Color>(colors[1]),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
        if (_loadingAlbum)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _pink)),
          )
        else if (_albumTracks.isEmpty)
          const SliverFillRemaining(
            child: Center(
              child: Text('No tracks found in this album.', style: TextStyle(color: _textSub)),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.only(bottom: 218),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((ctx, i) {
                return _TrackGlassTile(
                  track: _albumTracks[i],
                  queue: _albumTracks,
                  index: i,
                  coverUrl: coverUrl,
                  onTap: () => _playSong(
                    _albumTracks[i],
                    queue: _albumTracks,
                    idx: i,
                    coverUrl: coverUrl,
                    colors: colors,
                  ),
                );
              }, childCount: _albumTracks.length),
            ),
          ),
      ],
    );
  }

  // ── Home Tab ──────────────────────────────────────────────────────────────
  
  List<Widget> _homeAlbumShelfSlivers({
    required String title,
    required String subtitle,
    required List<Map<String, String>> items,
    double bottomPadding = 22,
  }) {
    if (items.isEmpty) return const <Widget>[];

    return [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
        sliver: SliverToBoxAdapter(
          child: _HomeSectionHeader(title: title, subtitle: subtitle),
        ),
      ),
      SliverPadding(
        padding: EdgeInsets.fromLTRB(20, 0, 0, bottomPadding),
        sliver: SliverToBoxAdapter(
          child: SizedBox(
            height: 214,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (context, i) {
                final info = items[i];
                return _HomeAlbumCard(
                  info: info,
                  onTap: () => _openAlbumByBrain(info),
                );
              },
            ),
          ),
        ),
      ),
    ];
  }

  // ── Library Tab ───────────────────────────────────────────────────────────
  
  // ── Search Tab ────────────────────────────────────────────────────────────
  
  Widget _buildAppBackground(List<Color> colors, {bool signIn = false}) {
    final safe = _safeColors(colors);
    final glowOpacity = _glassMode == glassModePerformance ? 0.52 : 0.80;

    return Container(
      color: _bg,
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF17171D),
                    Color.alphaBlend(safe[3].withOpacity(0.22), _bg),
                    Colors.black,
                  ],
                ),
              ),
            ),
          ),
          if (_showBackgroundGlow) ...[
            Positioned(top: signIn ? -120 : -130, left: -130, child: _buildBlob(safe[0], 360 * glowOpacity)),
            Positioned(top: signIn ? 100 : 46, right: -150, child: _buildBlob(safe[2], 310 * glowOpacity)),
            Positioned(bottom: 90, right: -110, child: _buildBlob(safe[1], 330 * glowOpacity)),
            Positioned(bottom: -140, left: -130, child: _buildBlob(safe[3], 320 * glowOpacity)),
            if (_glassMode == glassModePretty)
              Positioned(top: 260, left: 36, child: _buildBlob(safe[1].withOpacity(0.8), 190)),
          ],
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(signIn ? 0.08 : 0.14),
                    Colors.black.withOpacity(0.22),
                    Colors.black.withOpacity(0.50),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBlob(Color color, double size) {
    final opacity = _glassMode == glassModePerformance ? 0.18 : 0.28;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 650),
      curve: Curves.easeOutCubic,
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            color.withOpacity(opacity),
            color.withOpacity(opacity * 0.42),
            Colors.transparent,
          ],
          stops: const [0.0, 0.55, 1.0],
        ),
      ),
    );
  }

  Widget _buildGradientText(String text, {required double size, double spacing = 0}) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: size,
        fontWeight: FontWeight.w900,
        color: _textPri,
        letterSpacing: spacing,
      ),
    );
  }
}

