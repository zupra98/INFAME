part of '../main.dart';

// ─── Vinyl Disc ─────────────────────────────────────────────────────────────
class _VinylDisc extends StatelessWidget {
  final double size;
  final String? coverUrl;
  final List<Color> colors;
  final bool showGrooves;

  const _VinylDisc({
    required this.size,
    required this.coverUrl,
    required this.colors,
    this.showGrooves = true,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    final centerSize = size * 0.52;
    final holeSize = size * 0.075;

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  Colors.grey.shade900,
                  Colors.black,
                  const Color(0xFF050506),
                ],
                stops: const [0.0, 0.58, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: safe[0].withOpacity(0.38),
                  blurRadius: size * 0.16,
                  spreadRadius: size * 0.018,
                  offset: Offset(0, size * 0.055),
                ),
              ],
            ),
          ),
          if (showGrooves) ...[
            _VinylRing(size: size * 0.86),
            _VinylRing(size: size * 0.70),
            _VinylRing(size: size * 0.34),
          ],
          Container(
            width: centerSize,
            height: centerSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: safe,
              ),
              border: Border.all(color: Colors.white.withOpacity(0.10), width: 1),
              image: coverUrl != null && coverUrl!.isNotEmpty
                  ? DecorationImage(image: _coverProvider(coverUrl!)!, fit: BoxFit.cover)
                  : null,
            ),
            child: coverUrl == null || coverUrl!.isEmpty
                ? Icon(
                    Icons.music_note_rounded,
                    size: size * 0.22,
                    color: Colors.white.withOpacity(0.50),
                  )
                : null,
          ),
          Container(
            width: holeSize,
            height: holeSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _bg,
              border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
            ),
          ),
        ],
      ),
    );
  }
}

class _VinylRing extends StatelessWidget {
  final double size;

  const _VinylRing({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withOpacity(0.055), width: 1),
      ),
    );
  }
}

// ─── Lyrics Sheet ───────────────────────────────────────────────────────────
class _LyricsResult {
  final String trackName;
  final String artistName;
  final String? plainLyrics;
  final String? syncedLyrics;

  const _LyricsResult({
    required this.trackName,
    required this.artistName,
    this.plainLyrics,
    this.syncedLyrics,
  });

  bool get hasSynced => syncedLyrics != null && syncedLyrics!.trim().isNotEmpty;
  bool get hasPlain => plainLyrics != null && plainLyrics!.trim().isNotEmpty;
}

class _LyricLine {
  final Duration time;
  final String text;

  const _LyricLine({required this.time, required this.text});
}

class _LyricsSheet extends StatefulWidget {
  final AudioPlayer player;
  final Map<String, String> meta;
  final List<Color> colors;

  const _LyricsSheet({
    required this.player,
    required this.meta,
    required this.colors,
  });

  @override
  State<_LyricsSheet> createState() => _LyricsSheetState();
}

class _LyricsSheetState extends State<_LyricsSheet> {
  late final Future<_LyricsResult?> _lyricsFuture;
  final ScrollController _scrollController = ScrollController();
  int _lastActiveLine = -1;

  @override
  void initState() {
    super.initState();
    _lyricsFuture = _fetchLyrics();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<_LyricsResult?> _fetchLyrics() async {
    final title = (widget.meta['title'] ?? '').trim();
    final artist = (widget.meta['artist'] ?? '').trim();

    if (title.isEmpty) return null;

    final params = <String, String>{'track_name': title};

    if (artist.isNotEmpty && artist != 'Unknown Artist') {
      params['artist_name'] = artist;
    }

    Future<List<dynamic>> request(Uri uri) async {
      final res = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'MusixApp/1.0',
        },
      );

      if (res.statusCode != 200) return [];
      final decoded = json.decode(res.body);
      return decoded is List ? decoded : [];
    }

    List<dynamic> results = await request(Uri.https('lrclib.net', '/api/search', params));

    if (results.isEmpty) {
      final fallbackQuery = artist.isNotEmpty && artist != 'Unknown Artist'
          ? '$artist $title'
          : title;
      results = await request(Uri.https('lrclib.net', '/api/search', {'q': fallbackQuery}));
    }

    if (results.isEmpty) return null;

    Map<String, dynamic>? best;

    for (final item in results) {
      if (item is! Map<String, dynamic>) continue;
      final synced = item['syncedLyrics'];
      if (synced is String && synced.trim().isNotEmpty) {
        best = item;
        break;
      }
      best ??= item;
    }

    if (best == null) return null;

    return _LyricsResult(
      trackName: (best['trackName'] ?? title).toString(),
      artistName: (best['artistName'] ?? artist).toString(),
      plainLyrics: best['plainLyrics']?.toString(),
      syncedLyrics: best['syncedLyrics']?.toString(),
    );
  }

  List<_LyricLine> _parseSyncedLyrics(String raw) {
    final lines = <_LyricLine>[];

    for (final rawLine in raw.split(String.fromCharCode(10))) {
      final line = rawLine.trim();
      if (!line.startsWith('[')) continue;

      final end = line.indexOf(']');
      if (end <= 1) continue;

      final stamp = line.substring(1, end);
      final text = line.substring(end + 1).trim();
      if (text.isEmpty) continue;

      final timeParts = stamp.split(':');
      if (timeParts.length != 2) continue;

      final minutes = int.tryParse(timeParts[0]) ?? 0;
      final secondParts = timeParts[1].split('.');
      final seconds = int.tryParse(secondParts[0]) ?? 0;
      final fraction = secondParts.length > 1 ? secondParts[1] : '0';
      final padded = fraction.padRight(3, '0');
      final millis = int.tryParse(padded.substring(0, 3)) ?? 0;

      lines.add(
        _LyricLine(
          time: Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
          text: text,
        ),
      );
    }

    lines.sort((a, b) => a.time.compareTo(b.time));
    return lines;
  }

  int _activeLineIndex(List<_LyricLine> lines, Duration pos) {
    if (lines.isEmpty) return -1;

    int active = 0;
    for (int i = 0; i < lines.length; i++) {
      if (pos >= lines[i].time) {
        active = i;
      } else {
        break;
      }
    }

    return active;
  }

  void _scrollToActiveLine(int active) {
    if (active == _lastActiveLine || !_scrollController.hasClients) return;
    _lastActiveLine = active;

    final target = (active * 44.0).clamp(0.0, _scrollController.position.maxScrollExtent);

    _scrollController.animateTo(
      target,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = _safeColors(widget.colors);

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.82,
        decoration: BoxDecoration(
          color: _bg.withOpacity(0.96),
          borderRadius: BorderRadius.zero,
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.12))),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              colors[0].withOpacity(0.34),
              _bg.withOpacity(0.98),
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 24),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                    ),
                    const Spacer(),
                    Text(
                      'Lyrics',
                      style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w900),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
                Text(
                  '${widget.meta['title'] ?? ''} • ${widget.meta['artist'] ?? ''}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 22),
                Expanded(
                  child: FutureBuilder<_LyricsResult?>(
                    future: _lyricsFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return Center(child: CircularProgressIndicator(color: colors[1]));
                      }

                      if (snapshot.hasError) {
                        return Center(
                          child: Text(
                            'Could not load lyrics.',
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      final result = snapshot.data;
                      if (result == null || (!result.hasSynced && !result.hasPlain)) {
                        return Center(
                          child: Text(
                            'No lyrics found for this track.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      if (result.hasSynced) {
                        final lines = _parseSyncedLyrics(result.syncedLyrics!);

                        if (lines.isNotEmpty) {
                          return StreamBuilder<Duration>(
                            stream: widget.player.positionStream,
                            builder: (context, posSnap) {
                              final pos = posSnap.data ?? Duration.zero;
                              final active = _activeLineIndex(lines, pos);

                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                if (mounted) _scrollToActiveLine(active);
                              });

                              return ListView.builder(
                                controller: _scrollController,
                                physics: const BouncingScrollPhysics(),
                                padding: const EdgeInsets.only(top: 80, bottom: 160),
                                itemCount: lines.length,
                                itemBuilder: (context, i) {
                                  final isActive = i == active;
                                  return AnimatedDefaultTextStyle(
                                    duration: const Duration(milliseconds: 200),
                                    curve: Curves.easeOutCubic,
                                    style: GoogleFonts.inter(
                                      fontSize: isActive ? 23 : 19,
                                      height: 1.35,
                                      fontWeight: isActive ? FontWeight.w900 : FontWeight.w700,
                                      color: isActive ? Colors.white : Colors.white.withOpacity(0.38),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 8),
                                      child: Text(lines[i].text),
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        }
                      }

                      final plain = result.plainLyrics ?? result.syncedLyrics ?? '';

                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Text(
                          plain,
                          style: GoogleFonts.inter(
                            fontSize: 18,
                            height: 1.55,
                            fontWeight: FontWeight.w700,
                            color: Colors.white.withOpacity(0.86),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Lyrics by LRCLIB',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Queue Sheet ────────────────────────────────────────────────────────────
class _QueueSheet extends StatelessWidget {
  final List<Color> colors;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _QueueSheet({
    required this.colors,
    required this.onPlayFromQueue,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.78,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.zero,
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.12))),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              safe[0].withOpacity(0.30),
              _bg.withOpacity(0.98),
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                    ),
                    const Spacer(),
                    Text(
                      'Queue',
                      style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w900),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
                Text(
                  '${_nowPlaying.queue.length} tracks',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: ListenableBuilder(
                    listenable: _nowPlaying,
                    builder: (context, _) {
                      if (_nowPlaying.queue.isEmpty) {
                        return Center(
                          child: Text(
                            'Queue is empty.',
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      return ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        itemCount: _nowPlaying.queue.length,
                        itemBuilder: (context, i) {
                          final track = _nowPlaying.queue[i];
                          final meta = DriveUtils.getTrackMeta(track);
                          final isActive = i == _nowPlaying.queueIndex;

                          return GestureDetector(
                            onTap: () async {
                              await onPlayFromQueue(track, i);
                            },
                            behavior: HitTestBehavior.opaque,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                              decoration: BoxDecoration(
                                color: isActive ? Colors.white.withOpacity(0.11) : Colors.transparent,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isActive ? safe[1].withOpacity(0.40) : Colors.transparent,
                                ),
                              ),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 28,
                                    child: Text(
                                      '${i + 1}',
                                      style: GoogleFonts.inter(
                                        color: isActive ? safe[1] : _textSub,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          meta['title'] ?? 'Unknown',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.inter(
                                            color: isActive ? safe[1] : _textPri,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          meta['artist'] ?? 'Unknown Artist',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.inter(
                                            color: _textSub,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (isActive)
                                    Icon(Icons.graphic_eq_rounded, color: safe[1], size: 22),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Floating Player Bar ────────────────────────────────────────────────────
class _PlayerFloatingBar extends StatefulWidget {
  final AudioPlayer player;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _PlayerFloatingBar({
    required this.player,
    required this.onNext,
    required this.onPrev,
    required this.onPlayFromQueue,
  });

  @override
  State<_PlayerFloatingBar> createState() => _PlayerFloatingBarState();
}

class _PlayerFloatingBarState extends State<_PlayerFloatingBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spinCtrl;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8));
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    super.dispose();
  }

  void _syncSpin(bool isPlaying) {
    if (isPlaying && !_spinCtrl.isAnimating) {
      _spinCtrl.repeat();
    } else if (!isPlaying && _spinCtrl.isAnimating) {
      _spinCtrl.stop(canceled: false);
    }
  }

  void _openFullScreenPlayer(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) {
        return _FullScreenPlayerSheet(
          player: widget.player,
          onNext: widget.onNext,
          onPrev: widget.onPrev,
          onPlayFromQueue: widget.onPlayFromQueue,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _nowPlaying,
      builder: (ctx, _) {
        final track = _nowPlaying.track;
        if (track == null) return const SizedBox.shrink();

        final meta = DriveUtils.getTrackMeta(track);
        final coverUrl = _nowPlaying.currentCoverUrl;
        final colors = _safeColors(_nowPlaying.dynamicColors);

        return StreamBuilder<PlayerState>(
          stream: widget.player.playerStateStream,
          builder: (_, stateSnap) {
            final state = stateSnap.data;
            final isPlaying = state?.playing ?? false;
            final isLoading = state?.processingState == ProcessingState.loading ||
                state?.processingState == ProcessingState.buffering;

            _syncSpin(isPlaying);

            return GlassyContainer(
              radius: 26,
              allowRealBlur: true,
              customBorder: colors[0].withOpacity(0.52),
              customColor: Colors.white.withOpacity(0.085),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _openFullScreenPlayer(context),
                      behavior: HitTestBehavior.opaque,
                      child: Row(
                        children: [
                          Hero(
                            tag: 'now_playing_hero',
                            child: RotationTransition(
                              turns: _spinCtrl,
                              child: _VinylDisc(
                                size: 50,
                                coverUrl: coverUrl,
                                colors: colors,
                                showGrooves: false,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  meta['title']!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.inter(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: _textPri,
                                  ),
                                ),
                                const SizedBox(height: 1),
                                Text(
                                  meta['artist']!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.inter(fontSize: 11, color: _textSub),
                                ),
                                StreamBuilder<Duration>(
                                  stream: widget.player.positionStream,
                                  builder: (_, posSnap) {
                                    return StreamBuilder<Duration?>(
                                      stream: widget.player.durationStream,
                                      builder: (_, durSnap) {
                                        final dur = durSnap.data ?? Duration.zero;
                                        final pos = posSnap.data ?? Duration.zero;
                                        final prog = dur.inMilliseconds > 0
                                            ? (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0)
                                            : 0.0;

                                        return Padding(
                                          padding: const EdgeInsets.only(top: 5, right: 8),
                                          child: LinearProgressIndicator(
                                            value: prog,
                                            backgroundColor: glassBorder,
                                            valueColor: AlwaysStoppedAnimation<Color>(colors[1]),
                                            minHeight: 3,
                                            borderRadius: BorderRadius.circular(3),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_previous_rounded, color: _textPri),
                    onPressed: widget.onPrev,
                  ),
                  GestureDetector(
                    onTap: () {
                      if (isLoading) return;
                      isPlaying ? widget.player.pause() : widget.player.play();
                    },
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: colors[1],
                        boxShadow: [
                          BoxShadow(color: colors[1].withOpacity(0.30), blurRadius: 18),
                        ],
                      ),
                      child: isLoading
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2),
                            )
                          : Icon(
                              isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                              color: Colors.black,
                              size: 27,
                            ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_next_rounded, color: _textPri),
                    onPressed: widget.onNext,
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ─── Fullscreen Player Sheet ────────────────────────────────────────────────
class _FullScreenPlayerSheet extends StatefulWidget {
  final AudioPlayer player;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _FullScreenPlayerSheet({
    required this.player,
    required this.onNext,
    required this.onPrev,
    required this.onPlayFromQueue,
  });

  @override
  State<_FullScreenPlayerSheet> createState() => _FullScreenPlayerSheetState();
}

class _FullScreenPlayerSheetState extends State<_FullScreenPlayerSheet>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spinCtrl;
  bool _vinylOpen = false;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16));
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    super.dispose();
  }

  void _syncSpin(bool isPlaying) {
    if (isPlaying && !_spinCtrl.isAnimating) {
      _spinCtrl.repeat();
    } else if (!isPlaying && _spinCtrl.isAnimating) {
      _spinCtrl.stop(canceled: false);
    }
  }

  String _formatTime(Duration d) {
    final hours = d.inHours;
    final minutes = d.inMinutes.remainder(60).toString().padLeft(hours > 0 ? 2 : 1, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');

    if (hours > 0) return '$hours:$minutes:$seconds';
    return '$minutes:$seconds';
  }

  Widget _buildArtwork(BuildContext context, String? coverUrl, List<Color> colors) {
    final screenWidth = MediaQuery.of(context).size.width;
    final coverSize = screenWidth * 0.68;
    final vinylSize = coverSize * 0.92;
    final closedWidth = coverSize;
    final openWidth = coverSize + (vinylSize * 0.48);

    return Center(
      child: GestureDetector(
        onTap: () => setState(() => _vinylOpen = !_vinylOpen),
        behavior: HitTestBehavior.opaque,
        child: Hero(
          tag: 'now_playing_hero',
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
            width: _vinylOpen ? openWidth : closedWidth,
            height: coverSize,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.centerLeft,
              children: [
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 420),
                  curve: Curves.easeOutCubic,
                  left: _vinylOpen ? coverSize - (vinylSize * 0.52) : (coverSize - vinylSize) / 2,
                  top: (coverSize - vinylSize) / 2,
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 280),
                    opacity: _vinylOpen ? 1.0 : 0.0,
                    child: RotationTransition(
                      turns: _spinCtrl,
                      child: _VinylDisc(
                        size: vinylSize,
                        coverUrl: coverUrl,
                        colors: colors,
                        showGrooves: true,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  top: 0,
                  child: Container(
                    width: coverSize,
                    height: coverSize,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: colors,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.46),
                          blurRadius: 34,
                          offset: const Offset(0, 18),
                        ),
                        BoxShadow(
                          color: colors[0].withOpacity(0.28),
                          blurRadius: 42,
                          spreadRadius: 2,
                        ),
                      ],
                      image: coverUrl != null && coverUrl.isNotEmpty
                          ? DecorationImage(
                              image: _coverProvider(coverUrl)!,
                              fit: BoxFit.cover,
                            )
                          : null,
                    ),
                    child: coverUrl == null || coverUrl.isEmpty
                        ? Center(
                            child: Icon(
                              Icons.music_note_rounded,
                              color: Colors.white.withOpacity(0.48),
                              size: 86,
                            ),
                          )
                        : null,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openLyricsSheet(
    BuildContext context,
    Map<String, String> meta,
    List<Color> colors,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (_) {
        return _LyricsSheet(
          player: widget.player,
          meta: meta,
          colors: colors,
        );
      },
    );
  }

  void _openQueueSheet(BuildContext context, List<Color> colors) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (_) {
        return _QueueSheet(
          colors: colors,
          onPlayFromQueue: widget.onPlayFromQueue,
        );
      },
    );
  }

  Widget _smallControlButton({
    required IconData icon,
    required VoidCallback onTap,
    bool active = false,
    Color? accent,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        alignment: Alignment.center,
        child: Icon(
          icon,
          color: active ? accent ?? _accentDefault : Colors.white.withOpacity(0.76),
          size: 24,
        ),
      ),
    );
  }

  Widget _pillButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: GlassyContainer(
          radius: 24,
          padding: const EdgeInsets.symmetric(vertical: 13),
          customColor: Colors.white.withOpacity(0.075),
          customBorder: Colors.white.withOpacity(0.10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 19, color: Colors.white.withOpacity(0.82)),
              const SizedBox(width: 8),
              Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Colors.white.withOpacity(0.86),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _nowPlaying,
      builder: (context, _) {
        final track = _nowPlaying.track;
        if (track == null) return const SizedBox.shrink();

        final meta = DriveUtils.getTrackMeta(track);
        final coverUrl = _nowPlaying.currentCoverUrl;
        final colors = _safeColors(_nowPlaying.dynamicColors);

        return StreamBuilder<PlayerState>(
          stream: widget.player.playerStateStream,
          builder: (context, stateSnap) {
            final state = stateSnap.data;
            final isPlaying = state?.playing ?? false;
            final isLoading = state?.processingState == ProcessingState.loading ||
                state?.processingState == ProcessingState.buffering;

            _syncSpin(isPlaying);

            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.96,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.zero,
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      colors[0].withOpacity(0.36),
                      colors[3].withOpacity(0.18),
                      _bg.withOpacity(0.98),
                      Colors.black,
                    ],
                  ),
                  border: Border.all(color: Colors.white.withOpacity(0.10)),
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 12, 24, 26),
                    child: Column(
                      children: [
                        Container(
                          width: 42,
                          height: 5,
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.26),
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => Navigator.pop(context),
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 35),
                            ),
                            const Spacer(),
                            IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.more_horiz_rounded, size: 29),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Center(child: _buildArtwork(context, coverUrl, colors)),
                        const SizedBox(height: 38),
                        Text(
                          meta['title']!,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.inter(
                            fontSize: 29,
                            height: 1.08,
                            fontWeight: FontWeight.w900,
                            color: _textPri,
                            letterSpacing: -0.8,
                          ),
                        ),
                        const SizedBox(height: 9),
                        Text(
                          meta['artist']!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.inter(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: _textSub,
                          ),
                        ),
                        const Spacer(),
                        StreamBuilder<Duration>(
                          stream: widget.player.positionStream,
                          builder: (_, posSnap) {
                            return StreamBuilder<Duration?>(
                              stream: widget.player.durationStream,
                              builder: (_, durSnap) {
                                final pos = posSnap.data ?? Duration.zero;
                                final dur = durSnap.data ?? Duration.zero;

                                final max = dur.inMilliseconds > 0
                                    ? dur.inMilliseconds.toDouble()
                                    : 1.0;

                                final value = pos.inMilliseconds.toDouble().clamp(0.0, max);

                                return Column(
                                  children: [
                                    SliderTheme(
                                      data: SliderThemeData(
                                        trackHeight: 4.5,
                                        activeTrackColor: Colors.white.withOpacity(0.92),
                                        inactiveTrackColor: Colors.white.withOpacity(0.18),
                                        thumbColor: Colors.white,
                                        overlayColor: colors[1].withOpacity(0.16),
                                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6.5),
                                        overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
                                      ),
                                      child: Slider(
                                        value: value,
                                        max: max,
                                        onChanged: (v) {
                                          widget.player.seek(Duration(milliseconds: v.toInt()));
                                        },
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 4),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            _formatTime(pos),
                                            style: GoogleFonts.inter(
                                              color: _textSub,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          Text(
                                            _formatTime(dur),
                                            style: GoogleFonts.inter(
                                              color: _textSub,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                        ),
                        const SizedBox(height: 26),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _smallControlButton(
                              icon: Icons.shuffle_rounded,
                              onTap: _nowPlaying.toggleShuffle,
                              active: _nowPlaying.shuffleEnabled,
                              accent: colors[1],
                            ),
                            IconButton(
                              icon: const Icon(Icons.skip_previous_rounded, size: 43, color: Colors.white),
                              onPressed: widget.onPrev,
                            ),
                            GestureDetector(
                              onTap: () {
                                if (isLoading) return;
                                isPlaying ? widget.player.pause() : widget.player.play();
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 180),
                                width: 82,
                                height: 82,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.white.withOpacity(0.22),
                                      blurRadius: 26,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: isLoading
                                    ? const Padding(
                                        padding: EdgeInsets.all(25),
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                          strokeWidth: 3,
                                        ),
                                      )
                                    : Icon(
                                        isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                        color: Colors.black,
                                        size: 47,
                                      ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.skip_next_rounded, size: 43, color: Colors.white),
                              onPressed: widget.onNext,
                            ),
                            _smallControlButton(
                              icon: Icons.repeat_rounded,
                              onTap: () async {
                                _nowPlaying.toggleRepeatOne();
                                await widget.player.setLoopMode(
                                  _nowPlaying.repeatOne ? LoopMode.one : LoopMode.off,
                                );
                              },
                              active: _nowPlaying.repeatOne,
                              accent: colors[1],
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                        Row(
                          children: [
                            _pillButton(
                              icon: Icons.lyrics_rounded,
                              label: 'Lyrics',
                              onTap: () => _openLyricsSheet(context, meta, colors),
                            ),
                            const SizedBox(width: 12),
                            _pillButton(
                              icon: Icons.queue_music_rounded,
                              label: 'Queue',
                              onTap: () => _openQueueSheet(context, colors),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
