part of '../main.dart';

// ─── Safe Static Utils ──────────────────────────────────────────────────────
class DriveUtils {
  static String? effectiveId(drive.File f) {
    if (f.mimeType == 'application/vnd.google-apps.shortcut' &&
        f.shortcutDetails?.targetId != null) {
      return f.shortcutDetails!.targetId;
    }
    return f.id;
  }

  static String? effectiveMimeType(drive.File f) {
    if (f.mimeType == 'application/vnd.google-apps.shortcut' &&
        f.shortcutDetails?.targetMimeType != null) {
      return f.shortcutDetails!.targetMimeType;
    }
    return f.mimeType;
  }

  static bool isFolder(drive.File f) {
    return effectiveMimeType(f) == 'application/vnd.google-apps.folder';
  }

  static bool isAudio(drive.File f) {
    final n = (f.name ?? '').toLowerCase();
    return n.endsWith('.mp3') ||
        n.endsWith('.flac') ||
        n.endsWith('.wav') ||
        n.endsWith('.m4a') ||
        n.endsWith('.aac') ||
        n.endsWith('.ogg') ||
        n.endsWith('.wma');
  }

  static Map<String, String> getTrackMeta(drive.File f) {
    final cached = _metaStore.peekFresh(f) ?? _metaStore.peek(f);
    if (cached != null) return cached.toMap();
    String title = f.name ?? 'Unknown';
    title = title.replaceAll(
      RegExp(r'\.(mp3|flac|wav|m4a|aac|ogg|wma)$', caseSensitive: false),
      '',
    );

    String artist = 'Unknown Artist';

    title = title.replaceFirst(RegExp(r'^\s*\d+[\s\.\-_]*'), '').trim();

    if (title.contains('-')) {
      final parts = title.split('-');
      artist = parts[0].trim();
      title = parts.sublist(1).join('-').trim();
    }

    return {
      'title': title.isEmpty ? f.name ?? 'Unknown' : title,
      'artist': artist.isEmpty ? 'Unknown Artist' : artist,
    };
  }
}
