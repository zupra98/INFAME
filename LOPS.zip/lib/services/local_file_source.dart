part of '../main.dart';

// ─── Local Files Source (MVP) ──────────────────────────────────────────────
// Keeps local files inside the same album/track model as Drive tracks by
// representing them as drive.File objects with source=local app properties.

extension _LocalFileSourceExtension on _MainScreenState {
  bool _isLocalAlbumRecord(Map<String, String> album) {
    return (album['source'] ?? '').trim() == 'local' ||
        (album['id'] ?? '').startsWith('local_album:');
  }

  String _localAlbumId(String album, String artist) {
    final key = [artist, album]
        .where((value) => value.trim().isNotEmpty)
        .join('::')
        .trim();
    return 'local_album:${_normalizeAlbumKeySegment(key.isEmpty ? album : key)}';
  }

  String _localBasename(String path) {
    final normalized = path.replaceAll('\\', '/');
    final idx = normalized.lastIndexOf('/');
    return idx >= 0 ? normalized.substring(idx + 1) : normalized;
  }

  drive.File _localDriveFileFromPath(String path) {
    final file = File(path);
    FileStat? stat;
    try {
      stat = file.statSync();
    } catch (_) {}

    return drive.File()
      ..id = DriveUtils.localIdForPath(path)
      ..name = _localBasename(path)
      ..mimeType = 'audio/local'
      ..size = stat?.size.toString() ?? '0'
      ..modifiedTime = stat?.modified
      ..appProperties = <String, String>{
        'source': 'local',
        'path': path,
      }
      ..properties = <String, String>{
        'source': 'local',
        'path': path,
      };
  }

  List<drive.File> _localTracksForAlbum(Map<String, String> album) {
    final albumId = _albumCacheKey(album, source: 'local_album_tracks');
    final cached = _albumTracksCache[albumId];
    if (cached != null && cached.isNotEmpty) return cached;

    final tracks = <drive.File>[];
    for (final record in _libraryTrackIndex.values) {
      if ((record['source'] ?? '') != 'local') continue;
      if ((record['albumId'] ?? '') != albumId &&
          (record['albumId'] ?? '') != (album['id'] ?? '')) {
        continue;
      }

      final localPath = (record['localPath'] ?? '').trim();
      if (localPath.isEmpty || !File(localPath).existsSync()) continue;
      tracks.add(_fileFromTrackIndexRecord(record));
    }

    final sorted = _sortTracksForAlbum(tracks);
    if (sorted.isNotEmpty) _albumTracksCache[albumId] = sorted;
    return sorted;
  }

  Future<void> _importLocalAudioFiles() async {
    if (_isScanning || _loadingMetadata) {
      _showError('Wait for the current scan to finish first.');
      return;
    }

    FilePickerResult? result;
    try {
      result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: const [
          'mp3',
          'flac',
          'wav',
          'm4a',
          'aac',
          'ogg',
          'wma',
        ],
      );
    } catch (e) {
      _showError('Local file picker failed: $e');
      return;
    }

    final paths = result?.files
            .map((file) => file.path?.trim() ?? '')
            .where((path) => path.isNotEmpty)
            .toSet()
            .toList() ??
        <String>[];

    if (paths.isEmpty) return;

    setState(() => _isScanning = true);
    _showSuccess('Importing ${paths.length} local audio files...');

    final albumsById = <String, Map<String, String>>{};
    final tracksByAlbum = <String, List<drive.File>>{};
    var importedTracks = 0;

    try {
      for (final path in paths) {
        final file = File(path);
        if (!await file.exists()) continue;

        final localFile = _localDriveFileFromPath(path);
        if (!DriveUtils.isAudio(localFile)) continue;

        final fallback = DriveUtils.getTrackMeta(localFile);
        TrackMetadata metadata;
        try {
          final raw = readMetadata(file, getImage: false);
          metadata = TrackMetadata(
            title: raw.title?.trim().isNotEmpty == true
                ? raw.title!.trim()
                : fallback['title'] ?? localFile.name ?? 'Unknown',
            artist: raw.artist?.trim().isNotEmpty == true
                ? raw.artist!.trim()
                : fallback['artist'] ?? 'Unknown Artist',
            album: raw.album?.trim().isNotEmpty == true
                ? raw.album!.trim()
                : 'Local Files',
            trackNumber: raw.trackNumber,
            discNumber: raw.discNumber,
            modifiedTime: localFile.modifiedTime?.toIso8601String(),
            size: localFile.size,
          );
        } catch (_) {
          metadata = TrackMetadata(
            title: fallback['title'] ?? localFile.name ?? 'Unknown',
            artist: fallback['artist'] ?? 'Unknown Artist',
            album: 'Local Files',
            modifiedTime: localFile.modifiedTime?.toIso8601String(),
            size: localFile.size,
          );
        }

        _metaStore.putMemory(localFile, metadata);
        final albumTitle = _cleanBrainValue(metadata.album) == ''
            ? 'Local Files'
            : metadata.album!.trim();
        final artist = _cleanBrainValue(metadata.artist).isEmpty
            ? 'Unknown Artist'
            : metadata.artist.trim();
        final albumId = _localAlbumId(albumTitle, artist);
        final existingAlbum = albumsById[albumId] ??
            _albums.firstWhere(
              (album) => (album['id'] ?? '') == albumId,
              orElse: () => <String, String>{},
            );
        final dateAdded = existingAlbum['dateAdded'] ??
            DateTime.now().millisecondsSinceEpoch.toString();

        final albumRecord = <String, String>{
          ...existingAlbum,
          'id': albumId,
          'albumKey': albumId,
          'source': 'local',
          'name': albumTitle,
          'displayName': albumTitle,
          'artist': artist,
          'cover': existingAlbum['cover'] ?? '',
          'dateAdded': dateAdded,
        };

        albumsById[albumId] = albumRecord;
        tracksByAlbum.putIfAbsent(albumId, () => <drive.File>[]).add(localFile);
        importedTracks++;
      }

      if (importedTracks == 0) {
        _showError('No supported local audio files were imported.');
        return;
      }

      final existingById = <String, Map<String, String>>{
        for (final album in _albums) (album['id'] ?? ''): album,
      };

      for (final entry in albumsById.entries) {
        final albumId = entry.key;
        final album = entry.value;
        final tracks = _sortTracksForAlbum(tracksByAlbum[albumId] ?? []);
        if (tracks.isEmpty) continue;

        _albumTracksCache[albumId] = tracks;
        _indexAlbumFromTracks(album, tracks, save: false);
        _indexTracksForAlbum(album, tracks);
        existingById[albumId] = album;
      }

      _albums = existingById.values
          .where((album) => (album['id'] ?? '').trim().isNotEmpty)
          .toList()
        ..sort((a, b) =>
            (a['displayName'] ?? a['name'] ?? '').compareTo(
              b['displayName'] ?? b['name'] ?? '',
            ));

      await _metaStore.persistNow();
      await _saveLibraryTrackIndex();
      await _saveLibraryBrain();
      await _persistAlbums();
      await _saveKnownTrackDurations();

      _librarySearchTextCache.clear();
      _invalidateHomeBrowseCache();
      _invalidateLibraryBrowseCache();
      _nowPlaying.refresh();

      if (mounted) setState(() {});
      _showSuccess('Imported $importedTracks local songs.');
    } catch (e) {
      _showError('Local import failed: $e');
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _loadMetadataForLocal(
    drive.File file, {
    Map<String, String>? albumRecord,
  }) async {
    final localPath = DriveUtils.localPath(file);
    if (localPath == null || localPath.isEmpty) return;

    try {
      final localFile = File(localPath);
      if (!await localFile.exists()) return;

      final cachedFresh = _metaStore.peekFresh(file);
      if (cachedFresh != null) return;

      final fallback = DriveUtils.getTrackMeta(file);
      final raw = readMetadata(localFile, getImage: false);
      final metadata = TrackMetadata(
        title: raw.title?.trim().isNotEmpty == true
            ? raw.title!.trim()
            : fallback['title'] ?? file.name ?? 'Unknown',
        artist: raw.artist?.trim().isNotEmpty == true
            ? raw.artist!.trim()
            : fallback['artist'] ?? 'Unknown Artist',
        album: raw.album?.trim().isNotEmpty == true ? raw.album!.trim() : null,
        trackNumber: raw.trackNumber,
        discNumber: raw.discNumber,
        modifiedTime: file.modifiedTime?.toIso8601String(),
        size: file.size,
      );

      await _metaStore.put(file, metadata);
      _indexTracksForAlbum(albumRecord ?? _viewingAlbum ?? <String, String>{}, [
        file,
      ]);
      _nowPlaying.refresh();
      if (mounted) setState(() {});
    } catch (_) {
      return;
    }
  }
}
