part of '../main.dart';

extension BuildHomeTabExtension on _MainScreenState {
  Widget buildHomeTab() {
    final colors = _safeColors(_currentDynamicColors);
    final spotlight = _spotlightAlbum();
    final recent = _recentBrainAlbums(limit: 14);
    final played = _lastPlayedAlbums(limit: 10);
    final heavy = _mostPlayedAlbums(limit: 10);
    final all = _homeDistinctAlbums([played, recent, heavy, _brainAlbums()], limit: 18);
    final hero = spotlight ?? (played.isNotEmpty ? played.first : recent.isNotEmpty ? recent.first : null);

    return Container(
      color: const Color(0xFF050505),
      child: CustomScrollView(
        key: const PageStorageKey('home_tab_monolithic_archive_v1'),
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 26, 18, 0),
            sliver: SliverToBoxAdapter(
              child: _ArchiveStatusHeader(
                colors: colors,
                isScanning: _loadingMetadata || _isScanning,
                status: _loadingMetadata ? _metadataStatusLabel() : (_exploreItems.isNotEmpty ? 'SYS_SYNC: OK' : 'SYS_SYNC: IDLE'),
                onSearch: () => _selectRootTab(1),
                onSources: () => _selectRootTab(2),
              ),
            ),
          ),
          if (_loadingMetadata)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
              sliver: SliverToBoxAdapter(
                child: _ArchiveFetchBlock(
                  label: _metadataStatusLabel(),
                  progress: _metadataTotal > 0 ? (_metadataDone / _metadataTotal).clamp(0.0, 1.0) : null,
                  accent: _archiveAccent(colors),
                  onTap: _openSettingsSheet,
                ),
              ),
            ),
          if (_loadingSaved || _isScanning)
            const SliverFillRemaining(
              child: Center(child: _ArchiveLoader()),
            )
          else if (_albums.isEmpty)
            SliverFillRemaining(
              child: _ArchiveEmptyState(onSources: () => _selectRootTab(2)),
            )
          else ...[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
              sliver: SliverToBoxAdapter(
                child: _CurrentRotationSlab(
                  hero: hero,
                  albums: all,
                  colors: colors,
                  player: _player,
                  onTap: hero == null ? null : () => _openAlbumByBrain(hero),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
              sliver: SliverToBoxAdapter(
                child: _HardwarePlaybackHud(
                  player: _player,
                  colors: colors,
                  onOpenPlayer: _openFullPlayer,
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 24, 18, 0),
              sliver: SliverToBoxAdapter(
                child: _ArchiveDirectoryBlock(
                  all: _brainAlbums(),
                  recent: recent,
                  played: played,
                  heavy: heavy,
                  colors: colors,
                  onLibrary: () => _selectRootTab(1),
                  onSources: () => _selectRootTab(2),
                  onAlbum: _openAlbumByBrain,
                ),
              ),
            ),
            if (played.isNotEmpty)
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 26, 0, 0),
                sliver: SliverToBoxAdapter(
                  child: _RecentDigsRail(
                    title: 'RECENT DIGS',
                    albums: played,
                    colors: colors,
                    onTap: _openAlbumByBrain,
                  ),
                ),
              ),
            if (recent.isNotEmpty)
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 26, 0, 0),
                sliver: SliverToBoxAdapter(
                  child: _RecentDigsRail(
                    title: 'NEWLY INDEXED',
                    albums: recent,
                    colors: colors,
                    onTap: _openAlbumByBrain,
                    compact: true,
                  ),
                ),
              ),
            if (_playHistory.isNotEmpty)
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 28, 18, 230),
                sliver: SliverToBoxAdapter(
                  child: _TrackResiduePanel(
                    history: _playHistory.take(8).toList(),
                    colors: colors,
                    onTap: (item) {
                      final album = _albumById(item['albumId'] ?? '');
                      if (album != null) _openAlbum(album);
                    },
                  ),
                ),
              )
            else
              const SliverToBoxAdapter(child: SizedBox(height: 230)),
          ],
        ],
      ),
    );
  }

  List<Map<String, String>> _homeDistinctAlbums(
    List<List<Map<String, String>>> groups, {
    int limit = 8,
  }) {
    final seen = <String>{};
    final out = <Map<String, String>>[];
    for (final group in groups) {
      for (final album in group) {
        final id = album['albumId'] ?? album['id'] ?? album['name'] ?? '';
        if (id.isEmpty || seen.contains(id)) continue;
        seen.add(id);
        out.add(album);
        if (out.length >= limit) return out;
      }
    }
    return out;
  }
}

Color _archiveAccent(List<Color> colors) {
  final safe = _safeColors(colors);
  final candidates = [safe[1], safe[2], safe[0], _cyan, _pink];
  for (final color in candidates) {
    if (color.computeLuminance() > 0.08) return color;
  }
  return _cyan;
}

TextStyle _archiveDisplay({
  required double size,
  Color color = const Color(0xFFF4F4F5),
  double spacing = -0.8,
  FontWeight weight = FontWeight.w900,
  double height = 1.0,
}) {
  return GoogleFonts.spaceGrotesk(
    color: color,
    fontSize: size,
    letterSpacing: spacing,
    fontWeight: weight,
    height: height,
  );
}

TextStyle _archiveMono({
  required double size,
  Color color = const Color(0xFF71717A),
  double spacing = 0.0,
  FontWeight weight = FontWeight.w800,
  double height = 1.2,
}) {
  return GoogleFonts.jetBrainsMono(
    color: color,
    fontSize: size,
    letterSpacing: spacing,
    fontWeight: weight,
    height: height,
  );
}

String _archiveAlbumName(Map<String, String>? album) {
  if (album == null) return 'NO OBJECT SELECTED';
  return album['displayName'] ?? album['name'] ?? 'UNKNOWN OBJECT';
}

String _archiveArtist(Map<String, String>? album) {
  if (album == null) return 'PRIVATE DRIVE ARCHIVE';
  final artist = album['artist'] ?? '';
  return artist.trim().isEmpty ? 'UNKNOWN ARTIST' : artist.trim();
}

String _archiveCover(Map<String, String>? album) {
  if (album == null) return '';
  return album['cover'] ?? album['coverUrl'] ?? '';
}

String _archiveTrackCount(Map<String, String> album) {
  final tracks = album['trackCount'] ?? album['count'] ?? '';
  final value = int.tryParse(tracks);
  if (value == null || value <= 0) return '[-- ITEMS]';
  return '[${value.toString().padLeft(2, '0')} ITEMS]';
}

String _clock(Duration? duration) {
  if (duration == null || duration.inMilliseconds < 0) return '--:--';
  final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
  final hours = duration.inHours;
  if (hours > 0) return '$hours:$minutes:$seconds';
  return '$minutes:$seconds';
}

class _ArchiveStatusHeader extends StatelessWidget {
  final List<Color> colors;
  final bool isScanning;
  final String status;
  final VoidCallback onSearch;
  final VoidCallback onSources;

  const _ArchiveStatusHeader({
    required this.colors,
    required this.isScanning,
    required this.status,
    required this.onSearch,
    required this.onSources,
  });

  @override
  Widget build(BuildContext context) {
    final accent = isScanning ? _pink : _archiveAccent(colors);
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: onSources,
            behavior: HitTestBehavior.opaque,
            child: Row(
              children: [
                _PhosphorDot(color: accent, active: isScanning),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    '[${status.toUpperCase()}]',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _archiveMono(
                      size: 11,
                      color: const Color(0xFFF4F4F5),
                      spacing: 0.7,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        _ArchiveIconButton(icon: Icons.search_rounded, color: accent, onTap: onSearch),
        const SizedBox(width: 8),
        _ArchiveIconButton(icon: Icons.storage_rounded, color: accent, onTap: onSources),
      ],
    );
  }
}

class _PhosphorDot extends StatefulWidget {
  final Color color;
  final bool active;
  const _PhosphorDot({required this.color, this.active = true});

  @override
  State<_PhosphorDot> createState() => _PhosphorDotState();
}

class _PhosphorDotState extends State<_PhosphorDot> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final pulse = widget.active ? (0.35 + _controller.value * 0.65) : 0.45;
        return Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: widget.color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: widget.color.withOpacity(pulse), blurRadius: 18 * pulse, spreadRadius: 3 * pulse)],
          ),
        );
      },
    );
  }
}

class _ArchiveIconButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _ArchiveIconButton({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: const Color(0xFF121214),
          border: Border.all(color: color.withOpacity(0.45), width: 1),
          boxShadow: [BoxShadow(color: color.withOpacity(0.18), blurRadius: 0, spreadRadius: 1, offset: const Offset(3, 3))],
        ),
        child: Icon(icon, color: const Color(0xFFF4F4F5), size: 21),
      ),
    );
  }
}

class _ArchiveFetchBlock extends StatelessWidget {
  final String label;
  final double? progress;
  final Color accent;
  final VoidCallback onTap;
  const _ArchiveFetchBlock({required this.label, required this.progress, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(13),
        color: const Color(0xFF121214),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('[FETCHING]', style: _archiveMono(size: 11, color: accent, spacing: 1.4)),
                const SizedBox(width: 10),
                Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: _archiveMono(size: 11, color: const Color(0xFFF4F4F5)))),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: progress,
              minHeight: 3,
              backgroundColor: const Color(0xFF050505),
              valueColor: AlwaysStoppedAnimation<Color>(accent),
            ),
          ],
        ),
      ),
    );
  }
}

class _CurrentRotationSlab extends StatelessWidget {
  final Map<String, String>? hero;
  final List<Map<String, String>> albums;
  final List<Color> colors;
  final AudioPlayer player;
  final VoidCallback? onTap;

  const _CurrentRotationSlab({
    required this.hero,
    required this.albums,
    required this.colors,
    required this.player,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final accent = _archiveAccent(colors);
    final title = _archiveAlbumName(hero);
    final artist = _archiveArtist(hero);
    final cover = _archiveCover(hero);
    final gradient = getAlbumGradient(title);
    final screenWidth = MediaQuery.of(context).size.width;
    final slabSize = math.min(screenWidth, 430.0);

    return GestureDetector(
      onTap: onTap == null
          ? null
          : () {
              HapticFeedback.mediumImpact();
              onTap!();
            },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.only(bottom: 22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Text('CURRENT ROTATION', style: _archiveMono(size: 11, color: accent, spacing: 2.2)),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: slabSize + 160,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    child: Container(
                      width: slabSize,
                      height: slabSize,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: gradient),
                        boxShadow: [BoxShadow(color: accent.withOpacity(0.74), blurRadius: 0, spreadRadius: 0, offset: const Offset(12, 12))],
                      ),
                      child: cover.isNotEmpty
                          ? _coverImage(
                              cover,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: title, colors: gradient, radius: 0, small: false),
                            )
                          : _AlbumFallbackCover(name: title, colors: gradient, radius: 0, small: false),
                    ),
                  ),
                  Positioned(
                    right: 16,
                    top: 28,
                    child: _CoverSpineStack(albums: albums, accent: accent),
                  ),
                  Positioned(
                    left: 18,
                    right: 18,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(0, 18, 0, 0),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, const Color(0xFF050505).withOpacity(0.88), const Color(0xFF050505)],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title.toUpperCase(),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: _archiveDisplay(size: 42, spacing: -2.0, height: 0.90),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            artist.toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _archiveMono(size: 12, color: const Color(0xFFF4F4F5), spacing: 1.2),
                          ),
                          const SizedBox(height: 10),
                          StreamBuilder<Duration?>(
                            stream: player.durationStream,
                            builder: (context, snapshot) {
                              final track = _nowPlaying.track;
                              final spec = track == null ? 'STREAM: DRIVE' : DriveUtils.audioQualityLabel(track, snapshot.data);
                              final name = track?.name ?? 'NO ACTIVE TRANSPORT';
                              return Text(
                                'ROOT/DRIVE/${name.toUpperCase()}  ·  $spec',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: _archiveMono(size: 10.5, color: const Color(0xFF71717A), spacing: 0.3, height: 1.45),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CoverSpineStack extends StatelessWidget {
  final List<Map<String, String>> albums;
  final Color accent;
  const _CoverSpineStack({required this.albums, required this.accent});

  @override
  Widget build(BuildContext context) {
    final shown = albums.take(5).toList();
    return SizedBox(
      width: 92,
      height: 270,
      child: Stack(
        children: [
          for (int i = 0; i < shown.length; i++)
            Positioned(
              top: i * 38,
              right: i.isEven ? 0 : 10,
              child: Transform.rotate(
                angle: (i - 2) * 0.035,
                child: _SharpCover(album: shown[i], size: 76, accent: i == 0 ? accent : const Color(0xFF252529)),
              ),
            ),
        ],
      ),
    );
  }
}

class _SharpCover extends StatelessWidget {
  final Map<String, String> album;
  final double size;
  final Color accent;
  const _SharpCover({required this.album, required this.size, required this.accent});

  @override
  Widget build(BuildContext context) {
    final name = _archiveAlbumName(album);
    final cover = _archiveCover(album);
    final gradient = getAlbumGradient(name);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: gradient),
        boxShadow: [BoxShadow(color: accent.withOpacity(0.55), blurRadius: 0, offset: const Offset(5, 5))],
        border: Border.all(color: const Color(0xFF050505), width: 2),
      ),
      child: cover.isNotEmpty
          ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: name, colors: gradient, radius: 0, small: true))
          : _AlbumFallbackCover(name: name, colors: gradient, radius: 0, small: true),
    );
  }
}

class _HardwarePlaybackHud extends StatelessWidget {
  final AudioPlayer player;
  final List<Color> colors;
  final VoidCallback onOpenPlayer;
  const _HardwarePlaybackHud({required this.player, required this.colors, required this.onOpenPlayer});

  @override
  Widget build(BuildContext context) {
    final accent = _archiveAccent(colors);
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onOpenPlayer();
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF121214),
          border: Border.all(color: accent.withOpacity(0.56), width: 1),
          boxShadow: [BoxShadow(color: accent.withOpacity(0.28), blurRadius: 0, offset: const Offset(4, 4))],
        ),
        child: StreamBuilder<PlayerState>(
          stream: player.playerStateStream,
          builder: (context, stateSnap) {
            final isPlaying = stateSnap.data?.playing ?? player.playing;
            return Row(
              children: [
                GestureDetector(
                  onTap: () {
                    HapticFeedback.heavyImpact();
                    isPlaying ? player.pause() : player.play();
                  },
                  child: Container(
                    width: 48,
                    height: 48,
                    color: accent,
                    child: Icon(isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.black, size: 30),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(child: _MiniSpectrum(color: accent, active: isPlaying)),
                          const SizedBox(width: 10),
                          StreamBuilder<Duration>(
                            stream: player.positionStream,
                            builder: (context, snap) => Text(_clock(snap.data), style: _archiveMono(size: 11, color: const Color(0xFFF4F4F5))),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        (_nowPlaying.track?.name ?? 'TRANSPORT STANDBY').toUpperCase(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _archiveMono(size: 10.5, color: const Color(0xFF71717A), spacing: 0.3),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _MiniSpectrum extends StatelessWidget {
  final Color color;
  final bool active;
  const _MiniSpectrum({required this.color, required this.active});

  @override
  Widget build(BuildContext context) {
    final bars = <double>[0.24, 0.56, 0.36, 0.78, 0.42, 0.92, 0.30, 0.66, 0.52, 0.82, 0.34, 0.72];
    return SizedBox(
      height: 28,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (int i = 0; i < bars.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 1.4),
                child: TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0.2, end: active ? bars[i] : 0.18),
                  duration: Duration(milliseconds: active ? 150 + i * 17 : 90),
                  curve: Curves.linear,
                  builder: (_, value, __) => FractionallySizedBox(
                    heightFactor: value,
                    alignment: Alignment.bottomCenter,
                    child: Container(color: i.isEven ? color : const Color(0xFFF4F4F5).withOpacity(0.55)),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ArchiveDirectoryBlock extends StatelessWidget {
  final List<Map<String, String>> all;
  final List<Map<String, String>> recent;
  final List<Map<String, String>> played;
  final List<Map<String, String>> heavy;
  final List<Color> colors;
  final VoidCallback onLibrary;
  final VoidCallback onSources;
  final ValueChanged<Map<String, String>> onAlbum;

  const _ArchiveDirectoryBlock({
    required this.all,
    required this.recent,
    required this.played,
    required this.heavy,
    required this.colors,
    required this.onLibrary,
    required this.onSources,
    required this.onAlbum,
  });

  @override
  Widget build(BuildContext context) {
    final accent = _archiveAccent(colors);
    final pickList = [...played, ...heavy, ...recent, ...all];
    final randomPick = pickList.isEmpty ? null : pickList[DateTime.now().millisecondsSinceEpoch % pickList.length];
    return Container(
      decoration: const BoxDecoration(color: Color(0xFF121214)),
      child: Column(
        children: [
          _DirectoryRow(
            label: 'LIBRARY/CRATES',
            meta: '[${all.length.toString().padLeft(3, '0')} ALBUMS]',
            accent: accent,
            icon: Icons.all_inbox_rounded,
            onTap: onLibrary,
          ),
          _DirectoryRow(
            label: 'DRIVE/SOURCES',
            meta: '[SCAN + FOLDERS]',
            accent: _accentBlue,
            icon: Icons.storage_rounded,
            onTap: onSources,
          ),
          _DirectoryRow(
            label: 'HEAVY/ROTATION',
            meta: '[${heavy.length.toString().padLeft(2, '0')} ITEMS]',
            accent: _pink,
            icon: Icons.bolt_rounded,
            onTap: heavy.isEmpty ? onLibrary : () => onAlbum(heavy.first),
          ),
          _DirectoryRow(
            label: 'CRATE/DICE',
            meta: randomPick == null ? '[NO SIGNAL]' : '[RANDOM PULL]',
            accent: _cyan,
            icon: Icons.casino_rounded,
            onTap: randomPick == null ? onLibrary : () => onAlbum(randomPick),
          ),
        ],
      ),
    );
  }
}

class _DirectoryRow extends StatelessWidget {
  final String label;
  final String meta;
  final Color accent;
  final IconData icon;
  final VoidCallback onTap;
  const _DirectoryRow({required this.label, required this.meta, required this.accent, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.075), width: 1)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 13),
        child: Row(
          children: [
            Icon(icon, color: accent, size: 19),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: _archiveMono(size: 13, color: const Color(0xFFF4F4F5), spacing: 0.4))),
            Text(meta, style: _archiveMono(size: 11, color: const Color(0xFF71717A), spacing: 0.2)),
            const SizedBox(width: 8),
            Icon(Icons.arrow_forward_rounded, color: accent, size: 17),
          ],
        ),
      ),
    );
  }
}

class _RecentDigsRail extends StatelessWidget {
  final String title;
  final List<Map<String, String>> albums;
  final List<Color> colors;
  final ValueChanged<Map<String, String>> onTap;
  final bool compact;
  const _RecentDigsRail({required this.title, required this.albums, required this.colors, required this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final accent = _archiveAccent(colors);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 18),
          child: Row(
            children: [
              Text(title, style: _archiveMono(size: 12, color: const Color(0xFFF4F4F5), spacing: 1.8)),
              const SizedBox(width: 10),
              Expanded(child: Container(height: 1, color: accent.withOpacity(0.45))),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: compact ? 174 : 205,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: albums.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => _ArchiveAlbumTile(
              album: albums[i],
              width: compact ? 118 : 148,
              imageSize: compact ? 118 : 148,
              accent: i == 0 ? accent : const Color(0xFF252529),
              onTap: () => onTap(albums[i]),
            ),
          ),
        ),
      ],
    );
  }
}

class _ArchiveAlbumTile extends StatelessWidget {
  final Map<String, String> album;
  final double width;
  final double imageSize;
  final Color accent;
  final VoidCallback onTap;
  const _ArchiveAlbumTile({required this.album, required this.width, required this.imageSize, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = _archiveAlbumName(album);
    final artist = _archiveArtist(album);
    final cover = _archiveCover(album);
    final gradient = getAlbumGradient(name);
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: imageSize,
              height: imageSize,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: gradient),
                boxShadow: [BoxShadow(color: accent.withOpacity(0.60), blurRadius: 0, offset: const Offset(5, 5))],
              ),
              child: cover.isNotEmpty
                  ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: name, colors: gradient, radius: 0, small: true))
                  : _AlbumFallbackCover(name: name, colors: gradient, radius: 0, small: true),
            ),
            const SizedBox(height: 9),
            Text(name.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _archiveMono(size: 10.5, color: const Color(0xFFF4F4F5), spacing: 0.4)),
            const SizedBox(height: 2),
            Text(artist.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _archiveMono(size: 9.5, color: const Color(0xFF71717A), spacing: 0.2)),
          ],
        ),
      ),
    );
  }
}

class _TrackResiduePanel extends StatelessWidget {
  final List<Map<String, String>> history;
  final List<Color> colors;
  final ValueChanged<Map<String, String>> onTap;
  const _TrackResiduePanel({required this.history, required this.colors, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = _archiveAccent(colors);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('TRACK RESIDUE', style: _archiveMono(size: 12, color: const Color(0xFFF4F4F5), spacing: 1.8)),
            const SizedBox(width: 10),
            Expanded(child: Container(height: 1, color: accent.withOpacity(0.45))),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          color: const Color(0xFF121214),
          child: Column(
            children: [
              for (final item in history)
                _ResidueRow(
                  item: item,
                  accent: accent,
                  onTap: () => onTap(item),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ResidueRow extends StatelessWidget {
  final Map<String, String> item;
  final Color accent;
  final VoidCallback onTap;
  const _ResidueRow({required this.item, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final title = item['title'] ?? 'TRACK';
    final artist = item['artist'] ?? 'UNKNOWN';
    final cover = item['cover'] ?? '';
    final gradient = getAlbumGradient(title);
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        height: 58,
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.075)))),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(gradient: LinearGradient(colors: gradient), boxShadow: [BoxShadow(color: accent.withOpacity(0.35), blurRadius: 0, offset: const Offset(3, 3))]),
              child: cover.isNotEmpty
                  ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: title, colors: gradient, radius: 0, small: true))
                  : _AlbumFallbackCover(name: title, colors: gradient, radius: 0, small: true),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(title.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _archiveMono(size: 11, color: const Color(0xFFF4F4F5)))),
            const SizedBox(width: 8),
            Text(artist.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: _archiveMono(size: 9.5, color: const Color(0xFF71717A))),
          ],
        ),
      ),
    );
  }
}

class _ArchiveLoader extends StatelessWidget {
  const _ArchiveLoader();

  @override
  Widget build(BuildContext context) {
    return Text('[FETCHING ARCHIVE]', style: _archiveMono(size: 12, color: _pink, spacing: 1.5));
  }
}

class _ArchiveEmptyState extends StatelessWidget {
  final VoidCallback onSources;
  const _ArchiveEmptyState({required this.onSources});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('NO ARCHIVE', style: _archiveDisplay(size: 40, spacing: -1.6)),
            const SizedBox(height: 10),
            Text('CONNECT A DRIVE SOURCE TO INDEX PRIVATE AUDIO.', textAlign: TextAlign.center, style: _archiveMono(size: 11, color: const Color(0xFF71717A), spacing: 0.5, height: 1.45)),
            const SizedBox(height: 22),
            GestureDetector(
              onTap: onSources,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                color: const Color(0xFFF4F4F5),
                child: Text('OPEN SOURCES', style: _archiveMono(size: 12, color: Colors.black, spacing: 1.2)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
