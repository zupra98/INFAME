part of '../main.dart';

// ─── Vinyl Disc ─────────────────────────────────────────────────────────────
class _VinylDisc extends StatelessWidget {
  final double size;
  final String? coverUrl;
  final List<Color> colors;
  final bool showGrooves;

  const _VinylDisc({
    required this.size,
    required this.coverUrl,
    required this.colors,
    this.showGrooves = true,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    final centerSize = size * 0.52;
    final holeSize = size * 0.075;

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  Colors.grey.shade900,
                  Colors.black,
                  const Color(0xFF050506),
                ],
                stops: const [0.0, 0.58, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: safe[0].withOpacity(0.38),
                  blurRadius: size * 0.16,
                  spreadRadius: size * 0.018,
                  offset: Offset(0, size * 0.055),
                ),
              ],
            ),
          ),
          if (showGrooves) ...[
            _VinylRing(size: size * 0.86),
            _VinylRing(size: size * 0.70),
            _VinylRing(size: size * 0.34),
          ],
          Container(
            width: centerSize,
            height: centerSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: safe,
              ),
              border: Border.all(color: Colors.white.withOpacity(0.10), width: 1),
              image: coverUrl != null && coverUrl!.isNotEmpty
                  ? DecorationImage(image: _coverProvider(coverUrl!)!, fit: BoxFit.cover)
                  : null,
            ),
            child: coverUrl == null || coverUrl!.isEmpty
                ? Icon(
                    Icons.music_note_rounded,
                    size: size * 0.22,
                    color: Colors.white.withOpacity(0.50),
                  )
                : null,
          ),
          Container(
            width: holeSize,
            height: holeSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _bg,
              border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
            ),
          ),
        ],
      ),
    );
  }
}

class _VinylRing extends StatelessWidget {
  final double size;

  const _VinylRing({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withOpacity(0.055), width: 1),
      ),
    );
  }
}

// ─── Lyrics Sheet ───────────────────────────────────────────────────────────
class _LyricsResult {
  final String trackName;
  final String artistName;
  final String? plainLyrics;
  final String? syncedLyrics;

  const _LyricsResult({
    required this.trackName,
    required this.artistName,
    this.plainLyrics,
    this.syncedLyrics,
  });

  bool get hasSynced => syncedLyrics != null && syncedLyrics!.trim().isNotEmpty;
  bool get hasPlain => plainLyrics != null && plainLyrics!.trim().isNotEmpty;
}

class _LyricLine {
  final Duration time;
  final String text;

  const _LyricLine({required this.time, required this.text});
}

class _LyricsSheet extends StatefulWidget {
  final AudioPlayer player;
  final Map<String, String> meta;
  final List<Color> colors;

  const _LyricsSheet({
    required this.player,
    required this.meta,
    required this.colors,
  });

  @override
  State<_LyricsSheet> createState() => _LyricsSheetState();
}

class _LyricsSheetState extends State<_LyricsSheet> {
  late final Future<_LyricsResult?> _lyricsFuture;
  final ScrollController _scrollController = ScrollController();
  int _lastActiveLine = -1;

  @override
  void initState() {
    super.initState();
    _lyricsFuture = _fetchLyrics();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<_LyricsResult?> _fetchLyrics() async {
    final title = (widget.meta['title'] ?? '').trim();
    final artist = (widget.meta['artist'] ?? '').trim();

    if (title.isEmpty) return null;

    final params = <String, String>{'track_name': title};

    if (artist.isNotEmpty && artist != 'Unknown Artist') {
      params['artist_name'] = artist;
    }

    Future<List<dynamic>> request(Uri uri) async {
      final res = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'InfameApp/1.0',
        },
      );

      if (res.statusCode != 200) return [];
      final decoded = json.decode(res.body);
      return decoded is List ? decoded : [];
    }

    List<dynamic> results = await request(Uri.https('lrclib.net', '/api/search', params));

    if (results.isEmpty) {
      final fallbackQuery = artist.isNotEmpty && artist != 'Unknown Artist'
          ? '$artist $title'
          : title;
      results = await request(Uri.https('lrclib.net', '/api/search', {'q': fallbackQuery}));
    }

    if (results.isEmpty) return null;

    Map<String, dynamic>? best;

    for (final item in results) {
      if (item is! Map<String, dynamic>) continue;
      final synced = item['syncedLyrics'];
      if (synced is String && synced.trim().isNotEmpty) {
        best = item;
        break;
      }
      best ??= item;
    }

    if (best == null) return null;

    return _LyricsResult(
      trackName: (best['trackName'] ?? title).toString(),
      artistName: (best['artistName'] ?? artist).toString(),
      plainLyrics: best['plainLyrics']?.toString(),
      syncedLyrics: best['syncedLyrics']?.toString(),
    );
  }

  List<_LyricLine> _parseSyncedLyrics(String raw) {
    final lines = <_LyricLine>[];

    for (final rawLine in raw.split(String.fromCharCode(10))) {
      final line = rawLine.trim();
      if (!line.startsWith('[')) continue;

      final end = line.indexOf(']');
      if (end <= 1) continue;

      final stamp = line.substring(1, end);
      final text = line.substring(end + 1).trim();
      if (text.isEmpty) continue;

      final timeParts = stamp.split(':');
      if (timeParts.length != 2) continue;

      final minutes = int.tryParse(timeParts[0]) ?? 0;
      final secondParts = timeParts[1].split('.');
      final seconds = int.tryParse(secondParts[0]) ?? 0;
      final fraction = secondParts.length > 1 ? secondParts[1] : '0';
      final padded = fraction.padRight(3, '0');
      final millis = int.tryParse(padded.substring(0, 3)) ?? 0;

      lines.add(
        _LyricLine(
          time: Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
          text: text,
        ),
      );
    }

    lines.sort((a, b) => a.time.compareTo(b.time));
    return lines;
  }

  int _activeLineIndex(List<_LyricLine> lines, Duration pos) {
    if (lines.isEmpty) return -1;

    int active = 0;
    for (int i = 0; i < lines.length; i++) {
      if (pos >= lines[i].time) {
        active = i;
      } else {
        break;
      }
    }

    return active;
  }

  void _scrollToActiveLine(int active) {
    if (active == _lastActiveLine || !_scrollController.hasClients) return;
    _lastActiveLine = active;

    final target = (active * 44.0).clamp(0.0, _scrollController.position.maxScrollExtent);

    _scrollController.animateTo(
      target,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = _safeColors(widget.colors);

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.82,
        decoration: BoxDecoration(
          color: _bg.withOpacity(0.96),
          borderRadius: BorderRadius.zero,
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.12))),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              colors[0].withOpacity(0.34),
              _bg.withOpacity(0.98),
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 24),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                    ),
                    const Spacer(),
                    Text(
                      'Lyrics',
                      style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w900),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
                Text(
                  '${widget.meta['title'] ?? ''} • ${widget.meta['artist'] ?? ''}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 22),
                Expanded(
                  child: FutureBuilder<_LyricsResult?>(
                    future: _lyricsFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return Center(child: CircularProgressIndicator(color: colors[1]));
                      }

                      if (snapshot.hasError) {
                        return Center(
                          child: Text(
                            'Could not load lyrics.',
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      final result = snapshot.data;
                      if (result == null || (!result.hasSynced && !result.hasPlain)) {
                        return Center(
                          child: Text(
                            'No lyrics found for this track.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      if (result.hasSynced) {
                        final lines = _parseSyncedLyrics(result.syncedLyrics!);

                        if (lines.isNotEmpty) {
                          return StreamBuilder<Duration>(
                            stream: widget.player.positionStream,
                            builder: (context, posSnap) {
                              final pos = posSnap.data ?? Duration.zero;
                              final active = _activeLineIndex(lines, pos);

                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                if (mounted) _scrollToActiveLine(active);
                              });

                              return ListView.builder(
                                controller: _scrollController,
                                physics: const BouncingScrollPhysics(),
                                padding: const EdgeInsets.only(top: 80, bottom: 160),
                                itemCount: lines.length,
                                itemBuilder: (context, i) {
                                  final isActive = i == active;
                                  return AnimatedDefaultTextStyle(
                                    duration: const Duration(milliseconds: 200),
                                    curve: Curves.easeOutCubic,
                                    style: GoogleFonts.inter(
                                      fontSize: isActive ? 23 : 19,
                                      height: 1.35,
                                      fontWeight: isActive ? FontWeight.w900 : FontWeight.w700,
                                      color: isActive ? Colors.white : Colors.white.withOpacity(0.38),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 8),
                                      child: Text(lines[i].text),
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        }
                      }

                      final plain = result.plainLyrics ?? result.syncedLyrics ?? '';

                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Text(
                          plain,
                          style: GoogleFonts.inter(
                            fontSize: 18,
                            height: 1.55,
                            fontWeight: FontWeight.w700,
                            color: Colors.white.withOpacity(0.86),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Lyrics by LRCLIB',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Queue Sheet ────────────────────────────────────────────────────────────
class _QueueSheet extends StatelessWidget {
  final List<Color> colors;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _QueueSheet({
    required this.colors,
    required this.onPlayFromQueue,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);

    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.78,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.zero,
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.12))),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              safe[0].withOpacity(0.30),
              _bg.withOpacity(0.98),
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                    ),
                    const Spacer(),
                    Text(
                      'Queue',
                      style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w900),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
                Text(
                  '${_nowPlaying.queue.length} tracks',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: ListenableBuilder(
                    listenable: _nowPlaying,
                    builder: (context, _) {
                      if (_nowPlaying.queue.isEmpty) {
                        return Center(
                          child: Text(
                            'Queue is empty.',
                            style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                          ),
                        );
                      }

                      return ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        itemCount: _nowPlaying.queue.length,
                        itemBuilder: (context, i) {
                          final track = _nowPlaying.queue[i];
                          final meta = DriveUtils.getTrackMeta(track);
                          final isActive = i == _nowPlaying.queueIndex;

                          return GestureDetector(
                            onTap: () async {
                              await onPlayFromQueue(track, i);
                            },
                            behavior: HitTestBehavior.opaque,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                              decoration: BoxDecoration(
                                color: isActive ? Colors.white.withOpacity(0.11) : Colors.transparent,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isActive ? safe[1].withOpacity(0.40) : Colors.transparent,
                                ),
                              ),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 28,
                                    child: Text(
                                      '${i + 1}',
                                      style: GoogleFonts.inter(
                                        color: isActive ? safe[1] : _textSub,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          meta['title'] ?? 'Unknown',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.inter(
                                            color: isActive ? safe[1] : _textPri,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          meta['artist'] ?? 'Unknown Artist',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.inter(
                                            color: _textSub,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (isActive)
                                    Icon(Icons.graphic_eq_rounded, color: safe[1], size: 22),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Floating Player Bar ────────────────────────────────────────────────────
class _PlayerFloatingBar extends StatelessWidget {
  final AudioPlayer player;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _PlayerFloatingBar({
    required this.player,
    required this.onNext,
    required this.onPrev,
    required this.onPlayFromQueue,
  });

  void _openFullScreenPlayer(BuildContext context) {
    HapticFeedback.selectionClick();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.82),
      builder: (_) {
        return _FullScreenPlayerSheet(
          player: player,
          onNext: onNext,
          onPrev: onPrev,
          onPlayFromQueue: onPlayFromQueue,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _nowPlaying,
      builder: (ctx, _) {
        final track = _nowPlaying.track;
        if (track == null) return const SizedBox.shrink();

        final meta = DriveUtils.getTrackMeta(track);
        final coverUrl = _nowPlaying.currentCoverUrl;
        final colors = _safeColors(_nowPlaying.dynamicColors);
        final accent = colors[1];

        return StreamBuilder<PlayerState>(
          stream: player.playerStateStream,
          builder: (_, stateSnap) {
            final state = stateSnap.data;
            final isPlaying = state?.playing ?? false;
            final isLoading = state?.processingState == ProcessingState.loading ||
                state?.processingState == ProcessingState.buffering;

            return ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  height: 76,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.72),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: Colors.white.withOpacity(0.10), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withOpacity(0.18),
                        blurRadius: 30,
                        offset: const Offset(0, 14),
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.40),
                        blurRadius: 24,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: StreamBuilder<Duration>(
                          stream: player.positionStream,
                          builder: (_, posSnap) {
                            return StreamBuilder<Duration?>(
                              stream: player.durationStream,
                              builder: (_, durSnap) {
                                final dur = durSnap.data ?? Duration.zero;
                                final pos = posSnap.data ?? Duration.zero;
                                final prog = dur.inMilliseconds > 0
                                    ? (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0)
                                    : 0.0;
                                return LinearProgressIndicator(
                                  value: prog,
                                  minHeight: 2,
                                  backgroundColor: Colors.white.withOpacity(0.08),
                                  valueColor: AlwaysStoppedAnimation<Color>(accent),
                                );
                              },
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 9, 8, 10),
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: () => _openFullScreenPlayer(context),
                              behavior: HitTestBehavior.opaque,
                              child: Row(
                                children: [
                                  _PremiumCoverArt(
                                    heroTag: 'now_playing_artwork',
                                    coverUrl: coverUrl,
                                    colors: colors,
                                    size: 56,
                                    radius: 15,
                                    shadow: false,
                                  ),
                                  const SizedBox(width: 12),
                                ],
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: () => _openFullScreenPlayer(context),
                                behavior: HitTestBehavior.opaque,
                                child: AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 220),
                                  switchInCurve: Curves.easeOutCubic,
                                  switchOutCurve: Curves.easeInCubic,
                                  transitionBuilder: (child, animation) {
                                    final offset = Tween<Offset>(
                                      begin: const Offset(0.04, 0),
                                      end: Offset.zero,
                                    ).animate(animation);
                                    return FadeTransition(
                                      opacity: animation,
                                      child: SlideTransition(position: offset, child: child),
                                    );
                                  },
                                  child: Column(
                                    key: ValueKey('${track.id}_${meta['title']}_${meta['artist']}'),
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        meta['title'] ?? 'Unknown',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.inter(
                                          fontSize: 14.5,
                                          height: 1.05,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.white,
                                          letterSpacing: -0.25,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        meta['artist'] ?? 'Unknown Artist',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.inter(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white.withOpacity(0.54),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              icon: Icon(Icons.skip_previous_rounded, color: Colors.white.withOpacity(0.70)),
                              onPressed: () {
                                HapticFeedback.selectionClick();
                                onPrev();
                              },
                            ),
                            GestureDetector(
                              onTap: () {
                                if (isLoading) return;
                                HapticFeedback.lightImpact();
                                isPlaying ? player.pause() : player.play();
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 160),
                                curve: Curves.easeOutCubic,
                                width: 45,
                                height: 45,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: accent.withOpacity(isPlaying ? 0.28 : 0.16),
                                      blurRadius: 20,
                                      spreadRadius: 1,
                                    ),
                                  ],
                                ),
                                child: isLoading
                                    ? const Padding(
                                        padding: EdgeInsets.all(13),
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                          strokeWidth: 2.2,
                                        ),
                                      )
                                    : Icon(
                                        isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                        color: Colors.black,
                                        size: 29,
                                      ),
                              ),
                            ),
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              icon: Icon(Icons.skip_next_rounded, color: Colors.white.withOpacity(0.86)),
                              onPressed: () {
                                HapticFeedback.selectionClick();
                                onNext();
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _PremiumCoverArt extends StatelessWidget {
  final String? heroTag;
  final String? coverUrl;
  final List<Color> colors;
  final double size;
  final double radius;
  final bool shadow;

  const _PremiumCoverArt({
    super.key,
    this.heroTag,
    required this.coverUrl,
    required this.colors,
    required this.size,
    required this.radius,
    this.shadow = true,
  });

  @override
  Widget build(BuildContext context) {
    final provider = _coverProvider(coverUrl);
    final safe = _safeColors(colors);

    Widget artwork = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [safe[0], safe[1], safe[2]],
        ),
        boxShadow: shadow
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.34),
                  blurRadius: 34,
                  offset: const Offset(0, 18),
                ),
                BoxShadow(
                  color: safe[1].withOpacity(0.26),
                  blurRadius: 44,
                  spreadRadius: 1,
                ),
              ]
            : const [],
      ),
      clipBehavior: Clip.antiAlias,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 260),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        child: provider == null
            ? Center(
                key: const ValueKey('empty_cover'),
                child: Icon(
                  Icons.music_note_rounded,
                  color: Colors.white.withOpacity(0.48),
                  size: size * 0.30,
                ),
              )
            : Image(
                key: ValueKey(coverUrl),
                image: provider,
                width: size,
                height: size,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                filterQuality: FilterQuality.medium,
                frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                  if (wasSynchronouslyLoaded) return child;
                  return AnimatedOpacity(
                    opacity: frame == null ? 0 : 1,
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    child: child,
                  );
                },
                errorBuilder: (_, __, ___) {
                  return Center(
                    child: Icon(
                      Icons.music_note_rounded,
                      color: Colors.white.withOpacity(0.48),
                      size: size * 0.30,
                    ),
                  );
                },
              ),
      ),
    );

    if (heroTag != null) {
      artwork = Hero(tag: heroTag!, child: artwork);
    }

    return artwork;
  }
}

// ─── Fullscreen Player Sheet ────────────────────────────────────────────────
class _FullScreenPlayerSheet extends StatefulWidget {
  final AudioPlayer player;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final Future<void> Function(drive.File track, int index) onPlayFromQueue;

  const _FullScreenPlayerSheet({
    required this.player,
    required this.onNext,
    required this.onPrev,
    required this.onPlayFromQueue,
  });

  @override
  State<_FullScreenPlayerSheet> createState() => _FullScreenPlayerSheetState();
}

class _FullScreenPlayerSheetState extends State<_FullScreenPlayerSheet> {
  String _formatTime(Duration d) {
    final hours = d.inHours;
    final minutes = d.inMinutes.remainder(60).toString().padLeft(hours > 0 ? 2 : 1, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');

    if (hours > 0) return '$hours:$minutes:$seconds';
    return '$minutes:$seconds';
  }

  void _openLyricsSheet(
    BuildContext context,
    Map<String, String> meta,
    List<Color> colors,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (_) {
        return _LyricsSheet(
          player: widget.player,
          meta: meta,
          colors: colors,
        );
      },
    );
  }

  void _openQueueSheet(BuildContext context, List<Color> colors) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (_) {
        return _QueueSheet(
          colors: colors,
          onPlayFromQueue: widget.onPlayFromQueue,
        );
      },
    );
  }

  Widget _circleIconButton({
    required IconData icon,
    required VoidCallback onTap,
    bool active = false,
    Color? accent,
  }) {
    final c = active ? accent ?? Colors.white : Colors.white.withOpacity(0.78);
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 48,
        height: 48,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active ? (accent ?? Colors.white).withOpacity(0.14) : Colors.white.withOpacity(0.055),
          border: Border.all(color: active ? (accent ?? Colors.white).withOpacity(0.32) : Colors.white.withOpacity(0.08)),
        ),
        child: Icon(icon, color: c, size: 23),
      ),
    );
  }

  Widget _bottomTextButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white.withOpacity(0.76), size: 24),
          const SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.white.withOpacity(0.50),
              letterSpacing: 0.1,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _nowPlaying,
      builder: (context, _) {
        final track = _nowPlaying.track;
        if (track == null) return const SizedBox.shrink();

        final meta = DriveUtils.getTrackMeta(track);
        final coverUrl = _nowPlaying.currentCoverUrl;
        final colors = _safeColors(_nowPlaying.dynamicColors);
        final accent = colors[1];
        final provider = _coverProvider(coverUrl);
        final height = MediaQuery.of(context).size.height;
        final width = MediaQuery.of(context).size.width;
        final artSize = (width * 0.78).clamp(260.0, 360.0);

        return StreamBuilder<PlayerState>(
          stream: widget.player.playerStateStream,
          builder: (context, stateSnap) {
            final state = stateSnap.data;
            final isPlaying = state?.playing ?? false;
            final isLoading = state?.processingState == ProcessingState.loading ||
                state?.processingState == ProcessingState.buffering;

            return ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Container(color: Colors.black),
                  ),
                  if (provider != null)
                    Positioned.fill(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        child: Image(
                          key: ValueKey('bg_$coverUrl'),
                          image: provider,
                          fit: BoxFit.cover,
                          gaplessPlayback: true,
                          filterQuality: FilterQuality.low,
                        ),
                      ),
                    ),
                  Positioned.fill(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 42, sigmaY: 42),
                      child: Container(color: Colors.black.withOpacity(0.40)),
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.18),
                            colors[0].withOpacity(0.22),
                            Colors.black.withOpacity(0.72),
                            Colors.black,
                          ],
                          stops: const [0.0, 0.28, 0.72, 1.0],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: height * 0.96,
                    child: SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(22, 12, 22, 26),
                        child: Column(
                          children: [
                            Container(
                              width: 42,
                              height: 5,
                              margin: const EdgeInsets.only(bottom: 10),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.32),
                                borderRadius: BorderRadius.circular(99),
                              ),
                            ),
                            Row(
                              children: [
                                IconButton(
                                  onPressed: () => Navigator.pop(context),
                                  icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 35, color: Colors.white),
                                ),
                                const Spacer(),
                                Text(
                                  'INFAME',
                                  style: GoogleFonts.inter(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.8,
                                    color: Colors.white.withOpacity(0.46),
                                  ),
                                ),
                                const Spacer(),
                                IconButton(
                                  onPressed: () {},
                                  icon: Icon(Icons.more_horiz_rounded, size: 29, color: Colors.white.withOpacity(0.88)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            AnimatedSwitcher(
                              duration: const Duration(milliseconds: 260),
                              switchInCurve: Curves.easeOutCubic,
                              switchOutCurve: Curves.easeInCubic,
                              child: _PremiumCoverArt(
                                key: ValueKey('full_$coverUrl'),
                                heroTag: 'now_playing_artwork',
                                coverUrl: coverUrl,
                                colors: colors,
                                size: artSize,
                                radius: 20,
                                shadow: true,
                              ),
                            ),
                            const SizedBox(height: 30),
                            AnimatedSwitcher(
                              duration: const Duration(milliseconds: 230),
                              transitionBuilder: (child, animation) {
                                return FadeTransition(
                                  opacity: animation,
                                  child: SlideTransition(
                                    position: Tween<Offset>(
                                      begin: const Offset(0, 0.04),
                                      end: Offset.zero,
                                    ).animate(animation),
                                    child: child,
                                  ),
                                );
                              },
                              child: Column(
                                key: ValueKey('title_${track.id}_${meta['title']}'),
                                children: [
                                  Text(
                                    meta['title'] ?? 'Unknown',
                                    maxLines: 2,
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.inter(
                                      fontSize: 29,
                                      height: 1.06,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: -0.8,
                                    ),
                                  ),
                                  const SizedBox(height: 9),
                                  Text(
                                    meta['artist'] ?? 'Unknown Artist',
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.inter(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white.withOpacity(0.62),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            StreamBuilder<Duration?>(
                              stream: widget.player.durationStream,
                              builder: (context, durationSnap) {
                                return _AudioQualityBadge(
                                  track: track,
                                  duration: durationSnap.data ?? widget.player.duration,
                                  accent: accent,
                                );
                              },
                            ),
                            const Spacer(),
                            StreamBuilder<Duration>(
                              stream: widget.player.positionStream,
                              builder: (_, posSnap) {
                                return StreamBuilder<Duration?>(
                                  stream: widget.player.durationStream,
                                  builder: (_, durSnap) {
                                    final pos = posSnap.data ?? Duration.zero;
                                    final dur = durSnap.data ?? Duration.zero;
                                    final max = dur.inMilliseconds > 0
                                        ? dur.inMilliseconds.toDouble()
                                        : 1.0;
                                    final value = pos.inMilliseconds.toDouble().clamp(0.0, max);

                                    return Column(
                                      children: [
                                        SliderTheme(
                                          data: SliderThemeData(
                                            trackHeight: 3.2,
                                            activeTrackColor: Colors.white,
                                            inactiveTrackColor: Colors.white.withOpacity(0.18),
                                            thumbColor: Colors.white,
                                            overlayColor: accent.withOpacity(0.14),
                                            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5.5),
                                            overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
                                          ),
                                          child: Slider(
                                            value: value,
                                            max: max,
                                            onChanged: (v) {
                                              widget.player.seek(Duration(milliseconds: v.toInt()));
                                            },
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 3),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                _formatTime(pos),
                                                style: GoogleFonts.inter(
                                                  color: Colors.white.withOpacity(0.54),
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              Text(
                                                _formatTime(dur),
                                                style: GoogleFonts.inter(
                                                  color: Colors.white.withOpacity(0.54),
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            ),
                            const SizedBox(height: 24),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                _circleIconButton(
                                  icon: Icons.shuffle_rounded,
                                  onTap: _nowPlaying.toggleShuffle,
                                  active: _nowPlaying.shuffleEnabled,
                                  accent: accent,
                                ),
                                IconButton(
                                  icon: Icon(Icons.skip_previous_rounded, size: 45, color: Colors.white.withOpacity(0.94)),
                                  onPressed: () {
                                    HapticFeedback.selectionClick();
                                    widget.onPrev();
                                  },
                                ),
                                GestureDetector(
                                  onTap: () {
                                    if (isLoading) return;
                                    HapticFeedback.mediumImpact();
                                    isPlaying ? widget.player.pause() : widget.player.play();
                                  },
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 150),
                                    curve: Curves.easeOutCubic,
                                    width: 78,
                                    height: 78,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(
                                          color: accent.withOpacity(0.24),
                                          blurRadius: 28,
                                          spreadRadius: 2,
                                        ),
                                      ],
                                    ),
                                    child: isLoading
                                        ? const Padding(
                                            padding: EdgeInsets.all(24),
                                            child: CircularProgressIndicator(color: Colors.black, strokeWidth: 3),
                                          )
                                        : Icon(
                                            isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                            color: Colors.black,
                                            size: 45,
                                          ),
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(Icons.skip_next_rounded, size: 45, color: Colors.white.withOpacity(0.94)),
                                  onPressed: () {
                                    HapticFeedback.selectionClick();
                                    widget.onNext();
                                  },
                                ),
                                _circleIconButton(
                                  icon: Icons.repeat_rounded,
                                  onTap: () async {
                                    _nowPlaying.toggleRepeatOne();
                                    await widget.player.setLoopMode(
                                      _nowPlaying.repeatOne ? LoopMode.one : LoopMode.off,
                                    );
                                  },
                                  active: _nowPlaying.repeatOne,
                                  accent: accent,
                                ),
                              ],
                            ),
                            const SizedBox(height: 24),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _bottomTextButton(
                                  icon: Icons.lyrics_rounded,
                                  label: 'Lyrics',
                                  onTap: () => _openLyricsSheet(context, meta, colors),
                                ),
                                _bottomTextButton(
                                  icon: Icons.queue_music_rounded,
                                  label: 'Queue',
                                  onTap: () => _openQueueSheet(context, colors),
                                ),
                                _bottomTextButton(
                                  icon: Icons.album_rounded,
                                  label: 'Sleeve',
                                  onTap: () {},
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _AudioQualityBadge extends StatelessWidget {
  final drive.File track;
  final Duration? duration;
  final Color accent;

  const _AudioQualityBadge({
    required this.track,
    required this.duration,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final label = DriveUtils.audioQualityLabel(track, duration);
    final isLossless = DriveUtils.isLosslessAudio(track);

    return Align(
      alignment: Alignment.center,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.075),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: isLossless ? accent.withOpacity(0.34) : Colors.white.withOpacity(0.12),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isLossless ? Icons.diamond_rounded : Icons.graphic_eq_rounded,
              size: 16,
              color: isLossless ? accent : Colors.white.withOpacity(0.74),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.inter(
                color: _textPri,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
