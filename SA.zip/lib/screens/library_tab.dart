part of '../main.dart';

extension BuildLibraryTabExtension on _MainScreenState {
Widget buildLibraryTab() {
    final colors = _safeColors(_currentDynamicColors);
    final query = _libraryQuery.trim().toLowerCase();
    final visibleAlbums = _albums.where((album) {
      if (query.isEmpty) return true;
      final brain = _libraryBrain[album['id'] ?? ''] ?? <String, String>{};
      final haystack = [
        album['name'] ?? '',
        album['displayName'] ?? '',
        album['artist'] ?? '',
        album['genre'] ?? '',
        album['year'] ?? '',
        brain['displayName'] ?? '',
        brain['artist'] ?? '',
        brain['genre'] ?? '',
        brain['year'] ?? '',
      ].join(' ').toLowerCase();
      return haystack.contains(query);
    }).toList();

    visibleAlbums.sort((a, b) {
      final ab = _libraryBrain[a['id'] ?? ''] ?? <String, String>{};
      final bb = _libraryBrain[b['id'] ?? ''] ?? <String, String>{};
      final an = ab['displayName'] ?? a['displayName'] ?? a['name'] ?? '';
      final bn = bb['displayName'] ?? b['displayName'] ?? b['name'] ?? '';
      if (_librarySortMode == 'za') return bn.compareTo(an);
      return an.compareTo(bn);
    });

    return CustomScrollView(
      key: const PageStorageKey('library_tab_scroll'),
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 40, 20, 14),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: _buildGradientText('Your Library', size: 32, spacing: -1)),
                    IconButton(
                      tooltip: _libraryGridMode ? 'List view' : 'Grid view',
                      icon: Icon(
                        _libraryGridMode ? Icons.view_list_rounded : Icons.grid_view_rounded,
                        color: _textSub,
                      ),
                      onPressed: () => setState(() => _libraryGridMode = !_libraryGridMode),
                    ),
                    PopupMenuButton<String>(
                      tooltip: 'Sort library',
                      icon: const Icon(Icons.sort_rounded, color: _textSub),
                      color: const Color(0xFF1A1A22),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      onSelected: (value) => setState(() => _librarySortMode = value),
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          value: 'az',
                          child: Text('Sort A–Z', style: GoogleFonts.inter(color: _textPri)),
                        ),
                        PopupMenuItem(
                          value: 'za',
                          child: Text('Sort Z–A', style: GoogleFonts.inter(color: _textPri)),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                GlassyContainer(
                  radius: 24,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                  customColor: Colors.white.withOpacity(0.070),
                  customBorder: Colors.white.withOpacity(0.12),
                  child: TextField(
                    onChanged: (value) => setState(() => _libraryQuery = value),
                    style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w700),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      icon: Icon(Icons.search_rounded, color: colors[1]),
                      hintText: 'Search albums',
                      hintStyle: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  '${visibleAlbums.length} of ${_albums.length} albums • Delete tools moved to Settings',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_loadingSaved || _isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _accentDefault)),
          )
        else if (_albums.isEmpty)
          const SliverFillRemaining(
            child: Center(child: Text('Library is empty.', style: TextStyle(color: _textSub))),
          )
        else if (visibleAlbums.isEmpty)
          SliverFillRemaining(
            child: Center(
              child: Text(
                'No albums match your search.',
                style: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
              ),
            ),
          )
        else if (_libraryGridMode)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 218),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.78,
              ),
              delegate: SliverChildBuilderDelegate((ctx, i) {
                final album = visibleAlbums[i];
                final merged = Map<String, String>.from(album);
                final brain = _libraryBrain[album['id'] ?? ''];
                if (brain != null) merged.addAll(brain);
                return _AlbumGridCard(
                  album: merged,
                  onTap: () => _openAlbum(album),
                );
              }, childCount: visibleAlbums.length),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 218),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((ctx, i) {
                final album = visibleAlbums[i];
                final brain = _libraryBrain[album['id'] ?? ''];
                final name = brain?['displayName'] ?? album['displayName'] ?? album['name'] ?? 'Album';
                final artist = brain?['artist'] ?? album['artist'] ?? '';
                final year = brain?['year'] ?? album['year'] ?? '';
                final genre = brain?['genre'] ?? album['genre'] ?? '';
                final coverUrl = album['cover'] ?? brain?['cover'] ?? '';
                final gradient = getAlbumGradient(name);

                return GestureDetector(
                  onTap: () => _openAlbum(album),
                  child: GlassyContainer(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    radius: 20,
                    child: Row(
                      children: [
                        Container(
                          width: 58,
                          height: 58,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: gradient,
                            ),
                          ),
                          child: coverUrl.isNotEmpty
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(14),
                                  child: _coverImage(
                                    coverUrl,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                                      name: name,
                                      colors: gradient,
                                      radius: 14,
                                      small: true,
                                    ),
                                  ),
                                )
                              : _AlbumFallbackCover(
                                  name: name,
                                  colors: gradient,
                                  radius: 14,
                                  small: true,
                                ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: _textPri,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                artist.isNotEmpty
                                    ? artist
                                    : year.isNotEmpty
                                        ? year
                                        : genre.isNotEmpty
                                            ? genre
                                            : 'Album • Drive',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(fontSize: 12, color: _textSub),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded, color: _textSub),
                      ],
                    ),
                  ),
                );
              }, childCount: visibleAlbums.length),
            ),
          ),
      ],
    );
  }

}
