part of '../main.dart';

extension BuildHomeTabExtension on _MainScreenState {
Widget buildHomeTab() {
    final colors = _safeColors(_currentDynamicColors);
    final spotlight = _spotlightAlbum();
    final recentlyPlayed = _lastPlayedAlbums(limit: 8);
    final mostPlayed = _mostPlayedAlbums(limit: 8);
    final recentAlbums = _recentBrainAlbums(limit: 10);
    final genres = _topGenres(limit: 3);
    final decades = _topDecades(limit: 3);
    final artists = _topArtists(limit: 12);

    return CustomScrollView(
      key: const PageStorageKey('home_tab_scroll'),
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 40, 20, 18),
          sliver: SliverToBoxAdapter(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Good Evening',
                        style: GoogleFonts.inter(
                          color: _textPri,
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -1.1,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        _albums.isEmpty
                            ? 'Connect a Drive folder to build your music library.'
                            : '${_albums.length} albums • ${_metaStore.count} cached tracks',
                        style: GoogleFonts.inter(
                          color: _textSub,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Settings',
                  icon: const Icon(Icons.settings_rounded, color: _textSub),
                  onPressed: _openSettingsSheet,
                ),
                IconButton(
                  tooltip: 'Sign out',
                  icon: const Icon(Icons.logout_rounded, color: _textSub),
                  onPressed: _signOut,
                ),
              ],
            ),
          ),
        ),
        if (_loadingMetadata)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
            sliver: SliverToBoxAdapter(
              child: GestureDetector(
                onTap: _openSettingsSheet,
                child: GlassyContainer(
                  radius: 24,
                  padding: const EdgeInsets.all(15),
                  customColor: Colors.white.withOpacity(0.075),
                  customBorder: colors[1].withOpacity(0.22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.4,
                              color: colors[1],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _metadataStatusLabel(),
                              style: GoogleFonts.inter(
                                color: _textPri,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                height: 1.35,
                              ),
                            ),
                          ),
                          const Icon(Icons.chevron_right_rounded, color: _textSub),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: _metadataTotal > 0
                              ? (_metadataDone / _metadataTotal).clamp(0.0, 1.0)
                              : null,
                          minHeight: 5,
                          backgroundColor: Colors.white.withOpacity(0.14),
                          valueColor: AlwaysStoppedAnimation<Color>(colors[1]),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        if (_loadingSaved || _isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _accentDefault)),
          )
        else if (_albums.isEmpty)
          SliverFillRemaining(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 34),
                child: Text(
                  'No albums yet.\nHead to Search, open a music folder, then scan it to your library.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.inter(color: _textSub, height: 1.5),
                ),
              ),
            ),
          )
        else ...[
          if (spotlight != null)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              sliver: SliverToBoxAdapter(
                child: _HomeSpotlightCard(
                  info: spotlight,
                  accent: colors[1],
                  onTap: () => _openAlbumByBrain(spotlight),
                ),
              ),
            ),
          if (_homeShowContinue && recentlyPlayed.isNotEmpty)
            ..._homeAlbumShelfSlivers(
              title: 'Continue listening',
              subtitle: 'Albums you came back to recently',
              items: recentlyPlayed,
            ),
          if (_homeShowContinue && _playHistory.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 0, 22),
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _HomeSectionHeader(
                      title: 'Recent tracks',
                      subtitle: 'Tap a row to open its album',
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 82,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        itemCount: math.min(_playHistory.length, 8),
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (context, i) {
                          final item = _playHistory[i];
                          return _RecentTrackPill(
                            item: item,
                            accent: colors[1],
                            onTap: () {
                              final albumId = item['albumId'] ?? '';
                              final album = _albumById(albumId);
                              if (album != null) _openAlbum(album);
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (mostPlayed.isNotEmpty)
            ..._homeAlbumShelfSlivers(
              title: 'Heavy rotation',
              subtitle: 'Albums you play the most',
              items: mostPlayed,
            ),
          if (_homeShowDiscovery && recentAlbums.length > 3)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
              sliver: SliverToBoxAdapter(
                child: _DiscoveryCard(
                  accent: colors[1],
                  onTap: _shuffleLibrary,
                ),
              ),
            ),
          if (_homeShowGenres)
            for (final genre in genres)
              ..._homeAlbumShelfSlivers(
                title: genre,
                subtitle: 'Auto-grouped from tags and folder names',
                items: _albumsForGenre(genre),
              ),
          if (_homeShowDecades)
            for (final decade in decades)
              ..._homeAlbumShelfSlivers(
                title: decade,
                subtitle: 'Sorted by year when metadata is available',
                items: _albumsForDecade(decade),
              ),
          if (_homeShowArtists && artists.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 0, 22),
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _HomeSectionHeader(
                      title: 'Artists in your library',
                      subtitle: 'Built from cached artist metadata',
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 54,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        itemCount: artists.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 10),
                        itemBuilder: (context, i) {
                          final item = artists[i];
                          return _ArtistChip(
                            name: item['artist'] ?? 'Artist',
                            count: item['count'] ?? '0',
                            accent: colors[1],
                            onTap: () {
                              setState(() {
                                _libraryQuery = item['artist'] ?? '';
                                _navIndex = 1;
                              });
                              _selectRootTab(1);
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ..._homeAlbumShelfSlivers(
            title: 'Recently added',
            subtitle: 'Newest albums added to Infame',
            items: recentAlbums,
            bottomPadding: 218,
          ),
        ],
      ],
    );
  }

}
