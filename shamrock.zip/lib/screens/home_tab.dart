part of '../main.dart';

extension BuildHomeTabExtension on _MainScreenState {
  Widget buildHomeTab() {
    final colors = _safeColors(_currentDynamicColors);
    final accent = colors[1];
    final spotlight = _spotlightAlbum();
    final recentlyPlayed = _lastPlayedAlbums(limit: 10);
    final mostPlayed = _mostPlayedAlbums(limit: 10);
    final recentAlbums = _recentBrainAlbums(limit: 12);
    final wall = _homeDistinctAlbums([
      recentlyPlayed,
      recentAlbums,
      mostPlayed,
      _brainAlbums(),
    ], limit: 10);
    final heroAlbum = spotlight ?? (recentAlbums.isNotEmpty ? recentAlbums.first : null);

    return CustomScrollView(
      key: const PageStorageKey('home_tab_scroll'),
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(18, 34, 18, 0),
          sliver: SliverToBoxAdapter(
            child: _InfameTopBar(
              albumCount: _albums.length,
              cachedCount: _metaStore.count,
              accent: accent,
              onSettings: _openSettingsSheet,
              onSignOut: _signOut,
            ),
          ),
        ),
        if (_loadingMetadata)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
            sliver: SliverToBoxAdapter(
              child: _InfameScanStrip(
                label: _metadataStatusLabel(),
                progress: _metadataTotal > 0
                    ? (_metadataDone / _metadataTotal).clamp(0.0, 1.0)
                    : null,
                accent: accent,
                onTap: _openSettingsSheet,
              ),
            ),
          ),
        if (_loadingSaved || _isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _accentDefault)),
          )
        else if (_albums.isEmpty)
          SliverFillRemaining(child: _InfameEmptyHome(accent: accent))
        else ...[
          if (heroAlbum != null)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
              sliver: SliverToBoxAdapter(
                child: _InfameWildHero(
                  spotlight: heroAlbum,
                  wallAlbums: wall,
                  accent: accent,
                  colors: colors,
                  onTap: () => _openAlbumByBrain(heroAlbum),
                ),
              ),
            ),
          if (_playHistory.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 0, 24),
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _InfameSectionTitle(
                      title: 'Last transmissions',
                      subtitle: 'Fast access to the tracks you just touched',
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 88,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        itemCount: math.min(_playHistory.length, 10),
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (context, i) {
                          final item = _playHistory[i];
                          return _RecentTrackPill(
                            item: item,
                            accent: accent,
                            onTap: () {
                              final albumId = item['albumId'] ?? '';
                              final album = _albumById(albumId);
                              if (album != null) _openAlbum(album);
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (recentlyPlayed.isNotEmpty)
            ..._infameAlbumRail(
              title: 'Return to orbit',
              subtitle: 'Albums already in motion',
              albums: recentlyPlayed,
              tall: true,
            ),
          if (recentAlbums.isNotEmpty)
            ..._infameAlbumRail(
              title: 'New in the vault',
              subtitle: 'Fresh covers pulled from your archive',
              albums: recentAlbums,
            ),
          if (mostPlayed.isNotEmpty)
            ..._infameAlbumRail(
              title: 'Pressure points',
              subtitle: 'Records that refuse to leave rotation',
              albums: mostPlayed,
            ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 226),
            sliver: SliverToBoxAdapter(
              child: _InfameLibraryPortal(
                accent: accent,
                colors: colors,
                onLibrary: () => _selectRootTab(1),
                onSources: () => _selectRootTab(2),
              ),
            ),
          ),
        ],
      ],
    );
  }

  List<Map<String, String>> _homeDistinctAlbums(
    List<List<Map<String, String>>> groups, {
    int limit = 8,
  }) {
    final seen = <String>{};
    final out = <Map<String, String>>[];

    for (final group in groups) {
      for (final album in group) {
        final id = album['albumId'] ?? album['id'] ?? album['name'] ?? '';
        if (id.isEmpty || seen.contains(id)) continue;
        seen.add(id);
        out.add(album);
        if (out.length >= limit) return out;
      }
    }

    return out;
  }

  List<Widget> _infameAlbumRail({
    required String title,
    required String subtitle,
    required List<Map<String, String>> albums,
    bool tall = false,
  }) {
    if (albums.isEmpty) return const <Widget>[];

    return [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
        sliver: SliverToBoxAdapter(
          child: _InfameSectionTitle(title: title, subtitle: subtitle),
        ),
      ),
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(18, 0, 0, 26),
        sliver: SliverToBoxAdapter(
          child: SizedBox(
            height: tall ? 236 : 214,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: albums.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (context, i) {
                return _InfameRailAlbum(
                  info: albums[i],
                  big: tall && i == 0,
                  onTap: () => _openAlbumByBrain(albums[i]),
                );
              },
            ),
          ),
        ),
      ),
    ];
  }
}

class _InfameTopBar extends StatelessWidget {
  final int albumCount;
  final int cachedCount;
  final Color accent;
  final VoidCallback onSettings;
  final VoidCallback onSignOut;

  const _InfameTopBar({
    required this.albumCount,
    required this.cachedCount,
    required this.accent,
    required this.onSettings,
    required this.onSignOut,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 9,
                    height: 9,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: accent,
                      boxShadow: [
                        BoxShadow(color: accent.withOpacity(0.72), blurRadius: 18),
                      ],
                    ),
                  ),
                  const SizedBox(width: 9),
                  Text(
                    'INFAME',
                    style: GoogleFonts.inter(
                      color: _textSub,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3.2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Your music vault',
                style: GoogleFonts.inter(
                  color: _textPri,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1.2,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '$albumCount albums • $cachedCount cached tracks',
                style: GoogleFonts.inter(
                  color: _textSub,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        _InfameCircleButton(icon: Icons.tune_rounded, onTap: onSettings, accent: accent),
        const SizedBox(width: 8),
        _InfameCircleButton(icon: Icons.logout_rounded, onTap: onSignOut, accent: Colors.white),
      ],
    );
  }
}

class _InfameCircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color accent;

  const _InfameCircleButton({
    required this.icon,
    required this.onTap,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.075),
          border: Border.all(color: Colors.white.withOpacity(0.10)),
        ),
        child: Icon(icon, color: accent.withOpacity(0.92), size: 21),
      ),
    );
  }
}

class _InfameScanStrip extends StatelessWidget {
  final String label;
  final double? progress;
  final Color accent;
  final VoidCallback onTap;

  const _InfameScanStrip({
    required this.label,
    required this.progress,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: GlassyContainer(
        radius: 24,
        padding: const EdgeInsets.all(14),
        customColor: Colors.white.withOpacity(0.080),
        customBorder: accent.withOpacity(0.22),
        child: Column(
          children: [
            Row(
              children: [
                SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.4, color: accent),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: GoogleFonts.inter(
                      color: _textPri,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: _textSub),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 5,
                backgroundColor: Colors.white.withOpacity(0.14),
                valueColor: AlwaysStoppedAnimation<Color>(accent),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfameHeroCard extends StatelessWidget {
  final Map<String, String> spotlight;
  final List<Map<String, String>> wallAlbums;
  final Color accent;
  final VoidCallback onTap;

  const _InfameHeroCard({
    required this.spotlight,
    required this.wallAlbums,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final name = spotlight['displayName'] ?? spotlight['name'] ?? 'Album';
    final artist = spotlight['artist'] ?? 'Unknown Artist';
    final year = spotlight['year'] ?? '';
    final genre = spotlight['genre'] ?? '';
    final cover = spotlight['cover'] ?? spotlight['coverUrl'] ?? '';
    final gradient = getAlbumGradient(name);

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      gradient[0].withOpacity(0.88),
                      gradient[1].withOpacity(0.55),
                      Colors.black.withOpacity(0.95),
                    ],
                  ),
                ),
              ),
            ),
            if (cover.isNotEmpty)
              Positioned.fill(
                child: Opacity(
                  opacity: 0.26,
                  child: ImageFiltered(
                    imageFilter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
                    child: _coverImage(cover, fit: BoxFit.cover),
                  ),
                ),
              ),
            Positioned(
              right: -50,
              top: -40,
              child: Container(
                width: 190,
                height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.24),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(999),
                          color: Colors.black.withOpacity(0.30),
                          border: Border.all(color: Colors.white.withOpacity(0.14)),
                        ),
                        child: Text(
                          'TONIGHT\'S PICK',
                          style: GoogleFonts.inter(
                            color: Colors.white.withOpacity(0.88),
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.7,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Icon(Icons.auto_awesome_rounded, color: accent, size: 22),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _InfameCoverStack(albums: wallAlbums, fallback: spotlight),
                      const SizedBox(width: 18),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.inter(
                                color: Colors.white,
                                fontSize: 29,
                                height: 0.96,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -1.0,
                              ),
                            ),
                            const SizedBox(height: 9),
                            Text(
                              artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.inter(
                                color: Colors.white.withOpacity(0.74),
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                if (year.isNotEmpty) _InfameTinyTag(label: year),
                                if (genre.isNotEmpty) _InfameTinyTag(label: genre),
                                _InfameTinyTag(label: 'Open album'),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfameCoverStack extends StatelessWidget {
  final List<Map<String, String>> albums;
  final Map<String, String> fallback;

  const _InfameCoverStack({required this.albums, required this.fallback});

  @override
  Widget build(BuildContext context) {
    final items = albums.isNotEmpty ? albums : [fallback];

    return SizedBox(
      width: 122,
      height: 146,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          for (int i = math.min(items.length, 3) - 1; i >= 0; i--)
            Positioned(
              left: i * 12,
              top: i * 9,
              child: Transform.rotate(
                angle: (i - 1) * 0.08,
                child: _InfameSmallCover(info: items[i], size: i == 0 ? 118 : 102),
              ),
            ),
        ],
      ),
    );
  }
}

class _InfameSmallCover extends StatelessWidget {
  final Map<String, String> info;
  final double size;

  const _InfameSmallCover({required this.info, required this.size});

  @override
  Widget build(BuildContext context) {
    final name = info['displayName'] ?? info['name'] ?? 'Album';
    final cover = info['cover'] ?? info['coverUrl'] ?? '';
    final gradient = getAlbumGradient(name);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(colors: gradient),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.36),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
        ],
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: cover.isNotEmpty
          ? ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: _coverImage(
                cover,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                  name: name,
                  colors: gradient,
                  radius: 24,
                ),
              ),
            )
          : _AlbumFallbackCover(name: name, colors: gradient, radius: 24),
    );
  }
}

class _InfameTinyTag extends StatelessWidget {
  final String label;

  const _InfameTinyTag({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: Colors.white.withOpacity(0.12),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: Text(
        label,
        style: GoogleFonts.inter(
          color: Colors.white.withOpacity(0.88),
          fontSize: 11,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _InfameStatPill extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color accent;

  const _InfameStatPill({
    required this.label,
    required this.value,
    required this.icon,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return GlassyContainer(
      radius: 24,
      padding: const EdgeInsets.all(13),
      customColor: Colors.white.withOpacity(0.070),
      customBorder: accent.withOpacity(0.18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: accent, size: 20),
          const SizedBox(height: 10),
          Text(
            value,
            style: GoogleFonts.inter(
              color: _textPri,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.inter(
              color: _textSub,
              fontSize: 11,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _InfameSectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _InfameSectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  color: _textPri,
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.55,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.inter(
                  color: _textSub,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        Container(
          width: 34,
          height: 2,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(99),
            color: Colors.white.withOpacity(0.20),
          ),
        ),
      ],
    );
  }
}

class _InfameRailAlbum extends StatelessWidget {
  final Map<String, String> info;
  final bool big;
  final VoidCallback onTap;

  const _InfameRailAlbum({
    required this.info,
    required this.big,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final name = info['displayName'] ?? info['name'] ?? 'Album';
    final artist = info['artist'] ?? info['genre'] ?? 'Album';
    final cover = info['coverUrl'] ?? info['cover'] ?? '';
    final gradient = getAlbumGradient(name);
    final width = big ? 166.0 : 138.0;
    final coverSize = big ? 166.0 : 138.0;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: coverSize,
              height: coverSize,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(big ? 28 : 22),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: gradient,
                ),
                boxShadow: [
                  BoxShadow(
                    color: gradient.first.withOpacity(0.22),
                    blurRadius: big ? 26 : 18,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: cover.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(big ? 28 : 22),
                      child: _coverImage(
                        cover,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                          name: name,
                          colors: gradient,
                          radius: big ? 28 : 22,
                        ),
                      ),
                    )
                  : _AlbumFallbackCover(name: name, colors: gradient, radius: big ? 28 : 22),
            ),
            const SizedBox(height: 10),
            Text(
              name,
              maxLines: big ? 2 : 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.inter(
                color: _textPri,
                fontSize: big ? 15 : 13,
                height: 1.1,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.inter(
                color: _textSub,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfameMoodBoard extends StatelessWidget {
  final List<String> genres;
  final List<String> decades;
  final Color accent;
  final ValueChanged<String> onGenreTap;
  final ValueChanged<String> onDecadeTap;

  const _InfameMoodBoard({
    required this.genres,
    required this.decades,
    required this.accent,
    required this.onGenreTap,
    required this.onDecadeTap,
  });

  @override
  Widget build(BuildContext context) {
    final chips = <Widget>[
      for (final genre in genres)
        _InfameMoodChip(label: genre, icon: Icons.bolt_rounded, accent: accent, onTap: () => onGenreTap(genre)),
      for (final decade in decades)
        _InfameMoodChip(label: decade, icon: Icons.schedule_rounded, accent: Colors.white, onTap: () => onDecadeTap(decade)),
    ];

    return GlassyContainer(
      radius: 30,
      padding: const EdgeInsets.all(16),
      customColor: Colors.white.withOpacity(0.065),
      customBorder: accent.withOpacity(0.16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _InfameSectionTitle(
            title: 'Sonic lanes',
            subtitle: 'Jump by sound, year or mood',
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: chips,
          ),
        ],
      ),
    );
  }
}

class _InfameMoodChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color accent;
  final VoidCallback onTap;

  const _InfameMoodChip({
    required this.label,
    required this.icon,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          color: Colors.white.withOpacity(0.075),
          border: Border.all(color: accent.withOpacity(0.18)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: accent.withOpacity(0.95), size: 17),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.inter(
                color: _textPri,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _InfameWildHero extends StatelessWidget {
  final Map<String, String> spotlight;
  final List<Map<String, String>> wallAlbums;
  final Color accent;
  final List<Color> colors;
  final VoidCallback onTap;

  const _InfameWildHero({
    required this.spotlight,
    required this.wallAlbums,
    required this.accent,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final title = spotlight['displayName'] ?? spotlight['name'] ?? 'Tonight\'s pick';
    final artist = spotlight['artist'] ?? '';
    final cover = spotlight['cover'] ?? '';
    final gradient = getAlbumGradient(title);
    final coverAlbums = wallAlbums.isEmpty ? [spotlight] : wallAlbums;

    Widget coverTile(Map<String, String> album, double size, double radius) {
      final name = album['displayName'] ?? album['name'] ?? 'Album';
      final src = album['cover'] ?? '';
      final g = getAlbumGradient(name);
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          gradient: LinearGradient(colors: g),
          boxShadow: [
            BoxShadow(
              color: g.first.withOpacity(0.32),
              blurRadius: 24,
              offset: const Offset(0, 12),
            ),
          ],
          border: Border.all(color: Colors.white.withOpacity(0.14)),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius),
          child: src.isNotEmpty
              ? _coverImage(
                  src,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                    name: name,
                    colors: g,
                    radius: radius,
                    small: true,
                  ),
                )
              : _AlbumFallbackCover(name: name, colors: g, radius: radius, small: true),
        ),
      );
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 430,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(36),
          gradient: RadialGradient(
            center: const Alignment(-0.85, -0.95),
            radius: 1.4,
            colors: [
              colors[0].withOpacity(0.95),
              gradient[1].withOpacity(0.55),
              const Color(0xFF08080D),
            ],
          ),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.28),
              blurRadius: 50,
              spreadRadius: -8,
              offset: const Offset(0, 20),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(36),
          child: Stack(
            children: [
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.white.withOpacity(0.10),
                        Colors.transparent,
                        Colors.black.withOpacity(0.62),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -48,
                top: -32,
                child: Transform.rotate(
                  angle: -0.18,
                  child: coverTile(coverAlbums[0], 188, 32),
                ),
              ),
              if (coverAlbums.length > 1)
                Positioned(
                  right: 110,
                  top: 40,
                  child: Transform.rotate(
                    angle: 0.22,
                    child: coverTile(coverAlbums[1], 96, 22),
                  ),
                ),
              if (coverAlbums.length > 2)
                Positioned(
                  right: 24,
                  bottom: 86,
                  child: Transform.rotate(
                    angle: 0.14,
                    child: coverTile(coverAlbums[2], 122, 26),
                  ),
                ),
              Positioned(
                left: -42,
                bottom: -36,
                child: Container(
                  width: 230,
                  height: 230,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withOpacity(0.12), width: 18),
                    gradient: SweepGradient(
                      colors: [
                        accent.withOpacity(0.0),
                        accent.withOpacity(0.65),
                        colors[2].withOpacity(0.55),
                        accent.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 22,
                right: 22,
                top: 22,
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.32),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withOpacity(0.16)),
                      ),
                      child: Text(
                        'INFAME SIGNAL',
                        style: GoogleFonts.inter(
                          color: Colors.white,
                          fontSize: 11,
                          letterSpacing: 1.8,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Icon(Icons.arrow_outward_rounded, color: Colors.white.withOpacity(0.86)),
                  ],
                ),
              ),
              Positioned(
                left: 24,
                right: 24,
                bottom: 24,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        coverTile(spotlight, 116, 26),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Tonight\'s pick',
                                style: GoogleFonts.inter(
                                  color: Colors.white.withOpacity(0.66),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(
                                  color: Colors.white,
                                  fontSize: 29,
                                  height: 0.95,
                                  letterSpacing: -1.4,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                artist.isEmpty ? 'Tap to open the record' : artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(
                                  color: Colors.white.withOpacity(0.74),
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.13),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: Colors.white.withOpacity(0.16)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.play_arrow_rounded, color: accent, size: 28),
                          const SizedBox(width: 8),
                          Text(
                            'Open album',
                            style: GoogleFonts.inter(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            '${coverAlbums.length} covers live',
                            style: GoogleFonts.inter(
                              color: Colors.white.withOpacity(0.58),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfameLibraryPortal extends StatelessWidget {
  final Color accent;
  final List<Color> colors;
  final VoidCallback onLibrary;
  final VoidCallback onSources;

  const _InfameLibraryPortal({
    required this.accent,
    required this.colors,
    required this.onLibrary,
    required this.onSources,
  });

  @override
  Widget build(BuildContext context) {
    Widget action({
      required String title,
      required String subtitle,
      required IconData icon,
      required VoidCallback onTap,
      required Color color,
    }) {
      return Expanded(
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  color.withOpacity(0.28),
                  Colors.white.withOpacity(0.07),
                ],
              ),
              border: Border.all(color: Colors.white.withOpacity(0.12)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: Colors.white, size: 28),
                const SizedBox(height: 18),
                Text(
                  title,
                  style: GoogleFonts.inter(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        action(
          title: 'Crates',
          subtitle: 'albums, artists, tracks',
          icon: Icons.grid_view_rounded,
          onTap: onLibrary,
          color: accent,
        ),
        const SizedBox(width: 12),
        action(
          title: 'Sources',
          subtitle: 'Drive folders + scans',
          icon: Icons.folder_special_rounded,
          onTap: onSources,
          color: colors[2],
        ),
      ],
    );
  }
}

class _InfameEmptyHome extends StatelessWidget {
  final Color accent;

  const _InfameEmptyHome({required this.accent});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 34),
        child: GlassyContainer(
          radius: 32,
          padding: const EdgeInsets.all(24),
          customColor: Colors.white.withOpacity(0.070),
          customBorder: accent.withOpacity(0.20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.folder_special_rounded, color: accent, size: 42),
              const SizedBox(height: 14),
              Text(
                'Build the vault',
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(
                  color: _textPri,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.7,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Go to Drive, open your music folder, then scan it into Infame.',
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(
                  color: _textSub,
                  fontSize: 14,
                  height: 1.45,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
