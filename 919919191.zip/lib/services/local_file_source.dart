part of '../main.dart';

// ─── Local Files Source ────────────────────────────────────────────────────
// Keeps local files inside the same album/track model as Drive tracks by
// representing them as drive.File objects with source=local app properties.
//
// v2 adds:
// - selected local folders
// - recursive folder rescans
// - unchanged-file metadata cache reuse
// - folder.jpg/cover.jpg artwork
// - light embedded artwork fallback
// - missing-file cleanup

const String _localFoldersPrefsKey = 'infame_selected_local_folders_v1';

extension _LocalFileSourceExtension on _MainScreenState {
  static const Set<String> _supportedLocalAudioExtensions = <String>{
    'mp3',
    'flac',
    'wav',
    'm4a',
    'aac',
    'ogg',
    'opus',
    'wma',
  };

  static const List<String> _localFolderCoverNames = <String>[
    'cover.jpg',
    'folder.jpg',
    'front.jpg',
    'album.jpg',
    'artwork.jpg',
    'cover.jpeg',
    'folder.jpeg',
    'front.jpeg',
    'album.jpeg',
    'artwork.jpeg',
    'cover.png',
    'folder.png',
    'front.png',
    'album.png',
    'artwork.png',
  ];

  bool _isLocalAlbumRecord(Map<String, String> album) {
    return (album['source'] ?? '').trim() == 'local' ||
        (album['id'] ?? '').startsWith('local_album:');
  }

  String _localAlbumId(String album, String artist) {
    final key = [artist, album]
        .where((value) => value.trim().isNotEmpty)
        .join('::')
        .trim();
    return 'local_album:${_normalizeAlbumKeySegment(key.isEmpty ? album : key)}';
  }

  String _localBasename(String path) {
    final normalized = path.replaceAll('\\', '/');
    final idx = normalized.lastIndexOf('/');
    return idx >= 0 ? normalized.substring(idx + 1) : normalized;
  }

  String _localDirname(String path) {
    final normalized = path.replaceAll('\\', '/');
    final idx = normalized.lastIndexOf('/');
    return idx >= 0 ? normalized.substring(0, idx) : '';
  }

  String _localExtension(String path) {
    final name = _localBasename(path).toLowerCase();
    final idx = name.lastIndexOf('.');
    if (idx < 0 || idx == name.length - 1) return '';
    return name.substring(idx + 1);
  }

  bool _isSupportedLocalAudioPath(String path) {
    return _supportedLocalAudioExtensions.contains(_localExtension(path));
  }

  drive.File _localDriveFileFromPath(String path) {
    final file = File(path);
    FileStat? stat;
    try {
      stat = file.statSync();
    } catch (_) {}

    return drive.File()
      ..id = DriveUtils.localIdForPath(path)
      ..name = _localBasename(path)
      ..mimeType = 'audio/local'
      ..size = stat?.size.toString() ?? '0'
      ..modifiedTime = stat?.modified
      ..appProperties = <String, String>{
        'source': 'local',
        'path': path,
      }
      ..properties = <String, String>{
        'source': 'local',
        'path': path,
      };
  }

  List<drive.File> _localTracksForAlbum(Map<String, String> album) {
    final albumId = _albumCacheKey(album, source: 'local_album_tracks');
    final cached = _albumTracksCache[albumId];
    if (cached != null && cached.isNotEmpty) {
      return _sortTracksForAlbum(cached.where((track) {
        final path = DriveUtils.localPath(track);
        return path == null || path.isEmpty || File(path).existsSync();
      }).toList());
    }

    final tracks = <drive.File>[];
    for (final record in _libraryTrackIndex.values) {
      if ((record['source'] ?? '') != 'local') continue;
      if ((record['albumId'] ?? '') != albumId &&
          (record['albumId'] ?? '') != (album['id'] ?? '')) {
        continue;
      }

      final localPath = (record['localPath'] ?? '').trim();
      if (localPath.isEmpty || !File(localPath).existsSync()) continue;
      tracks.add(_fileFromTrackIndexRecord(record));
    }

    final sorted = _sortTracksForAlbum(tracks);
    if (sorted.isNotEmpty) _albumTracksCache[albumId] = sorted;
    return sorted;
  }

  Future<void> _loadSelectedLocalFolders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs
              .getStringList(_localFoldersPrefsKey)
              ?.map((path) => path.trim())
              .where((path) => path.isNotEmpty)
              .toSet()
              .toList() ??
          <String>[];
      saved.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
      if (!mounted) {
        _selectedLocalFolders = saved;
        return;
      }
      setState(() => _selectedLocalFolders = saved);
    } catch (_) {
      return;
    }
  }

  Future<void> _saveSelectedLocalFolders() async {
    final prefs = await SharedPreferences.getInstance();
    final folders = _selectedLocalFolders
        .map((path) => path.trim())
        .where((path) => path.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    await prefs.setStringList(_localFoldersPrefsKey, folders);
  }

  Future<void> _pickLocalMusicFolder() async {
    if (_isScanning || _loadingMetadata) {
      _showError('Wait for the current scan to finish first.');
      return;
    }

    String? folderPath;
    try {
      folderPath = await FilePicker.platform.getDirectoryPath(
        dialogTitle: 'Choose a local music folder',
      );
    } catch (e) {
      _showError('Local folder picker failed: $e');
      return;
    }

    final folder = folderPath?.trim() ?? '';
    if (folder.isEmpty) return;

    final normalized = folder.replaceAll('\\', '/');
    if (!_selectedLocalFolders.contains(normalized)) {
      setState(() => _selectedLocalFolders = [
            ..._selectedLocalFolders,
            normalized,
          ]..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase())));
      await _saveSelectedLocalFolders();
    }

    await _rescanLocalMusicFolders(pathsOverride: <String>[normalized]);
  }

  Future<void> _rescanLocalMusicFolders({List<String>? pathsOverride}) async {
    if (_isScanning || _loadingMetadata) {
      _showError('Wait for the current scan to finish first.');
      return;
    }

    final folders = (pathsOverride ?? _selectedLocalFolders)
        .map((path) => path.trim())
        .where((path) => path.isNotEmpty)
        .toSet()
        .toList();

    if (folders.isEmpty) {
      _showError('Choose a local music folder first.');
      return;
    }

    setState(() => _isScanning = true);
    _showSuccess('Scanning ${folders.length} local folder${folders.length == 1 ? '' : 's'}...');

    try {
      final paths = <String>{};
      final missingFolders = <String>[];

      for (final folder in folders) {
        final dir = Directory(folder);
        if (!await dir.exists()) {
          missingFolders.add(folder);
          continue;
        }

        await for (final entity in dir.list(
          recursive: true,
          followLinks: false,
        )) {
          if (entity is! File) continue;
          final path = entity.path.trim();
          if (path.isEmpty || !_isSupportedLocalAudioPath(path)) continue;
          paths.add(path.replaceAll('\\', '/'));
        }
      }

      if (missingFolders.isNotEmpty) {
        _selectedLocalFolders = _selectedLocalFolders
            .where((folder) => !missingFolders.contains(folder))
            .toList();
        await _saveSelectedLocalFolders();
      }

      if (paths.isEmpty) {
        _showError('No supported audio files found in selected folders.');
        return;
      }

      await _importLocalAudioPaths(
        paths.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase())),
        successPrefix: 'Scanned',
      );
    } catch (e) {
      _showError('Local folder scan failed: $e');
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _importLocalAudioFiles() async {
    if (_isScanning || _loadingMetadata) {
      _showError('Wait for the current scan to finish first.');
      return;
    }

    FilePickerResult? result;
    try {
      result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: _supportedLocalAudioExtensions.toList(),
      );
    } catch (e) {
      _showError('Local file picker failed: $e');
      return;
    }

    final paths = result?.files
            .map((file) => file.path?.trim() ?? '')
            .where((path) => path.isNotEmpty && _isSupportedLocalAudioPath(path))
            .toSet()
            .toList() ??
        <String>[];

    if (paths.isEmpty) return;

    setState(() => _isScanning = true);
    _showSuccess('Importing ${paths.length} local audio files...');

    try {
      await _importLocalAudioPaths(paths, successPrefix: 'Imported');
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _importLocalAudioPaths(
    List<String> paths, {
    String successPrefix = 'Imported',
  }) async {
    final albumsById = <String, Map<String, String>>{};
    final tracksByAlbum = <String, List<drive.File>>{};
    var importedTracks = 0;
    var reusedCached = 0;

    try {
      for (final rawPath in paths) {
        final path = rawPath.trim().replaceAll('\\', '/');
        if (path.isEmpty || !_isSupportedLocalAudioPath(path)) continue;

        final file = File(path);
        if (!await file.exists()) continue;

        final localFile = _localDriveFileFromPath(path);
        if (!DriveUtils.isAudio(localFile)) continue;

        final metadata = await _readLocalTrackMetadata(localFile, file);
        if (_metaStore.peekFresh(localFile) != null) {
          reusedCached++;
        }
        _metaStore.putMemory(localFile, metadata);

        final albumTitle = _cleanBrainValue(metadata.album) == ''
            ? _localAlbumFallbackFromPath(path)
            : metadata.album!.trim();
        final artist = _cleanBrainValue(metadata.artist).isEmpty
            ? 'Unknown Artist'
            : metadata.artist.trim();
        final albumId = _localAlbumId(albumTitle, artist);
        final existingAlbum = albumsById[albumId] ??
            _albums.firstWhere(
              (album) => (album['id'] ?? '') == albumId,
              orElse: () => <String, String>{},
            );
        final dateAdded = existingAlbum['dateAdded'] ??
            DateTime.now().millisecondsSinceEpoch.toString();

        final albumRecord = <String, String>{
          ...existingAlbum,
          'id': albumId,
          'albumKey': albumId,
          'source': 'local',
          'name': albumTitle,
          'displayName': albumTitle,
          'artist': artist,
          'cover': existingAlbum['cover'] ?? '',
          'dateAdded': dateAdded,
        };

        albumsById[albumId] = albumRecord;
        tracksByAlbum.putIfAbsent(albumId, () => <drive.File>[]).add(localFile);
        importedTracks++;
      }

      if (importedTracks == 0) {
        _showError('No supported local audio files were imported.');
        return;
      }

      final existingById = <String, Map<String, String>>{
        for (final album in _albums) (album['id'] ?? ''): album,
      };

      for (final entry in albumsById.entries) {
        final albumId = entry.key;
        final album = entry.value;
        final tracks = _sortTracksForAlbum(tracksByAlbum[albumId] ?? []);
        if (tracks.isEmpty) continue;

        final cover = album['cover']?.trim().isNotEmpty == true
            ? album['cover']!.trim()
            : await _resolveLocalAlbumCover(albumId, tracks);
        if (cover.trim().isNotEmpty) album['cover'] = cover.trim();

        _albumTracksCache[albumId] = tracks;
        _indexAlbumFromTracks(album, tracks, save: false);
        _indexTracksForAlbum(album, tracks);
        if (cover.trim().isNotEmpty) {
          _applyAlbumCoverFromMetadataScan(
            albumId,
            cover.trim(),
            persistChanges: false,
            refreshUi: false,
          );
        }
        existingById[albumId] = album;
      }

      _albums = existingById.values
          .where((album) => (album['id'] ?? '').trim().isNotEmpty)
          .toList()
        ..sort((a, b) =>
            (a['displayName'] ?? a['name'] ?? '').compareTo(
              b['displayName'] ?? b['name'] ?? '',
            ));

      await _metaStore.persistNow();
      await _saveLibraryTrackIndex();
      await _saveLibraryBrain();
      await _persistAlbums();
      await _saveKnownTrackDurations();

      _librarySearchTextCache.clear();
      _invalidateHomeBrowseCache();
      _invalidateLibraryBrowseCache();
      _nowPlaying.refresh();

      if (mounted) setState(() {});
      final cacheText = reusedCached > 0 ? ' ($reusedCached cached)' : '';
      _showSuccess('$successPrefix $importedTracks local songs$cacheText.');
    } catch (e) {
      _showError('Local import failed: $e');
    }
  }

  Future<TrackMetadata> _readLocalTrackMetadata(
    drive.File localFile,
    File file,
  ) async {
    final cachedFresh = _metaStore.peekFresh(localFile);
    if (cachedFresh != null) return cachedFresh;

    final fallback = DriveUtils.getTrackMeta(localFile);
    try {
      final raw = readMetadata(file, getImage: false);
      final durationMs = _durationMsFromDynamic(raw.duration);
      return TrackMetadata(
        title: raw.title?.trim().isNotEmpty == true
            ? raw.title!.trim()
            : fallback['title'] ?? localFile.name ?? 'Unknown',
        artist: raw.artist?.trim().isNotEmpty == true
            ? raw.artist!.trim()
            : fallback['artist'] ?? 'Unknown Artist',
        album: raw.album?.trim().isNotEmpty == true
            ? raw.album!.trim()
            : _localAlbumFallbackFromPath(file.path),
        trackNumber: raw.trackNumber,
        discNumber: raw.discNumber,
        modifiedTime: localFile.modifiedTime?.toIso8601String(),
        size: localFile.size,
        durationMs: durationMs,
      );
    } catch (_) {
      return TrackMetadata(
        title: fallback['title'] ?? localFile.name ?? 'Unknown',
        artist: fallback['artist'] ?? 'Unknown Artist',
        album: _localAlbumFallbackFromPath(file.path),
        modifiedTime: localFile.modifiedTime?.toIso8601String(),
        size: localFile.size,
      );
    }
  }

  int? _durationMsFromDynamic(dynamic value) {
    if (value == null) return null;
    if (value is Duration) return value.inMilliseconds;
    if (value is int) return value > 0 ? value : null;
    final parsed = int.tryParse(value.toString());
    return parsed != null && parsed > 0 ? parsed : null;
  }

  String _localAlbumFallbackFromPath(String path) {
    final dir = _localDirname(path);
    if (dir.isEmpty) return 'Local Files';
    final album = _localBasename(dir);
    return album.trim().isEmpty ? 'Local Files' : album.trim();
  }

  Future<String> _resolveLocalAlbumCover(
    String albumId,
    List<drive.File> tracks,
  ) async {
    if (tracks.isEmpty) return '';

    final folderCover = await _findLocalFolderCover(tracks);
    if (folderCover.isNotEmpty) return folderCover;

    for (final track in tracks.take(3)) {
      final path = DriveUtils.localPath(track);
      if (path == null || path.trim().isEmpty) continue;
      final cover = await _readAndCacheEmbeddedLocalCover(albumId, File(path));
      if (cover.isNotEmpty) return cover;
    }

    return '';
  }

  Future<String> _findLocalFolderCover(List<drive.File> tracks) async {
    final checkedDirs = <String>{};

    for (final track in tracks.take(6)) {
      final path = DriveUtils.localPath(track);
      if (path == null || path.isEmpty) continue;
      final dir = _localDirname(path);
      if (dir.isEmpty || !checkedDirs.add(dir)) continue;

      for (final name in _localFolderCoverNames) {
        final candidate = File('$dir/$name');
        if (await candidate.exists()) return candidate.path;
      }
    }

    return '';
  }

  Future<String> _readAndCacheEmbeddedLocalCover(String albumId, File file) async {
    if (!await file.exists()) return '';

    try {
      final dynamic raw = readMetadata(file, getImage: true);
      final bytes = _coverBytesFromDynamic(raw);
      if (bytes == null || bytes.isEmpty) return '';

      final dir = await getApplicationDocumentsDirectory();
      final coverDir = Directory('${dir.path}/infame_local_covers');
      if (!await coverDir.exists()) await coverDir.create(recursive: true);

      final safeName = _safeCacheName(albumId);
      final coverFile = File('${coverDir.path}/$safeName.jpg');
      await coverFile.writeAsBytes(bytes, flush: false);
      return coverFile.path;
    } catch (_) {
      return '';
    }
  }

  Uint8List? _coverBytesFromDynamic(dynamic raw) {
    dynamic value;

    try {
      value = raw.pictures;
      final bytes = _bytesFromPictureCollection(value);
      if (bytes != null) return bytes;
    } catch (_) {}

    try {
      value = raw.images;
      final bytes = _bytesFromPictureCollection(value);
      if (bytes != null) return bytes;
    } catch (_) {}

    try {
      value = raw.picture;
      final bytes = _bytesFromDynamicPicture(value);
      if (bytes != null) return bytes;
    } catch (_) {}

    try {
      value = raw.image;
      final bytes = _bytesFromDynamicPicture(value);
      if (bytes != null) return bytes;
    } catch (_) {}

    try {
      value = raw.coverBytes;
      final bytes = _bytesFromDynamicPicture(value);
      if (bytes != null) return bytes;
    } catch (_) {}

    return null;
  }

  Uint8List? _bytesFromPictureCollection(dynamic value) {
    if (value == null) return null;
    if (value is Uint8List) return value;
    if (value is List<int>) return Uint8List.fromList(value);
    if (value is Iterable && value.isNotEmpty) {
      for (final item in value) {
        final bytes = _bytesFromDynamicPicture(item);
        if (bytes != null && bytes.isNotEmpty) return bytes;
      }
    }
    return _bytesFromDynamicPicture(value);
  }

  Uint8List? _bytesFromDynamicPicture(dynamic value) {
    if (value == null) return null;
    if (value is Uint8List) return value;
    if (value is List<int>) return Uint8List.fromList(value);

    try {
      final dynamic bytes = value.bytes;
      if (bytes is Uint8List) return bytes;
      if (bytes is List<int>) return Uint8List.fromList(bytes);
    } catch (_) {}

    try {
      final dynamic bytes = value.data;
      if (bytes is Uint8List) return bytes;
      if (bytes is List<int>) return Uint8List.fromList(bytes);
    } catch (_) {}

    try {
      final dynamic bytes = value.pictureData;
      if (bytes is Uint8List) return bytes;
      if (bytes is List<int>) return Uint8List.fromList(bytes);
    } catch (_) {}

    return null;
  }

  Future<void> _removeMissingLocalFiles() async {
    if (_isScanning || _loadingMetadata) {
      _showError('Wait for the current scan to finish first.');
      return;
    }

    final missingIds = <String>[];
    for (final entry in _libraryTrackIndex.entries) {
      final record = entry.value;
      if ((record['source'] ?? '') != 'local') continue;
      final path = (record['localPath'] ?? '').trim();
      if (path.isEmpty || !File(path).existsSync()) missingIds.add(entry.key);
    }

    if (missingIds.isEmpty) {
      _showSuccess('No missing local files found.');
      return;
    }

    for (final id in missingIds) {
      _libraryTrackIndex.remove(id);
    }

    final localAlbumIdsWithTracks = _libraryTrackIndex.values
        .where((record) => (record['source'] ?? '') == 'local')
        .map((record) => (record['albumId'] ?? '').trim())
        .where((id) => id.isNotEmpty)
        .toSet();

    _albums.removeWhere((album) =>
        _isLocalAlbumRecord(album) &&
        !localAlbumIdsWithTracks.contains((album['id'] ?? '').trim()));

    final emptyLocalAlbumCaches = <String>[];
    final updatedLocalAlbumCaches = <String, List<drive.File>>{};
    _albumTracksCache.forEach((albumId, tracks) {
      if (!albumId.startsWith('local_album:')) return;
      final kept = tracks.where((track) {
        final id = DriveUtils.effectiveId(track);
        final path = DriveUtils.localPath(track);
        return id != null &&
            _libraryTrackIndex.containsKey(id) &&
            (path == null || path.isEmpty || File(path).existsSync());
      }).toList();
      if (kept.isEmpty) {
        emptyLocalAlbumCaches.add(albumId);
      } else {
        updatedLocalAlbumCaches[albumId] = kept;
      }
    });
    for (final albumId in emptyLocalAlbumCaches) {
      _albumTracksCache.remove(albumId);
    }
    updatedLocalAlbumCaches.forEach((albumId, tracks) {
      _albumTracksCache[albumId] = tracks;
    });

    await _saveLibraryTrackIndex();
    await _saveLibraryBrain();
    await _persistAlbums();

    _librarySearchTextCache.clear();
    _invalidateHomeBrowseCache();
    _invalidateLibraryBrowseCache();
    _nowPlaying.refresh();
    if (mounted) setState(() {});

    _showSuccess('Removed ${missingIds.length} missing local songs.');
  }

  Future<void> _loadMetadataForLocal(
    drive.File file, {
    Map<String, String>? albumRecord,
  }) async {
    final localPath = DriveUtils.localPath(file);
    if (localPath == null || localPath.isEmpty) return;

    try {
      final localFile = File(localPath);
      if (!await localFile.exists()) return;

      final metadata = await _readLocalTrackMetadata(file, localFile);
      await _metaStore.put(file, metadata);
      _indexTracksForAlbum(albumRecord ?? _viewingAlbum ?? <String, String>{}, [
        file,
      ]);
      _nowPlaying.refresh();
      if (mounted) setState(() {});
    } catch (_) {
      return;
    }
  }
}
