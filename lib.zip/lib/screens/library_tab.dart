part of '../main.dart';

extension BuildLibraryTabExtension on _MainScreenState {
  String _libraryAlbumTitle(Map<String, String> album) {
    final brain = _libraryBrain[album['id'] ?? ''];
    return brain?['displayName'] ?? album['displayName'] ?? album['name'] ?? 'Album';
  }

  String _libraryAlbumArtist(Map<String, String> album) {
    final brain = _libraryBrain[album['id'] ?? ''];
    final artist = _cleanBrainValue(brain?['artist']).isNotEmpty
        ? brain!['artist']!
        : _cleanBrainValue(album['artist']).isNotEmpty
            ? album['artist']!
            : _artistAlbumFromFolder(album['name'] ?? '')['artist'] ?? '';
    return artist;
  }

  String _libraryAlbumSearchText(Map<String, String> album) {
    final brain = _libraryBrain[album['id'] ?? ''] ?? const <String, String>{};
    final tracks = _albumTracksCache[album['id'] ?? ''] ?? const <drive.File>[];
    final trackText = <String>[];

    for (final track in tracks) {
      final cached = _metaStore.peekFresh(track) ?? _metaStore.peek(track);
      trackText.add(track.name ?? '');
      if (cached != null) {
        trackText.addAll([
          cached.title,
          cached.artist,
          cached.album ?? '',
          cached.year ?? '',
          cached.genre ?? '',
        ]);
      }
    }

    return [
      album['name'] ?? '',
      album['displayName'] ?? '',
      album['artist'] ?? '',
      album['genre'] ?? '',
      album['year'] ?? '',
      brain['displayName'] ?? '',
      brain['artist'] ?? '',
      brain['genre'] ?? '',
      brain['year'] ?? '',
      _artistAlbumFromFolder(album['name'] ?? '')['artist'] ?? '',
      _artistAlbumFromFolder(album['name'] ?? '')['album'] ?? '',
      ...trackText,
    ].join(' ').toLowerCase();
  }

  bool _libraryAlbumMatches(Map<String, String> album, String query) {
    if (query.isEmpty) return true;
    final words = query.split(RegExp(r'\s+')).where((w) => w.trim().isNotEmpty);
    final haystack = _libraryAlbumSearchText(album);
    return words.every((word) => haystack.contains(word));
  }

  int _visibleArtistCount() {
    final artists = <String>{};
    for (final album in _albums) {
      final artist = _cleanBrainValue(_libraryAlbumArtist(album));
      if (artist.isNotEmpty) artists.add(artist.toLowerCase());
    }
    return artists.length;
  }

  Widget buildLibraryTab() {
    final colors = _safeColors(_currentDynamicColors);
    final query = _libraryQuery.trim().toLowerCase();
    final visibleAlbums = _albums.where((album) => _libraryAlbumMatches(album, query)).toList();
    final bgColor = _isDarkMode ? _darkBg : _lightBg;

    visibleAlbums.sort((a, b) {
      final an = _libraryAlbumTitle(a).toLowerCase();
      final bn = _libraryAlbumTitle(b).toLowerCase();
      if (_librarySortMode == 'artist') {
        final aa = _libraryAlbumArtist(a).toLowerCase();
        final ba = _libraryAlbumArtist(b).toLowerCase();
        final byArtist = aa.compareTo(ba);
        if (byArtist != 0) return byArtist;
      }
      if (_librarySortMode == 'za') return bn.compareTo(an);
      return an.compareTo(bn);
    });

    return Container(
      color: bgColor,
      child: CustomScrollView(
        key: const PageStorageKey('library_tab_scroll'),
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 40, 20, 14),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: _buildGradientText('Crates', size: 34, spacing: -1.4)),
                    IconButton(
                      tooltip: _libraryGridMode ? 'List view' : 'Grid view',
                      icon: Icon(
                        _libraryGridMode ? Icons.view_list_rounded : Icons.grid_view_rounded,
                        color: _textSub,
                      ),
                      onPressed: () => setState(() => _libraryGridMode = !_libraryGridMode),
                    ),
                    PopupMenuButton<String>(
                      tooltip: 'Sort library',
                      icon: const Icon(Icons.sort_rounded, color: _textSub),
                      color: const Color(0xFF1A1A22),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      onSelected: (value) => setState(() => _librarySortMode = value),
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          value: 'az',
                          child: Text('Album A–Z', style: GoogleFonts.inter(color: _textPri)),
                        ),
                        PopupMenuItem(
                          value: 'za',
                          child: Text('Album Z–A', style: GoogleFonts.inter(color: _textPri)),
                        ),
                        PopupMenuItem(
                          value: 'artist',
                          child: Text('Artist A–Z', style: GoogleFonts.inter(color: _textPri)),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Search albums, artists, songs, years — all in one place.',
                  style: GoogleFonts.inter(
                    color: _textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 16),
                GlassyContainer(
                  radius: 26,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                  customColor: Colors.white.withOpacity(0.078),
                  customBorder: Colors.white.withOpacity(0.13),
                  child: TextField(
                    onChanged: (value) => setState(() => _libraryQuery = value),
                    style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w800),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      icon: Icon(Icons.manage_search_rounded, color: colors[1]),
                      suffixIcon: _libraryQuery.trim().isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.close_rounded, color: _textSub),
                              onPressed: () => setState(() => _libraryQuery = ''),
                            )
                          : null,
                      hintText: 'Search Nas, Illmatic, track names...',
                      hintStyle: GoogleFonts.inter(color: _textSub, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _LibraryInfoChip(label: '${visibleAlbums.length}/${_albums.length} albums', accent: colors[1]),
                    _LibraryInfoChip(label: '${_visibleArtistCount()} artists', accent: colors[2]),
                    _LibraryInfoChip(label: '${_metaStore.count} tagged tracks', accent: colors[0]),
                    if (_libraryQuery.trim().isNotEmpty)
                      GestureDetector(
                        onTap: () => setState(() => _libraryQuery = ''),
                        child: _LibraryInfoChip(label: 'Clear search ×', accent: _pink),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        if (_loadingSaved || _isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _accentDefault)),
          )
        else if (_albums.isEmpty)
          const SliverFillRemaining(
            child: Center(child: Text('Library is empty.', style: TextStyle(color: _textSub))),
          )
        else if (visibleAlbums.isEmpty)
          SliverFillRemaining(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'No records match that search.',
                    style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  TextButton(
                    onPressed: () => setState(() => _libraryQuery = ''),
                    child: Text('Clear search', style: GoogleFonts.inter(color: colors[1], fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
          )
        else if (_libraryGridMode)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 218),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.78,
              ),
              delegate: SliverChildBuilderDelegate((ctx, i) {
                final album = visibleAlbums[i];
                final merged = Map<String, String>.from(album);
                final brain = _libraryBrain[album['id'] ?? ''];
                if (brain != null) merged.addAll(brain);
                final folderGuess = _artistAlbumFromFolder(album['name'] ?? '');
                merged['artist'] = _libraryAlbumArtist(album);
                merged['displayName'] = _libraryAlbumTitle(album);
                if ((merged['artist'] ?? '').isEmpty && folderGuess['artist'] != null) {
                  merged['artist'] = folderGuess['artist']!;
                }
                return _AlbumGridCard(
                  key: ValueKey(album['id'] ?? album['name']),
                  album: merged,
                  onTap: () => _openAlbum(album),
                  isDarkMode: _isDarkMode,
                );
              }, childCount: visibleAlbums.length),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 218),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((ctx, i) {
                final album = visibleAlbums[i];
                final brain = _libraryBrain[album['id'] ?? ''];
                final name = _libraryAlbumTitle(album);
                final artist = _libraryAlbumArtist(album);
                final year = brain?['year'] ?? album['year'] ?? '';
                final genre = brain?['genre'] ?? album['genre'] ?? '';
                final coverUrl = album['cover'] ?? brain?['cover'] ?? '';
                final gradient = getAlbumGradient(name);

                return GestureDetector(
                  key: ValueKey(album['id'] ?? album['name']),
                  onTap: () => _openAlbum(album),
                  behavior: HitTestBehavior.opaque,
                  child: GlassyContainer(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    radius: 20,
                    child: Row(
                      children: [
                        Container(
                          width: 58,
                          height: 58,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: gradient,
                            ),
                          ),
                          child: coverUrl.isNotEmpty
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(14),
                                  child: _coverImage(
                                    coverUrl,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => _AlbumFallbackCover(
                                      name: name,
                                      colors: gradient,
                                      radius: 14,
                                      small: true,
                                    ),
                                  ),
                                )
                              : _AlbumFallbackCover(
                                  name: name,
                                  colors: gradient,
                                  radius: 14,
                                  small: true,
                                ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  color: _textPri,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                artist.isNotEmpty
                                    ? artist
                                    : year.isNotEmpty
                                        ? year
                                        : genre.isNotEmpty
                                            ? genre
                                            : 'Album • Drive',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(fontSize: 12, color: _textSub, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded, color: _textSub),
                      ],
                    ),
                  ),
                );
              }, childCount: visibleAlbums.length),
            ),
          ),
        ],
      ),
    );
  }
}

class _LibraryInfoChip extends StatelessWidget {
  final String label;
  final Color accent;

  const _LibraryInfoChip({required this.label, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: accent.withOpacity(0.25)),
      ),
      child: Text(
        label,
        style: GoogleFonts.inter(
          color: Colors.white.withOpacity(0.88),
          fontSize: 11,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}
