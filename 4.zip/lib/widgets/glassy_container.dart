import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

const String glassModePerformance = 'performance';
const String glassModeBalanced = 'balanced';
const String glassModePretty = 'pretty';

final ValueNotifier<String> glassModeNotifier =
    ValueNotifier<String>(glassModeBalanced);

final Color glassBorder = Colors.white.withOpacity(0.12);

class GlassyContainer extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final double blur;
  final Color? customBorder;
  final Color? customColor;
  final bool allowRealBlur;

  const GlassyContainer({
    super.key,
    required this.child,
    this.radius = 16,
    this.padding = EdgeInsets.zero,
    this.margin = EdgeInsets.zero,
    this.blur = 14,
    this.customBorder,
    this.customColor,
    this.allowRealBlur = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin,
      child: ValueListenableBuilder<String>(
        valueListenable: glassModeNotifier,
        builder: (context, mode, _) {
          final useRealBlur = allowRealBlur && mode != glassModePerformance;
          final effectiveBlur =
              mode == glassModePretty ? blur : math.min(blur, 10).toDouble();

          final effectiveColor = customColor ??
              (mode == glassModePerformance
                  ? Colors.white.withOpacity(0.055)
                  : Colors.white.withOpacity(0.075));

          final effectiveBorder = customBorder ??
              (mode == glassModePretty
                  ? Colors.white.withOpacity(0.18)
                  : glassBorder);

          final decorated = Container(
            padding: padding,
            decoration: BoxDecoration(
              color: effectiveColor,
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(color: effectiveBorder, width: 1),
              boxShadow: mode == glassModePerformance
                  ? const []
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.16),
                        blurRadius: mode == glassModePretty ? 24 : 16,
                        offset: const Offset(0, 8),
                      ),
                    ],
            ),
            child: child,
          );

          if (!useRealBlur) return decorated;

          return ClipRRect(
            borderRadius: BorderRadius.circular(radius),
            child: BackdropFilter(
              filter: ImageFilter.blur(
                sigmaX: effectiveBlur,
                sigmaY: effectiveBlur,
              ),
              child: decorated,
            ),
          );
        },
      ),
    );
  }
}