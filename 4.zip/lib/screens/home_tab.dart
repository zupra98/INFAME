part of '../main.dart';

extension BuildHomeTabExtension on _MainScreenState {
  Widget buildHomeTab() {
    final colors = _safeColors(_currentDynamicColors);
    final spotlight = _spotlightAlbum();
    final recent = _recentBrainAlbums(limit: 14);
    final played = _lastPlayedAlbums(limit: 12);
    final heavy = _mostPlayedAlbums(limit: 12);
    final all = _homeDistinctAlbums([played, recent, heavy, _brainAlbums()], limit: 18);
    final hero = spotlight ?? (played.isNotEmpty ? played.first : recent.isNotEmpty ? recent.first : null);

    return CustomScrollView(
      key: const PageStorageKey('home_tab_scroll_v2'),
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(18, 30, 18, 0),
          sliver: SliverToBoxAdapter(
            child: _InfameHomeChrome(
              colors: colors,
              onSettings: _openSettingsSheet,
              onSources: () => _selectRootTab(2),
            ),
          ),
        ),
        if (_loadingMetadata)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
            sliver: SliverToBoxAdapter(
              child: _InfameScanRibbon(
                label: _metadataStatusLabel(),
                progress: _metadataTotal > 0 ? (_metadataDone / _metadataTotal).clamp(0.0, 1.0) : null,
                colors: colors,
                onTap: _openSettingsSheet,
              ),
            ),
          ),
        if (_loadingSaved || _isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator(color: _pink)),
          )
        else if (_albums.isEmpty)
          SliverFillRemaining(
            child: _InfameEmptyHome(onSources: () => _selectRootTab(2)),
          )
        else ...[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 26),
            sliver: SliverToBoxAdapter(
              child: _InfameBlacksiteHero(
                hero: hero,
                albums: all,
                colors: colors,
                onHeroTap: hero == null ? null : () => _openAlbumByBrain(hero),
                onLibrary: () => _selectRootTab(1),
                onSources: () => _selectRootTab(2),
              ),
            ),
          ),
          if (played.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 26),
              sliver: SliverToBoxAdapter(
                child: _InfameTapeRun(
                  title: 'LAST SIGNALS',
                  subtitle: 'Records still warm from playback',
                  albums: played,
                  colors: colors,
                  onTap: _openAlbumByBrain,
                ),
              ),
            ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 26),
            sliver: SliverToBoxAdapter(
              child: _InfamePortalGrid(
                colors: colors,
                recent: recent,
                heavy: heavy,
                onLibrary: () => _selectRootTab(1),
                onSources: () => _selectRootTab(2),
                onAlbum: _openAlbumByBrain,
              ),
            ),
          ),
          if (recent.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 0, 24),
              sliver: SliverToBoxAdapter(
                child: _InfameCoverRiver(
                  title: 'FRESH PULLS',
                  subtitle: 'Recently indexed from the vault',
                  albums: recent,
                  colors: colors,
                  onTap: _openAlbumByBrain,
                ),
              ),
            ),
          if (_playHistory.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 0, 228),
              sliver: SliverToBoxAdapter(
                child: _InfameTrackSignals(
                  history: _playHistory.take(10).toList(),
                  colors: colors,
                  onTap: (item) {
                    final album = _albumById(item['albumId'] ?? '');
                    if (album != null) _openAlbum(album);
                  },
                ),
              ),
            )
          else
            const SliverToBoxAdapter(child: SizedBox(height: 226)),
        ],
      ],
    );
  }

  List<Map<String, String>> _homeDistinctAlbums(
    List<List<Map<String, String>>> groups, {
    int limit = 8,
  }) {
    final seen = <String>{};
    final out = <Map<String, String>>[];
    for (final group in groups) {
      for (final album in group) {
        final id = album['albumId'] ?? album['id'] ?? album['name'] ?? '';
        if (id.isEmpty || seen.contains(id)) continue;
        seen.add(id);
        out.add(album);
        if (out.length >= limit) return out;
      }
    }
    return out;
  }
}

class _InfameHomeChrome extends StatelessWidget {
  final List<Color> colors;
  final VoidCallback onSettings;
  final VoidCallback onSources;

  const _InfameHomeChrome({
    required this.colors,
    required this.onSettings,
    required this.onSources,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _PulseDot(color: _pink),
                  const SizedBox(width: 10),
                  Text(
                    'INFAME / PRIVATE ARCHIVE',
                    style: GoogleFonts.inter(
                      color: Colors.white.withOpacity(0.52),
                      fontSize: 11,
                      letterSpacing: 2.2,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Signal room',
                style: GoogleFonts.inter(
                  color: _textPri,
                  fontSize: 34,
                  letterSpacing: -1.6,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        _ChromeButton(icon: Icons.folder_special_rounded, color: safe[2], onTap: onSources),
        const SizedBox(width: 9),
        _ChromeButton(icon: Icons.tune_rounded, color: safe[1], onTap: onSettings),
      ],
    );
  }
}

class _PulseDot extends StatelessWidget {
  final Color color;
  const _PulseDot({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [BoxShadow(color: color.withOpacity(0.75), blurRadius: 18, spreadRadius: 3)],
      ),
    );
  }
}

class _ChromeButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _ChromeButton({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color.withOpacity(0.32), Colors.white.withOpacity(0.06)]),
          border: Border.all(color: color.withOpacity(0.30)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.18), blurRadius: 22, offset: const Offset(0, 9))],
        ),
        child: Icon(icon, color: _textPri, size: 22),
      ),
    );
  }
}

class _InfameScanRibbon extends StatelessWidget {
  final String label;
  final double? progress;
  final List<Color> colors;
  final VoidCallback onTap;

  const _InfameScanRibbon({required this.label, required this.progress, required this.colors, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(colors: [safe[1].withOpacity(0.22), Colors.white.withOpacity(0.055)]),
          border: Border.all(color: safe[1].withOpacity(0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2.2, color: safe[1])),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(label, style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: progress,
              minHeight: 4,
              borderRadius: BorderRadius.circular(99),
              backgroundColor: Colors.white.withOpacity(0.12),
              valueColor: AlwaysStoppedAnimation<Color>(safe[1]),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfameBlacksiteHero extends StatelessWidget {
  final Map<String, String>? hero;
  final List<Map<String, String>> albums;
  final List<Color> colors;
  final VoidCallback? onHeroTap;
  final VoidCallback onLibrary;
  final VoidCallback onSources;

  const _InfameBlacksiteHero({
    required this.hero,
    required this.albums,
    required this.colors,
    required this.onHeroTap,
    required this.onLibrary,
    required this.onSources,
  });

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    final title = hero?['displayName'] ?? hero?['name'] ?? 'The vault is awake';
    final artist = hero?['artist'] ?? 'No algorithm. No feed. Just your records.';
    final cover = hero?['cover'] ?? hero?['coverUrl'] ?? '';
    final gradient = getAlbumGradient(title);
    final stack = albums.isEmpty ? (hero == null ? <Map<String, String>>[] : [hero!]) : albums;

    return GestureDetector(
      onTap: onHeroTap,
      child: Container(
        height: 520,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40),
          gradient: RadialGradient(
            center: const Alignment(-0.9, -0.95),
            radius: 1.48,
            colors: [
              _pink.withOpacity(0.55),
              safe[2].withOpacity(0.34),
              const Color(0xFF09090E),
              Colors.black,
            ],
            stops: const [0.0, 0.34, 0.76, 1.0],
          ),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(color: _pink.withOpacity(0.22), blurRadius: 60, spreadRadius: -10, offset: const Offset(0, 24)),
            BoxShadow(color: safe[2].withOpacity(0.16), blurRadius: 70, spreadRadius: -18, offset: const Offset(-18, -8)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(40),
          child: Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: _InfameGridPainter(color: Colors.white.withOpacity(0.055)))),
              Positioned(right: -58, top: -30, child: _OrbitStack(albums: stack, size: 260)),
              Positioned(left: -40, bottom: 28, child: _GhostVinyl(color: safe[1].withOpacity(0.22), size: 210)),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black.withOpacity(0.12), Colors.black.withOpacity(0.72)],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 22,
                top: 24,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    color: Colors.black.withOpacity(0.36),
                    border: Border.all(color: Colors.white.withOpacity(0.14)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _PulseDot(color: _cyan),
                      const SizedBox(width: 9),
                      Text('LIVE SIGNAL', style: GoogleFonts.inter(color: _textPri, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 22,
                right: 22,
                bottom: 22,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (cover.isNotEmpty)
                      Container(
                        width: 86,
                        height: 86,
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          gradient: LinearGradient(colors: gradient),
                          boxShadow: [BoxShadow(color: gradient.first.withOpacity(0.32), blurRadius: 30, offset: const Offset(0, 14))],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(22),
                          child: _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: title, colors: gradient, radius: 22, small: true)),
                        ),
                      ),
                    Text(
                      'TONIGHT\'S OBJECT',
                      style: GoogleFonts.inter(color: safe[1], fontSize: 11, letterSpacing: 2.2, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.inter(color: _textPri, fontSize: 38, height: 0.96, letterSpacing: -1.8, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      artist.isEmpty ? 'Album from your private library' : artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.inter(color: Colors.white.withOpacity(0.66), fontSize: 13, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(child: _HomeShardButton(icon: Icons.library_music_rounded, label: 'Crates', color: _cyan, onTap: onLibrary)),
                        const SizedBox(width: 10),
                        Expanded(child: _HomeShardButton(icon: Icons.folder_special_rounded, label: 'Sources', color: _accentBlue, onTap: onSources)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OrbitStack extends StatelessWidget {
  final List<Map<String, String>> albums;
  final double size;
  const _OrbitStack({required this.albums, required this.size});

  @override
  Widget build(BuildContext context) {
    final shown = albums.take(6).toList();
    return SizedBox(
      width: size,
      height: size + 80,
      child: Stack(
        children: [
          for (int i = 0; i < shown.length; i++)
            Positioned(
              left: [44.0, 2.0, 116.0, 72.0, 160.0, 18.0][i % 6],
              top: [8.0, 118.0, 122.0, 216.0, 38.0, 240.0][i % 6],
              child: Transform.rotate(
                angle: [-0.22, 0.17, -0.08, 0.24, 0.13, -0.18][i % 6],
                child: _CoverChip(album: shown[i], size: [128.0, 92.0, 108.0, 82.0, 72.0, 64.0][i % 6]),
              ),
            ),
        ],
      ),
    );
  }
}

class _CoverChip extends StatelessWidget {
  final Map<String, String> album;
  final double size;
  const _CoverChip({required this.album, required this.size});

  @override
  Widget build(BuildContext context) {
    final name = album['displayName'] ?? album['name'] ?? 'Album';
    final cover = album['cover'] ?? album['coverUrl'] ?? '';
    final gradient = getAlbumGradient(name);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.19),
        gradient: LinearGradient(colors: gradient),
        border: Border.all(color: Colors.white.withOpacity(0.16)),
        boxShadow: [BoxShadow(color: gradient.first.withOpacity(0.28), blurRadius: 26, offset: const Offset(0, 14))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size * 0.19),
        child: cover.isNotEmpty
            ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: name, colors: gradient, radius: size * 0.19, small: true))
            : _AlbumFallbackCover(name: name, colors: gradient, radius: size * 0.19, small: true),
      ),
    );
  }
}

class _GhostVinyl extends StatelessWidget {
  final Color color;
  final double size;
  const _GhostVinyl({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: color.withOpacity(0.45), width: 2),
        gradient: RadialGradient(colors: [Colors.transparent, color.withOpacity(0.20), Colors.transparent], stops: const [0.0, 0.55, 1.0]),
      ),
      child: Center(
        child: Container(
          width: size * 0.18,
          height: size * 0.18,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.25)),
        ),
      ),
    );
  }
}

class _HomeShardButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _HomeShardButton({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: [color.withOpacity(0.28), Colors.white.withOpacity(0.07)]),
          border: Border.all(color: color.withOpacity(0.28)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _textPri, size: 18),
            const SizedBox(width: 9),
            Text(label, style: GoogleFonts.inter(color: _textPri, fontWeight: FontWeight.w900, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

class _InfameTapeRun extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Map<String, String>> albums;
  final List<Color> colors;
  final ValueChanged<Map<String, String>> onTap;
  const _InfameTapeRun({required this.title, required this.subtitle, required this.albums, required this.colors, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        color: Colors.white.withOpacity(0.052),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InfameHomeSection(title: title, subtitle: subtitle, color: safe[1]),
          const SizedBox(height: 14),
          SizedBox(
            height: 170,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: albums.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => _HomeTapeCard(album: albums[i], onTap: () => onTap(albums[i]), big: i == 0),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeTapeCard extends StatelessWidget {
  final Map<String, String> album;
  final bool big;
  final VoidCallback onTap;
  const _HomeTapeCard({required this.album, required this.onTap, this.big = false});

  @override
  Widget build(BuildContext context) {
    final name = album['displayName'] ?? album['name'] ?? 'Album';
    final artist = album['artist'] ?? '';
    final cover = album['cover'] ?? album['coverUrl'] ?? '';
    final gradient = getAlbumGradient(name);
    final width = big ? 174.0 : 126.0;
    final size = big ? 126.0 : 104.0;
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(colors: gradient),
                boxShadow: [BoxShadow(color: gradient.first.withOpacity(0.22), blurRadius: 20, offset: const Offset(0, 12))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: cover.isNotEmpty
                    ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: name, colors: gradient, radius: 24, small: true))
                    : _AlbumFallbackCover(name: name, colors: gradient, radius: 24, small: true),
              ),
            ),
            const SizedBox(height: 9),
            Text(name, maxLines: big ? 2 : 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textPri, fontSize: big ? 15 : 13, height: 1.08, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(artist.isEmpty ? 'Album' : artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textSub, fontSize: 11, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class _InfamePortalGrid extends StatelessWidget {
  final List<Color> colors;
  final List<Map<String, String>> recent;
  final List<Map<String, String>> heavy;
  final VoidCallback onLibrary;
  final VoidCallback onSources;
  final ValueChanged<Map<String, String>> onAlbum;
  const _InfamePortalGrid({required this.colors, required this.recent, required this.heavy, required this.onLibrary, required this.onSources, required this.onAlbum});

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    final randomPick = [...recent, ...heavy];
    final pick = randomPick.isNotEmpty ? randomPick[math.Random().nextInt(randomPick.length)] : null;
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _PortalTile(title: 'CRATES', subtitle: 'Browse the whole archive', icon: Icons.all_inbox_rounded, color: _cyan, onTap: onLibrary)),
            const SizedBox(width: 12),
            Expanded(child: _PortalTile(title: 'SOURCES', subtitle: 'Drive folders & scans', icon: Icons.hub_rounded, color: _accentBlue, onTap: onSources)),
          ],
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: pick == null ? null : () => onAlbum(pick),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              gradient: LinearGradient(colors: [safe[0].withOpacity(0.34), safe[2].withOpacity(0.16), Colors.white.withOpacity(0.045)]),
              border: Border.all(color: Colors.white.withOpacity(0.10)),
            ),
            child: Row(
              children: [
                Icon(Icons.casino_rounded, color: safe[1], size: 28),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('CRATE DICE', style: GoogleFonts.inter(color: _textPri, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: -0.2)),
                      const SizedBox(height: 3),
                      Text(pick == null ? 'Add albums to unlock random pulls' : 'Tap for ${pick['displayName'] ?? pick['name'] ?? 'a random album'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textSub, fontSize: 12, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_rounded, color: _textSub),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _PortalTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _PortalTile({required this.title, required this.subtitle, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 138,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: RadialGradient(center: const Alignment(-0.75, -0.8), colors: [color.withOpacity(0.36), Colors.white.withOpacity(0.055), Colors.black.withOpacity(0.12)]),
          border: Border.all(color: color.withOpacity(0.20)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const Spacer(),
            Text(title, style: GoogleFonts.inter(color: _textPri, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            const SizedBox(height: 4),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textSub, fontSize: 11, height: 1.18, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class _InfameCoverRiver extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Map<String, String>> albums;
  final List<Color> colors;
  final ValueChanged<Map<String, String>> onTap;
  const _InfameCoverRiver({required this.title, required this.subtitle, required this.albums, required this.colors, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.only(right: 18), child: _InfameHomeSection(title: title, subtitle: subtitle, color: safe[2])),
        const SizedBox(height: 14),
        SizedBox(
          height: 212,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: albums.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => _RiverCard(album: albums[i], onTap: () => onTap(albums[i])),
          ),
        ),
      ],
    );
  }
}

class _RiverCard extends StatelessWidget {
  final Map<String, String> album;
  final VoidCallback onTap;
  const _RiverCard({required this.album, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final name = album['displayName'] ?? album['name'] ?? 'Album';
    final cover = album['cover'] ?? album['coverUrl'] ?? '';
    final artist = album['artist'] ?? '';
    final gradient = getAlbumGradient(name);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 154,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), color: Colors.white.withOpacity(0.045), border: Border.all(color: Colors.white.withOpacity(0.08))),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 132,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: gradient)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: cover.isNotEmpty ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: name, colors: gradient, radius: 22, small: true)) : _AlbumFallbackCover(name: name, colors: gradient, radius: 22, small: true),
              ),
            ),
            const SizedBox(height: 10),
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textPri, fontSize: 13, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(artist.isEmpty ? 'Fresh pull' : artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textSub, fontSize: 11, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class _InfameTrackSignals extends StatelessWidget {
  final List<Map<String, String>> history;
  final List<Color> colors;
  final ValueChanged<Map<String, String>> onTap;
  const _InfameTrackSignals({required this.history, required this.colors, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final safe = _safeColors(colors);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.only(right: 18), child: _InfameHomeSection(title: 'TRACK RESIDUE', subtitle: 'The last things that hit the player', color: safe[1])),
        const SizedBox(height: 12),
        SizedBox(
          height: 92,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: history.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final item = history[i];
              final cover = item['cover'] ?? '';
              final title = item['title'] ?? 'Track';
              final artist = item['artist'] ?? '';
              final gradient = getAlbumGradient(title);
              return GestureDetector(
                onTap: () => onTap(item),
                child: Container(
                  width: 230,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: Colors.white.withOpacity(0.055), border: Border.all(color: Colors.white.withOpacity(0.08))),
                  child: Row(
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: LinearGradient(colors: gradient)),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: cover.isNotEmpty ? _coverImage(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _AlbumFallbackCover(name: title, colors: gradient, radius: 16, small: true)) : _AlbumFallbackCover(name: title, colors: gradient, radius: 16, small: true),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textPri, fontSize: 13, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 4),
                            Text(artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(color: _textSub, fontSize: 11, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _InfameHomeSection extends StatelessWidget {
  final String title;
  final String subtitle;
  final Color color;
  const _InfameHomeSection({required this.title, required this.subtitle, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 4, height: 30, decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), color: color, boxShadow: [BoxShadow(color: color.withOpacity(0.45), blurRadius: 14)])),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: GoogleFonts.inter(color: _textPri, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -0.4)),
              const SizedBox(height: 2),
              Text(subtitle, style: GoogleFonts.inter(color: _textSub, fontSize: 12, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ],
    );
  }
}

class _InfameEmptyHome extends StatelessWidget {
  final VoidCallback onSources;
  const _InfameEmptyHome({required this.onSources});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _GhostVinyl(color: _pink.withOpacity(0.55), size: 180),
            const SizedBox(height: 24),
            Text('Open the vault', style: GoogleFonts.inter(color: _textPri, fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -1.2)),
            const SizedBox(height: 8),
            Text('Connect a Drive source and Infame will turn folders into a proper music archive.', textAlign: TextAlign.center, style: GoogleFonts.inter(color: _textSub, height: 1.45, fontWeight: FontWeight.w700)),
            const SizedBox(height: 22),
            _HomeShardButton(icon: Icons.folder_special_rounded, label: 'Choose sources', color: _cyan, onTap: onSources),
          ],
        ),
      ),
    );
  }
}

class _InfameGridPainter extends CustomPainter {
  final Color color;
  _InfameGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..strokeWidth = 1;
    for (double x = -size.height; x < size.width + size.height; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paint);
    }
    for (double y = 0; y < size.height; y += 42) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _InfameGridPainter oldDelegate) => oldDelegate.color != color;
}
