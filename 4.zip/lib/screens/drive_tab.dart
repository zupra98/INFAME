part of '../main.dart';

extension BuildDriveTabExtension on _MainScreenState {
Widget buildDriveTab() {
    final folders = _exploreItems.where((f) => DriveUtils.isFolder(f)).toList();
    final tracks = _exploreItems.where((f) => DriveUtils.isAudio(f)).toList();
    final colors = _safeColors(_currentDynamicColors);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 40, 20, 12),
          child: Row(
            children: [
              if (_exploreFolder != null || _navStack.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _textPri),
                  onPressed: _exploreGoBack,
                ),
              Expanded(
                child: Text(
                  _exploreFolder?.name ?? 'My Drive',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.inter(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: _textPri,
                  ),
                ),
              ),
              if (_exploreFolder != null)
                GestureDetector(
                  onTap: _isScanning ? null : () => _scanFolderToLibrary(_exploreFolder!),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _isScanning ? [_glassWhite, _glassWhite] : [colors[0], colors[1]],
                      ),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [
                        BoxShadow(
                          color: colors[0].withOpacity(0.22),
                          blurRadius: 18,
                        ),
                      ],
                    ),
                    child: Text(
                      _isScanning ? 'Scanning...' : 'Scan',
                      style: GoogleFonts.inter(
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: _loadingExplore
              ? const Center(child: CircularProgressIndicator(color: _pink))
              : CustomScrollView(
                  key: const PageStorageKey('search_tab_scroll'),
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    if (folders.isEmpty && tracks.isEmpty)
                      SliverFillRemaining(
                        child: Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 36),
                            child: Text(
                              _exploreFolder == null
                                  ? 'Open Search to load your Drive folders.'
                                  : 'Nothing playable in this folder.',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.inter(color: _textSub, height: 1.5),
                            ),
                          ),
                        ),
                      )
                    else ...[
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate((ctx, i) {
                            final f = folders[i];
                            return GestureDetector(
                              onTap: () => _openExploreFolder(f),
                              child: GlassyContainer(
                                margin: const EdgeInsets.only(bottom: 9),
                                padding: const EdgeInsets.all(15),
                                radius: 18,
                                child: Row(
                                  children: [
                                    Icon(Icons.folder_rounded, color: colors[1], size: 26),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Text(
                                        f.name ?? 'Folder',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.inter(fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    const Icon(Icons.chevron_right_rounded, color: _textSub),
                                  ],
                                ),
                              ),
                            );
                          }, childCount: folders.length),
                        ),
                      ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 218),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate((ctx, i) {
                            return _TrackGlassTile(
                              track: tracks[i],
                              queue: tracks,
                              index: i,
                              onTap: () => _playSong(
                                tracks[i],
                                queue: tracks,
                                idx: i,
                                coverUrl: null,
                                colors: colors,
                              ),
                            );
                          }, childCount: tracks.length),
                        ),
                      ),
                    ],
                  ],
                ),
        ),
      ],
    );
  }

}
